/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import static org.xnap.commons.gui.completion.CompletionModeFactory.I18N;
import java.awt.event.InputEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.KeyStroke;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xnap.commons.gui.shortcut.DefaultShortcut;
import org.xnap.commons.gui.shortcut.ShortcutManager;


/**
 * This mode provides manual completion similar to the one offered by KDE.
 * 
 * Completion has to be triggered manually using a shortcut which can be
 * configured in the {@link org.xnap.commons.gui.shortcut.ShortcutManager} 
 * framework.
 *
 * @author Felix Berger
 */
public class ManualCompletionMode extends AbstractCompletionMode
{
    private static Log logger = LogFactory.getLog(ManualCompletionMode.class);
   
	private static DefaultShortcut manual = new DefaultShortcut
		(KeyStroke.getKeyStroke(KeyEvent.VK_T, InputEvent.CTRL_MASK),
		 I18N.tr("Completion"), I18N.tr("Trigger Manual Completion"));
		
	
	static {
		ShortcutManager.getInstance().add(manual);
	}
   
    private KeyListener listener = new KeyHandler();

    public void disable()
    {
        getTextComponent().removeKeyListener(listener);
    }

    /*
     * @see org.xnap.gui.component.CompletionMode#enable()
     */
    protected void enable()
    {
        getTextComponent().addKeyListener(listener);
    }

    private class KeyHandler extends KeyAdapter
    {
        public void keyPressed(KeyEvent e)
        {
            if (manual.getKeyStroke() != null
				&& manual.getKeyStroke().equals
				(KeyStroke.getKeyStrokeForEvent(e))) {
                String prefix = getText();
                String completion = getModel().completeUniquePrefix(prefix);
				
                if (completion.length() > prefix.length()) {
                    setText(completion, completion.length(), prefix.length());
                }
				e.consume();
            }
        }
    }
}
