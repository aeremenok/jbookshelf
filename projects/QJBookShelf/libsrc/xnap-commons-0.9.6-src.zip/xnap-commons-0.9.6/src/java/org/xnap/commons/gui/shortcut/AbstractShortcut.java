/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.shortcut;

import java.beans.PropertyChangeListener;
import java.util.HashMap;
import javax.swing.KeyStroke;
import javax.swing.event.SwingPropertyChangeSupport;

/**
 * 
 */
public abstract class AbstractShortcut implements Shortcut
{

	private SwingPropertyChangeSupport changeSupport =
		new SwingPropertyChangeSupport(this);
	
	private HashMap<String, Object> values = new HashMap<String, Object>();
	
	/*
	 * @see org.xnap.commons.gui.shortcut.Shortcut#putValue(java.lang.String, java.lang.Object)
	 */
	public void putValue(String key, Object value)
	{
		Object oldValue = null;
		if (values.containsKey(key)) {
			oldValue = values.get(key);
		}
		values.put(key, value);
		firePropertChange(key, oldValue, value);
	}

	protected void firePropertChange(String key, Object oldValue, Object newValue)
	{
		if (oldValue != newValue 
				&& (oldValue == null || newValue == null || !oldValue.equals(newValue))) {
			changeSupport.firePropertyChange(key, oldValue, newValue);
		}
	}

	/*
	 * @see org.xnap.commons.gui.shortcut.Shortcut#getValue(java.lang.String)
	 */
	public Object getValue(String key)
	{
		return  values.get(key);
	}

	/*
	 * @see org.xnap.commons.gui.shortcut.Shortcut#addPropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(PropertyChangeListener l)
	{
		changeSupport.addPropertyChangeListener(l);
	}

	/*
	 * @see org.xnap.commons.gui.shortcut.Shortcut#removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(PropertyChangeListener l)
	{
		changeSupport.removePropertyChangeListener(l);
	}

	/*
	 * @see org.xnap.commons.gui.shortcut.Shortcut#getKeyStroke()
	 */
	public KeyStroke getKeyStroke()
	{
		return (KeyStroke)values.get(KEYSTROKE);
	}

	/*
	 * @see org.xnap.commons.gui.shortcut.Shortcut#setKeyStroke(javax.swing.KeyStroke)
	 */
	public void setKeyStroke(KeyStroke stroke)
	{
		putValue(KEYSTROKE, stroke);
	}
}
