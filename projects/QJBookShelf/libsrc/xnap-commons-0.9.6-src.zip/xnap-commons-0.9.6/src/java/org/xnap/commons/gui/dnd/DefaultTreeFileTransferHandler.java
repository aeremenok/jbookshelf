package org.xnap.commons.gui.dnd;

import java.awt.Component;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JTree;
import javax.swing.tree.TreePath;
import org.xnap.commons.gui.Dialogs;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.io.Job;
import org.xnap.commons.io.JobExecutor;
import org.xnap.commons.io.ProgressMonitor;
import org.xnap.commons.io.SubTaskProgressMonitor;
import org.xnap.commons.settings.BooleanSetting;
import org.xnap.commons.settings.PropertyResource;
import org.xnap.commons.util.FileHelper;

/**
 * Provides a default file transfer handler for {@link JTree}s.
 * <p>
 * When a drag from a tree is initiated all selected paths are collected and
 * their {@link TreePath#getLastPathComponent() last path components}, if
 * they are files, are added to the {@link FileTransferable} that is created.
 * <p>
 * To support dragging of files you have to enable it for the tree, see
 * {@link JTree#setDragEnabled(boolean)}.
 * <p> 
 * When a transferable with files is dropped on the tree, the handler tries to
 * copy the dropped files to the first directory that is selected in the tree. A
 * confirmation dialog is shown before copying if the boolean setting 
 * {@link #getShowCopyDialogSetting()} is true.
 * 
 * @author Felix Berger
 */
public class DefaultTreeFileTransferHandler extends AbstractFileTransferHandler 
{

	private final static I18n i18n = 
		I18nFactory.getI18n(DefaultTreeFileTransferHandler.class);
	
	private BooleanSetting showCopyDialog;
	
	/**
	 * Constructs a file transfer handler for {@link JTree}s.
	 * @param showCopyDialog the boolean setting which decides if a
	 * confirmation dialog is shown before dropped files are copied to the
	 * selected directory in the tree.
	 * 
	 * @throws NullPointerException if <code>showCopyDialog</code> is null.
	 */
	public DefaultTreeFileTransferHandler(BooleanSetting showCopyDialog)
	{
		if (showCopyDialog == null) {
			throw new NullPointerException("showCopyDialog must not be null");
		}
		this.showCopyDialog = showCopyDialog;
	}
	
	/**
	 * Convenience constructor which creates a dummy boolean setting that
	 * says the copy confirmation dialog should not be shown.
	 * <p>
	 * See {@link #DefaultTreeFileTransferHandler(BooleanSetting)} and
	 * {@link Dialogs#showCopyDialog(Component, File[], File, BooleanSetting)}. 
	 */
	public DefaultTreeFileTransferHandler()
	{
		this(new BooleanSetting(new PropertyResource(), "dummy", 
				Boolean.FALSE));
	}
	
	/**
	 * Sets the boolean setting which decides if a confirmation dialog is 
	 * shown before any files are copied.
	 * <p>
	 * See {@link Dialogs#showCopyDialog(Component, File[], File, BooleanSetting)}.
	 * 
	 * @throws NullPointerException if <code>setting</code> is null.
	 */
	public void setShowCopyDialogSetting(BooleanSetting setting)
	{
		if (setting == null) {
			throw new NullPointerException("setting must not be null");
		}
		showCopyDialog = setting;
	}

	/**
	 * Returns the boolean setting which decides if a confirmation dialog
	 * is shown before any files are copied.
	 */
	public BooleanSetting getShowCopyDialogSetting()
	{
		return showCopyDialog;
	}
	
	/**
	 * 
	 * 
	 */
	@Override
	protected Transferable createTransferable(JComponent c) 
	{
		JTree tree = (JTree)c;
		TreePath[] selectedPaths = tree.getSelectionPaths();
		List<File> files = new ArrayList<File>(selectedPaths.length);
		for (TreePath path : selectedPaths) {
			if (path.getLastPathComponent() instanceof File) {
				files.add((File)path.getLastPathComponent());
			}
		}
		if (!files.isEmpty()) {
			return new FileTransferable(files);
		}
		return null;
	}

	/**
	 * Returns <code>false</code> if no directory is selected in the tree 
	 * where the files could be dropped into or the selected file is not an
	 * existent directory. 
	 * <p>
	 * Otherwise <code>files</code> are copied to the specified directory
	 * while a progress dialog is displayed.
	 */
	@Override
	public boolean importFiles(JComponent comp, List<File> files) 
	{
		final JTree tree = (JTree)comp;
		TreePath selectedPath = tree.getSelectionPath();
		if (selectedPath == null) {
			return  false;
		}
		final File dir = (File)selectedPath.getLastPathComponent();
		if (!dir.isDirectory()) {
			return false;
		}
		final File[] filesToCopy = Dialogs.showCopyDialog
			(tree, files.toArray(new File[0]), dir, 
					new BooleanSetting(new PropertyResource(), "dummy", 
							Boolean.TRUE));
		
		try {
			JobExecutor.run(i18n.tr("Copying Files"), new CopyRunner(filesToCopy, dir));
		}
		catch (Exception e) {
			Dialogs.showError(tree, i18n.tr("Error copying files"), e);
		}
		return false;
	}
	
	private class CopyRunner implements Job<Object>
	{
		private File[] files;
		private File targetPath;

		public CopyRunner(File[] files, File targetPath)
		{
			this.files = files;
			this.targetPath = targetPath;
		}

		public Object run(ProgressMonitor monitor) throws Exception
		{
			monitor.setTotalSteps(files.length * 100);
			for (File file : files) {
				File dest = FileHelper.createUnique(targetPath, file.getName());
				monitor.setText(i18n.tr("Copying<br>{0}<br>to<br>{1}...", file, dest));
				FileHelper.copy(file, dest,	new SubTaskProgressMonitor(monitor, 
						100, file.length()));
				if (monitor.isCancelled()) {
					return null;
				}
			}
			return null;
		}
	}
}
