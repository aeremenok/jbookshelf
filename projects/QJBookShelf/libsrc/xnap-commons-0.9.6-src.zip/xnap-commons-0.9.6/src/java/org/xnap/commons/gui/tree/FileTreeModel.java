/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.tree;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.List;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;

public class FileTreeModel extends AbstractTreeModel
{

    private List<Object> subRoots;
    private Hashtable<String,List<FileNode>> subChildren = new Hashtable<String,List<FileNode>>();
    private File cachedDir;
    private boolean cacheSorted;
    private File[] cache;
    private FileComparator comparator;
    private FileFilter filter = new DefaultFilter();
    private boolean sort = true;

    public FileTreeModel(String root, File[] roots)
    {
		super(root);

		if (roots != null) {
			subRoots = new ArrayList<Object>(roots.length);
			for (int i = 0; i < roots.length; i++) {
				addSubRoot(roots[i]);
			}
		}
		else {
			subRoots = new ArrayList<Object>();
		}
    }

    public FileTreeModel(String root)
    {
        this(root, null);
    }

    public boolean isLeaf(Object node)
    {
        return false;
    }

    public int getChildCount(Object node)
    {
		if (node instanceof File && ((File)node).canRead()) {
			return getSubDirs((File)node, false).length;
		} 
		else if (node instanceof String) {
			if (node.equals(root)) {
				return subRoots.size();
			}
			return subChildren.get(node).size();
		}
		else {
			return 0;
		}
    }
    
    public Object getChild(Object parent, int index)
    {
		if (parent instanceof File) {
			File[] children = getSubDirs((File)parent, sort);

			if (index >= children.length) { 
				return null;
			}
			return new FileNode(children[index]);
		} 
		else if (parent instanceof String) {
			if (parent.equals(root) && index < subRoots.size())
				return subRoots.get(index);
	    
			List<FileNode> v = subChildren.get(parent);
			return (index < v.size()) ? v.get(index) : null;
		}
		else {
			return null;
		}
    }
    
    public int getIndexOfChild(Object parent, Object child)
    {
		if (parent instanceof File) {
			File[] children = getSubDirs((File)parent, sort);

			if (children == null) 
				return -1;

			for (int i = 0; i < children.length; i++) {
				if (children[i] == child)
					return i;
			}
		}
		else if (parent instanceof String) {
			if (parent.equals(root)) {
				return subRoots.indexOf(child);
			}
			return ((List)subChildren.get(parent)).indexOf(child);
		}

		return -1; 
    }

    /**
     * Guaranteed to not return null.
     * @param f
     * @param doSort
     * @return
     */
    private File[] getSubDirs(File f, boolean doSort)
    {
		if (f == cachedDir && cacheSorted == doSort)
			return cache;

		File[] children = f.listFiles(filter); 
		if (children == null) {
			cache = new File[0];
		}
		else {
			cache = children;
			if (doSort) {
				Arrays.sort(cache, getComparator());
			}
		}
		cachedDir = f;
		cacheSorted = doSort;
		return cache;
    }

    public void addSubRoot(String name)
    {
		if (subRoots.contains(name))
			return;
	
		subRoots.add(name);
	
		/* add List for children of this node */
		subChildren.put(name, new ArrayList<FileNode>());

		Object[] path = { root };
		int[] indices = { subRoots.size() - 1 };
		Object[] children = { name };
		fireTreeNodesInserted(new TreeModelEvent(this, path, indices,
												 children));
	
    }

    public void addSubRoot(File f)
    {
		if (subRoots.contains(f))
			return;
	
		subRoots.add(f);
	
		Object[] path = { root };
		int[] indices = { subRoots.size() - 1 };
		Object[] children = { f };
		fireTreeNodesInserted(new TreeModelEvent(this, path, indices, 
												 children));
    }

    public void removeSubRoots()
    {
		/* remove respective Lists in hash tree */
		for (int i = 0; i < subRoots.size(); i++)
			subChildren.remove(subRoots.get(i));
	
		subRoots.clear();
	
		Object[] path = { root };
		fireTreeStructureChanged(new TreeModelEvent(this, path));
    }
    
    public void removeChildrenOfSubRoot(String s)
    {
		if (!subRoots.contains(s))
			return;

		subChildren.get(s).clear();
		
		Object[] path = { root, s };
		fireTreeStructureChanged(new TreeModelEvent(this, path));
    }

    public void addChildOfSubRoot(File file, String subRoot)
    {
		addChildOfSubRoot(file, subRoot, null);
    }

    public void addChildOfSubRoot(File file, String subRoot, String label)
    {
		addSubRoot(subRoot);
	
		List<FileNode> children = subChildren.get(subRoot);
		FileNode node = new FileNode(file, true, label);
	
		if (children.contains(node))
			return;
		children.add(node);
		
		fireTreeNodesInserted(new TreeModelEvent(this, 
				new Object[] { root, subRoot },
				new int[]    { children.size() - 1 },
				new Object[] { file }));
    }

    public void removeChildOfSubRoot(File file, String subRoot)
    {
		if (!subRoots.contains(subRoot))
			return;
	    
		List<FileNode> children = subChildren.get(subRoot);
	
		FileNode node = new FileNode(file, true);
		int index = children.indexOf(node);
		if (index == -1)
			return;
		children.remove(index);

		fireTreeNodesRemoved(new TreeModelEvent(this, 
				new Object[] { root, subRoot }, 
				new int[]    { index },		
				new Object[] { node }));
    }

    /**
     * Create comparator lazily.
     */
    private FileComparator getComparator()
    {
    	if (comparator == null) {
    		comparator = new FileComparator();
    	}
    	return comparator;
    }
    
    // raised visibilibity for testing
    static class FileComparator implements Comparator<File>
    {
    
    	public int compare(File o1, File o2)
    	{
    		return o1.getAbsolutePath().compareToIgnoreCase(o2.getAbsolutePath());
    	}
    }

    /**
     * Sets a file filter that is used for listing directories in the tree.
     * <p>
     * The default filter excludes hidden files and files that are not directories.
     * <p>
     * @param filter can be <code>null</code>
     */
	public void setFileFilter(FileFilter filter) 
	{
			this.filter = filter;
	}

	/**
	 * Returns the currently set file filter.
	 * @return can be <code>null</code>
	 */
	public FileFilter getFileFilter() 
	{
		return filter;
	}
	
	private class DefaultFilter implements FileFilter
	{
		public boolean accept(File file)
		{
			return file.isDirectory() && !file.isHidden();
		}
	}

	/**
	 * Sets whether the listed files of a directory should be sorted.
	 * <p>
	 * Fires {@link TreeModelListener#treeStructureChanged(javax.swing.event.TreeModelEvent)}
	 * with the root node as parameter to make sure the whole tree is updated
	 * correctly.
	 * @param sort
	 */
	public void setSortListedFiles(boolean sort) 
	{
		if (this.sort != sort) {
			this.sort = sort;
			fireTreeStructureChanged(new TreeModelEvent(this, new Object[] { getRoot() }));
		}
	}

	/**
	 * Returns whether the listed files of a directory are being sorted. 
	 */
	public boolean getSortListedFiles() 
	{
		return sort;
	}
}
