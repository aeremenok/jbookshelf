/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.awt.event.KeyEvent;
import java.util.StringTokenizer;
import javax.swing.KeyStroke;

/**
 * Provides a setting for <code>KeyStroke</code> objects.
 */
public class KeyStrokeSetting extends AbstractSetting<KeyStroke> {

    public KeyStrokeSetting(SettingResource backend, String key, KeyStroke defaultValue, Validator validator)
    {
    	super(backend, key, defaultValue, validator);
    }

    public KeyStrokeSetting(SettingResource backend, String key, KeyStroke defaultValue)
    {
    	super(backend, key, defaultValue, null);
    }

    protected KeyStroke fromString(String value)
	{
		// this could be way easier but there seems to be no serialize
		// method that can create the format recognized by getKeyStroke()
		//return KeyStroke.getKeyStroke(key);

		StringTokenizer t = new StringTokenizer(value, ARRAY_SEPARATOR);
		if (t.countTokens() >= 3) {
			try {
				int keyCode = Integer.parseInt(t.nextToken());
				int modifiers = Integer.parseInt(t.nextToken());
				Character character = new Character(t.nextToken().charAt(0));
				return (keyCode == KeyEvent.VK_UNDEFINED)
					? KeyStroke.getKeyStroke(character, modifiers)
					: KeyStroke.getKeyStroke(keyCode, modifiers);
			}
			catch (NumberFormatException e) {
			}
		}

		return null;
	}

	protected String toString(KeyStroke value)
	{
		KeyStroke keystroke = (KeyStroke)value;
		
		// encode keystroke
		StringBuilder sb = new StringBuilder();
		sb.append(keystroke.getKeyCode());
		sb.append(ARRAY_SEPARATOR);
		sb.append(keystroke.getModifiers());
		sb.append(ARRAY_SEPARATOR);
		sb.append(keystroke.getKeyChar());
		return sb.toString();
	}

}
