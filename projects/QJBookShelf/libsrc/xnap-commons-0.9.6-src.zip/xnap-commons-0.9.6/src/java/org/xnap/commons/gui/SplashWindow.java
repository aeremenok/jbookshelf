/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JProgressBar;
import javax.swing.JWindow;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import org.xnap.commons.gui.util.GUIHelper;

/**
 * Displays a splash window at the center of the screen.
 * <p>
 * The following colors are used as background and foreground colors:
 * <pre>
 * UIManager.getColor("TextField.background");
 * UIManager.getColor("TextField.foreground");
 * </pre>
 * 
 * @author Steffen Pingel
 */
public class SplashWindow extends JWindow
{

	private static SplashWindow instance = null;
    private JProgressBar progressBar;
	private JLabel statusLabel;
	private JLabel imageLabel;
    private static Object lock = new Object();

    private SplashWindow(String text, Icon icon)
    {
    	Color bg = UIManager.getColor("TextField.background");
    	Color fg = UIManager.getColor("TextField.foreground");

		Box box = new ContainerBox(BoxLayout.Y_AXIS);
		setBackground(bg);
		getContentPane().setBackground(bg);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(box, BorderLayout.CENTER);
		
		imageLabel = new JLabel(text);
		imageLabel.setForeground(fg);
		imageLabel.setIcon(icon);
		imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
		imageLabel.setVerticalAlignment(SwingConstants.CENTER);
		imageLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		imageLabel.setVerticalTextPosition(SwingConstants.BOTTOM);
		imageLabel.setAlignmentX(0.5f);
		box.add(imageLabel);

		progressBar = new JProgressBar(0, 100);
		progressBar.setBackground(Color.white);
		progressBar.setBorder(GUIHelper.createEmptyBorder(5));
		progressBar.setAlignmentX(0.5f);
		box.add(progressBar);

		statusLabel = new JLabel(" ");
		statusLabel.setForeground(fg);
		statusLabel.setFont(new Font("Dialog", Font.PLAIN, 10));
		statusLabel.setHorizontalTextPosition(SwingConstants.CENTER);
		statusLabel.setAlignmentX(0.5f);
		box.add(statusLabel);

		pack();
		centerOnScreen();
		
		// close on mouse click
		addMouseListener(new MouseAdapter() {
				public void mousePressed(MouseEvent event)
				{
					synchronized (lock) {
						lock.notify();
					}
				}
		});
    }

    public void centerOnScreen()
	{
		// center on screen
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension windowSize = getPreferredSize();
		setLocation(screenSize.width / 2 - (windowSize.width / 2),
					screenSize.height / 2 - (windowSize.height / 2));
	}

	public static SplashWindow createInstance(String text, Icon icon)
    {
    	if (instance == null) {
			instance = new SplashWindow(text, icon);
    	}
    	return instance;
    }
    
    /**
     * The splash window will be closed automatically after 
     * <code>timeout</code> milli seconds.
     * 
     * @param timeout automatic closing will be disabled, if less or equal
     *                than 0
     */
    public static void showSplashWindow(String text, Icon icon, final long timeout)
    {
    	createInstance(text, icon).show(timeout);
    }

    /**
     * Closes the window if shown on screen.
     */
    public static void closeSplashWindow()
    {
		if (instance != null) {
			synchronized (lock) {
				lock.notify();
			}
		}
    }	

    public static SplashWindow getInstance()
    {
    	return instance;
    }
        
	public JProgressBar getProgressBar()
	{
		return progressBar;
	}

	public JLabel getStatusLabel()
	{
		return statusLabel;
	}
    
	public JLabel getImageLabel()
	{
		return imageLabel;
	}
	
    /**
     * 
     */
    public static int getProgress()
    {
		return (instance != null) ? instance.progressBar.getValue() : 0;
    }

    /**
     * Increases the progress by <code>delta</code> percent and sets the 
     * status text to <code>newValue</code>.
     */
    public static void incProgress(int delta, String text)
    {
		if (instance != null) {
			incProgress(delta);
			setText(text);
		}
    }
    
    /**
     * Increases the progress by <code>delta</code> percent.
     */
    public static void incProgress(int delta)
    {
		if (instance != null) {
			instance.progressBar.setValue(instance.progressBar.getValue() + delta);
		}
    }

    /**
     * Sets the progress to <code>progress</code> and the status text to
     * <code>text</code>.
     */
    public static void setProgress(int progress, String text)
    {
		setProgress(progress);
		setText(text);
    }

    /**
     * Sets the progress to <code>newValue</code> percent.
     */
    public static void setProgress(int newValue)
    {
		if (instance != null) {
			instance.progressBar.setValue(newValue);
		}
    }

    /**
     * Sets the status text to <code>newValue</code>.
     */
    public static void setText(String newValue)
    {
		if (instance != null) {
			instance.statusLabel.setText(newValue);
		}
    }

    public void show(long timeout)
    {
    	Thread t = new Thread(new CloseRunner(timeout), "SplashWindowWaiter");
    	t.start();
   		
   		setVisible(true);
	}
    
	public static void updateComponentTree()
	{
		if (instance != null) {
			SwingUtilities.updateComponentTreeUI(instance);
		}
	}

	public static class CloseRunner implements Runnable
	{
		long timeout;

		public CloseRunner(long timeout)
		{
			this.timeout = timeout;
		}

		public void run()
		{
			try {
				synchronized (lock) {
					if (timeout > 0) {
						lock.wait(timeout);
					}
					else {
						lock.wait();
					}
				}
			}
			catch(InterruptedException e) {
			}
			
			Runnable runner = new Runnable()
				{
					public void run()
					{
						instance.setVisible(false);
						instance.dispose();
						instance = null;
					}
				};
			SwingUtilities.invokeLater(runner);
		}
	}
	/**
	 * Inner subclass of Box to override updateUI. 
	 */
	private class ContainerBox extends Box
	{
		public ContainerBox(int axis)
		{
			super(axis);
		}
		
		@Override
		public void updateUI() 
		{
			super.updateUI();
	    	Color bg = UIManager.getColor("TextField.background");
	    	Color fg = UIManager.getColor("TextField.foreground");
	    	
			SplashWindow.this.setBackground(bg);
			getContentPane().setBackground(bg);
			imageLabel.setForeground(fg);
			statusLabel.setForeground(fg);
			statusLabel.setBackground(bg);
		}
	}
}
