/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.CardLayout;
import java.awt.Component;
import java.awt.Container;
import javax.swing.DefaultListModel;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.ListCellRenderer;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * This class provides a tabbed pane like behaving widget. The 
 * <code>IconSplitPane</code> is split up in two parts. The left part is a
 * {@link javax.swing.JList JList} that contains icons and their descriptions.
 * The right part can be any component. If the user selects on of the icons
 * from the list the respective panel is show at the right.
 *
 * <p>The names of the methods are modelled after the 
 * {@link javax.swing.JTabbedPane JTabbedPane}.
 * 
 * TODO add ComponentOrientation support
 * TODO show empty icon instead of no icon? to separated list entries
 */
public class IconSplitPane extends JSplitPane
{

    private JList iconList;
    private DefaultListModel iconListModel;
    private CardLayout containerLayout;
    private Container container;
    private transient ChangeEvent changeEvent = null;

    public IconSplitPane()
    {
		super(JSplitPane.HORIZONTAL_SPLIT);

		initialize();
    }

    private void initialize() 
    {
		setOneTouchExpandable(true);

		iconList = new JList();
		iconListModel = new DefaultListModel();
		iconList.setModel(iconListModel);
		iconList.addListSelectionListener(new IconListener());
		iconList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		iconList.setCellRenderer(new IconRenderer());

		JScrollPane jspIcons = new JScrollPane(iconList);
		jspIcons.setHorizontalScrollBarPolicy
			(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		add(jspIcons, JSplitPane.LEFT);

		containerLayout = new CardLayout();
		container = new Container();
		container.setLayout(containerLayout);
		add(container, JSplitPane.RIGHT);
    }

    /**
     * Adds a new tab.
     */
    public void addTab(String description, Icon icon, Component c) 
    {
		insertTab(description, icon, c, iconListModel.size());
    }

    /**
     * Inserts a new tab at <code>index</code>.
     */
    public void insertTab(String description, Icon icon, Component c, 
						  int index) 
    {
		if (icon != null) {
			if (icon instanceof ImageIcon) {
				((ImageIcon)icon).setDescription(description);
			}
			iconListModel.insertElementAt(icon, index);
		}
		else {
			iconListModel.insertElementAt(description, index);
		}

		container.add(c, description, index);
		setDividerLocation(iconList.getPreferredSize().width + 30);

		if (iconListModel.size() == 1) {
			iconList.setSelectedIndex(0);
			//setDividerLocation(jlIcons.getPreferredSize().width * 2);
		}
		else if (iconList.getSelectedIndex() >= index) {
			iconList.setSelectedIndex(iconList.getSelectedIndex() + 1);
		}
    }

    /**
     * Returns all tabs as an array.
     */
    public Component[] getTabs()
    {
		return container.getComponents();
    }

    /**
     * Returns the tab at index <code>i</code>.
     */
    public Component getTabAt(int i)
    {
		return container.getComponents()[i];
    }

    /**
     * Returns the number of tabs.
     */
    public int getTabCount()
    {
		return container.getComponentCount();
    }

    /**
     * Returns the description at index <code>i</code>.
     */
    public String getDescriptionAt(int i)
    {
		Object o = iconListModel.get(i);
		if (o != null) {
			if (o instanceof ImageIcon) {
				return ((ImageIcon)o).getDescription();
			}
			return o.toString();
		}

		return null;
    }

    /**
     * Returns the icon at index <code>i</code>.
     */
    public Icon getIconAt(int i)
    {
		Object o = iconListModel.get(i);
		if (o instanceof Icon) {
			return (Icon)o;
		}
		else {
			return null;
		}
    }

    /**
     * Returns the title at index <code>i</code>.
     */
    public String getTitleAt(int i)
    {
		return iconListModel.get(i).toString();
    }

    /**
     * Sets the icon at index <code>i</code> to <code>icon</code>.
     */
    public void setIconAt(int i, Icon icon)
    {
		if (icon != null) {
			if (icon instanceof ImageIcon) {
				((ImageIcon)icon).setDescription(getDescriptionAt(i));
			}

			iconListModel.set(i, icon);
		}
    }

    /**
     * Returns the <code>index</code> of the currently selected tab.
     */
    public int getSelectedIndex()
    {
		return iconList.getSelectedIndex();
    }

    /**
     * Selects <code>c</code>. The corresponding icon will also be selected.
     */
    public void setSelectedComponent(Component c)
    {
		int i = indexOfComponent(c);
		if (i != -1) {
			iconList.setSelectedIndex(i);
		}
    }

    /**
     * Returns the index of <code>c</code>.
     */
    public int indexOfComponent(Component c)
    {
		int count = container.getComponentCount();
		for (int i = 0; i < count; i++) {
			if (container.getComponent(i) == c) {
				return i;
			}
		}

		return -1;
    }

    /**
     * Removes tab <code>c</code>.
     */
    public void remove(Component c)
    {
		if (container == null)
			return;

		int i = indexOfComponent(c);
		if (i != -1) {
			removeTabAt(i);
		}
    }

    /**
     * Removes tab at index <code>i</code>.
     */
    public void removeTabAt(int i)
    {
		if (i == iconList.getSelectedIndex()) {
			iconList.setSelectedIndex(0);
		}
		container.remove(i);
		iconListModel.remove(i);
    }

    /**
     * Adds a listener that gets notified when a tab is selected.
     */
    public void addChangeListener(ChangeListener l) 
    {
        listenerList.add(ChangeListener.class, l);
    }

    /**
     * Removes a <code>ChangeListener</code>.
     *
     * @param l the ChangeListener to remove
     * @see #fireStateChanged
     * @see #addChangeListener
     */
    public void removeChangeListener(ChangeListener l) {
        listenerList.remove(ChangeListener.class, l);
    }

    /**
     * Send a <code>ChangeEvent</code>, whose source is this tabbedpane, to
     * each listener.  This method method is called each time
     * a <code>ChangeEvent</code> is received from the model.
     *
     * @see #addChangeListener
     */
    protected void fireStateChanged() {
        // Guaranteed to return a non-null array
        Object[] listeners = listenerList.getListenerList();
        // Process the listeners last to first, notifying
        // those that are interested in this event
        for (int i = listeners.length-2; i>=0; i-=2) {
            if (listeners[i]==ChangeListener.class) {
                // Lazily create the event:
                if (changeEvent == null)
                    changeEvent = new ChangeEvent(this);
                ((ChangeListener)listeners[i+1]).stateChanged(changeEvent);
            }
        }
    }

    /**
     * Returns the currently selected tab.
     */
    public Component getSelectedComponent()
    {
		return container.getComponent(iconList.getSelectedIndex());
    }

    /**
     * Listens for icon selection events.
     */
    private class IconListener implements ListSelectionListener
    {

		public void valueChanged(ListSelectionEvent e)
		{
			int index = iconList.getSelectedIndex();
			if (index != -1) {
				String description = null;
				Object o = iconListModel.elementAt(index);
				if (o instanceof ImageIcon)
					description = ((ImageIcon)o).getDescription();
				else if (o instanceof String)
					description = (String)o;
				containerLayout.show(container, description);
				fireStateChanged();
			}
		}

    }

    /**
     * Renders the icons in the <code>JList</code>.
     */
    private class IconRenderer extends JLabel implements ListCellRenderer 
    {

		public IconRenderer() 
		{
			this.setOpaque(true);
			this.setHorizontalAlignment(CENTER);
			this.setVerticalAlignment(CENTER);
			this.setHorizontalTextPosition(CENTER);
			this.setVerticalTextPosition(SwingConstants.BOTTOM);
			this.setBorder(new EmptyBorder(5, 5, 5, 5));
		}

		public Component getListCellRendererComponent(JList list, Object value,
													  int index,
													  boolean isSelected,
													  boolean cellHasFocus)
		{
			if (isSelected) {
				this.setBackground(list.getSelectionBackground());
				this.setForeground(list.getSelectionForeground());
			} 
			else {
				this.setBackground(list.getBackground());
				this.setForeground(list.getForeground());
			}

			this.setText(null);
			this.setIcon(null);

			if (value instanceof ImageIcon) {
				ImageIcon icon = (ImageIcon)value;
				this.setText(icon.getDescription());
				this.setIcon(icon);
			}
			else if (value instanceof String) {
				this.setText((String)value);
//				this.setIcon(IconHelper.getEmptyIcon(32));
			}

			return this;
		}

    }   

}
