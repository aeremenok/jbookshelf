/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.util;

import java.io.IOException;
import java.net.ConnectException;
import java.net.UnknownHostException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * Provides a set of static methods for common network tasks.
 */
public class NetHelper {

	private static final I18n i18n = I18nFactory.getI18n(NetHelper.class);
    private static final Log logger = LogFactory.getLog(NetHelper.class);

    /**
     * Enables the use of a socks proxy at <code>host:port</code>. 
     *
     * @param host hostname of the proxy
     * @param port port of the proxy
     */
    public static void enableSocksProxy(String host, int port) 
    {
		logger.debug("Enabling socks proxy: " + host + ":" + port);

        System.getProperties().put("socksProxySet", "true");
        System.getProperties().put("socksProxyHost", host);
        System.getProperties().put("socksProxyPort", port + "");
    }

    /**
     * Disables the use of a socks proxy.
     */ 
    public static void disableSocksProxy() 
    {
		logger.debug("Disabling socks proxy");

        System.getProperties().remove("socksProxySet");
        System.getProperties().remove("socksProxyHost");
        System.getProperties().remove("socksProxyPort");
    }

    /**
     * Enables the use of a http proxy at <code>host:port</code>. 
     *
     * @param host hostname of the proxy
     * @param port port of the proxy
     */
    public static void enableHttpProxy(String host, int port) 
    {
		logger.debug("Enabling http proxy: " + host + ":" + port);

        System.getProperties().put("proxySet", "true");
        System.getProperties().put("proxyHost", host);
        System.getProperties().put("proxyPort", port + "");
    }

    /**
     * Disables the use of a http proxy.
     */ 
    public static void disableHttpProxy() 
    {
		logger.debug("Disabling http proxy");

        System.getProperties().remove("proxySet");
        System.getProperties().remove("proxyHost");
        System.getProperties().remove("proxyPort");
    }

    /**
     * Returns a sensible error message.
     */
    public static String getErrorMessage(IOException e)
    {
		String message = e.getLocalizedMessage();
		if (e instanceof ConnectException) {
			return i18n.tr("Connection refused");
		}
		else if (e instanceof UnknownHostException) {
			return i18n.tr("Unknown host {0}", 
						   (message != null) ? message : "");
		}
		else {
			return i18n.tr("Error ({0})", 
						   (message != null) ? message : e.toString());
		}
    }

	public static long ipToLongHiFirst(byte[] address)
	{
        if (address.length != 4) {
            throw new IllegalArgumentException("byte array must be of length 4");
        }

        long ipNum = 0;
        long multiplier = 1;
        for (int i = 3; i >= 0; i--) {
            int byteVal = (address[i] + 256) % 256;
            ipNum += byteVal * multiplier;
            multiplier *= 256;
        }
        return ipNum;
	}

    /**
     * Converts <code>ip</code> from an integer value to a dotted string
     * representation.
     */
    public static String toIPAddressLittleEndian(long ip)
    {
		StringBuilder sb = new StringBuilder(4 * 3 + 3);
	
		sb.append(ip & 0xFF);
		sb.append(".");
		sb.append((ip >> 8) & 0xFF);
		sb.append(".");
		sb.append((ip >> 16) & 0xFF);
		sb.append(".");
		sb.append((ip >> 24) & 0xFF);

		return sb.toString();
    }

    /**
     * Converts <code>ip</code> from an integer value to a dotted string
     * representation.
     */
    public static String toIPAddressBigEndian(long ip)
    {
		StringBuilder sb = new StringBuilder(4 * 3 + 3);
	
		sb.append((ip >> 24) & 0xFF);
		sb.append(".");
		sb.append((ip >> 16) & 0xFF);
		sb.append(".");
		sb.append((ip >> 8) & 0xFF);
		sb.append(".");
		sb.append(ip & 0xFF);

		return sb.toString();
    }

}
