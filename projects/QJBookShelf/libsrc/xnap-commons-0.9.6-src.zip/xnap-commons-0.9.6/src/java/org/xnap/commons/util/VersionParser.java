/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.util;

import java.util.StringTokenizer;

/**
 * This class can parse an compare (software) versions.
 */
public class VersionParser implements Comparable {
    
    private String version;
    /**
     * Constructs a new version parser that parses <code>version</code>.
     */
    public VersionParser(String version) 
    {
		this.version = version;
    }

    /**
     * Compares version <code>v1</code> with version <code>v2</code>.
     *
     * @return 1, if v1 is more recent; 0, if v1 is equal to v2; -1, if v2
     *         is more recent
     * @see #compareTo(Object)
     */
    public static int compare(String v1, String v2) 
    {
		int result = (new VersionParser(v1)).compareTo(new VersionParser(v2));
		return result;
    }

    /**
     * Compares this VersionParser to <code>o</code>.
     *
     * @return 1, if v1 is more recent; 0, if v1 is equal to v2; -1, if v2
     *         is more recent
     */
    public int compareTo(Object o) 
    {
		VersionParser vp = (VersionParser)o;

		StringTokenizer left = new StringTokenizer(version, ".-_: ");
		StringTokenizer right = new StringTokenizer(vp.version, ".-_: ");

		int result = 0;
		while (result == 0) {
			// check if one version is longer than the other one
			if (!left.hasMoreTokens() && !right.hasMoreTokens()) {
				return 0;
			}
			else if (!right.hasMoreTokens()) {
				return 1;
			}
			else if (!left.hasMoreTokens()) {
				return -1;
			}

			result = compareTokens(left.nextToken(), right.nextToken());
		}
		return result;
    }

	private static int compareTokens(String left, String right)
	{
		int leftNumber = getNumberPrefix(left);
		int rightNumber = getNumberPrefix(right);

		int result = leftNumber - rightNumber;
		if (result != 0) {
			return result;
		}

		return left.compareTo(right);
	}

	private static int getNumberPrefix(String s)
	{
		int i = 0;
		while (i < s.length() && s.charAt(i) >= '0' && s.charAt(i) <= '9') {
			i++;
		}
		return (i > 0) ? Integer.parseInt(s.substring(0, i)) : -1;
	}

    public String toString()
    {
		return version;
    }

}

