/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.dnd;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

/**
 * Implements the {@link Transferable} interface for files thereby supporting
 * the flavors {@link DataFlavor#javaFileListFlavor} and 
 * {@link org.xnap.commons.gui.dnd.AbstractFileTransferHandler#linuxURIFlavor}.
 * 
 * @author Felix Berger
 */
public class FileTransferable implements Transferable 
{
	private final List<File> files;
	
	/**
	 * Constructs a transferable for a list of files.
	 * <p>
	 * The list is not copied, so it should not be modified from the outside.
	 *
	 * @param files list of files to be transferred, must not be <code>null</code>
	 * 
	 * @throws NullPointerException if <code>files</code> is null
	 */
	public FileTransferable(List<File> files)
	{
		if (files == null) {
			throw new NullPointerException("files must not be null");
		}
		this.files = files;
	}
	
	public DataFlavor[] getTransferDataFlavors() 
	{
		return new DataFlavor[] { 
				DataFlavor.javaFileListFlavor, 
				AbstractFileTransferHandler.linuxURIFlavor 
		};
	}

	public boolean isDataFlavorSupported(DataFlavor flavor) 
	{
		return DataFlavor.javaFileListFlavor.equals(flavor) 
			|| AbstractFileTransferHandler.linuxURIFlavor.equals(flavor);
	}

	public Object getTransferData(DataFlavor flavor)
			throws UnsupportedFlavorException, IOException {
		if (DataFlavor.javaFileListFlavor.equals(flavor)) {
			return files;
		}
		else if (AbstractFileTransferHandler.linuxURIFlavor.equals(flavor)) {
			StringBuilder sb = new StringBuilder();
			String lineSep = System.getProperty("line.separator");
			for (Iterator<File> i = files.iterator(); i.hasNext();) {
				File file = i.next();
				URL url = file.toURL();
				if (sb.length() > 0) {
					sb.append(lineSep);
				}
				sb.append(url.toExternalForm());
			}
			return sb.toString();
		}
		else {
			throw new UnsupportedFlavorException(flavor);
		}
	}

}
