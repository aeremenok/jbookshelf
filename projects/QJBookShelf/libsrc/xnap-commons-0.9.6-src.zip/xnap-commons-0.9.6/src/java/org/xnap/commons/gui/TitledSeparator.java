package org.xnap.commons.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;

public class TitledSeparator extends JPanel {
    
    public TitledSeparator(String title, int alignment) {
    	// TODO rewrite this
    	setLayout(new BorderLayout());
    	add(new JSeparator(), BorderLayout.CENTER);
    	JLabel label = new JLabel(title);
    	label.setFont(new Font("Dialog", Font.BOLD, 14));
    	label.setForeground(Color.blue);
    	add(label, BorderLayout.EAST);
    }

}
