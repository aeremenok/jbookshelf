/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.SwingUtilities;
import org.xnap.commons.gui.util.GUIHelper;
import org.xnap.commons.io.ProgressMonitor;

/**
 * A simple progress dialog that displays text in a {@link javax.swing.JLabel}
 * and a {@link javax.swing.JProgressBar}. The dialog can be used to monitor 
 * long running operations.
 * 
 * @author Steffen Pingel
 * 
 * @see org.xnap.commons.io.ProgressMonitor
 */
public class ProgressDialog extends DefaultDialog implements ProgressMonitor {

	public static final int MAX_VALUE = 1000;
	
	private boolean isCancelled = false;
	private JPanel panel;
    private JProgressBar progressBar;
    private JLabel statusLabel;
	private boolean disposed = false;
	private long value;
	private long totalSteps;

    public ProgressDialog(JDialog owner, int buttons, String title) 
    {
		super(owner, buttons);

		initialize();
		
        setTitle(title);
    }

    public ProgressDialog(JFrame owner, int buttons, String title) 
    {
		super(owner, buttons);

		initialize();
		
        setTitle(title);
    }

    public ProgressDialog(int buttons, String title) 
    {
		super(buttons);

		initialize();
		
        setTitle(title);
    }

	public ProgressDialog(JDialog owner, String title)
	{
		this(owner, BUTTON_CANCEL, title);
	}

	public ProgressDialog(JFrame owner, String title)
	{
		this(owner, BUTTON_CANCEL, title);
	}

	public ProgressDialog(String title)
	{
		this(BUTTON_CANCEL, title);
	}

    public ProgressDialog(int buttons) 
    {
		super(buttons);

		initialize();
    }

	public ProgressDialog(JDialog owner)
	{
		this(owner, BUTTON_CANCEL, null);
	}

	public ProgressDialog(JFrame owner)
	{
		this(owner, BUTTON_CANCEL, null);
	}

	public ProgressDialog()
	{
		this(BUTTON_CANCEL);
	}
	
	private void initialize()
	{
		setModal(true);

		panel = new JPanel(new BorderLayout());

		// status
		statusLabel = new JLabel(GUIHelper.tt("&nbsp;"));
		statusLabel.setBorder(BorderFactory.createEmptyBorder(5, 0, 5, 0));
		panel.add(statusLabel, BorderLayout.CENTER);

		// progress
		progressBar = new JProgressBar();
		progressBar.setMinimum(0);
		progressBar.setMaximum(MAX_VALUE);
		progressBar.setValue(0);
		panel.add(progressBar, BorderLayout.SOUTH);

		setMainComponent(panel);
		pack();
	}

	/**
	 * Sets the cancelled status to true.
	 */
	public void close()
	{
		getCancelAction().setEnabled(false);
		isCancelled = true;
	}
    
	/**
	 * Disposes the dialog.
	 */
	public void done()
	{
		Runnable r = new Runnable()
			{
				public void run()
				{
					if (isVisible()) {
						dispose();
					}
					else {
						disposed = true;
					}
				}
			};
		SwingUtilities.invokeLater(r);		
	}
	
	public JPanel getPanel()
	{
		return panel;
	}

	public boolean isCancelled()
	{
		return isCancelled;
	}

	public long getValue()
	{
		return value;
	}
	
    public void setCancelEnabled(final boolean enabled)
    {
		Runnable r = new Runnable()
			{
				public void run()
				{
					getCancelAction().setEnabled(enabled);
				}
			};
		SwingUtilities.invokeLater(r);
    }

    public void setTotalSteps(final long max)
    {
		this.totalSteps = max;
    }

    public void setValue(final long value)
    {
		this.value = value;
		final double percent = (double)this.value / totalSteps;
		Runnable r = new Runnable()
			{
				public void run()
				{
					progressBar.setValue((int)(percent * MAX_VALUE));
				}
			};
		SwingUtilities.invokeLater(r);
    }

    public void work(final long amount)
    {
		this.value += amount;
		final double percent = (double)this.value / totalSteps;
		Runnable r = new Runnable()
			{
				public void run()
				{
					progressBar.setValue((int)(percent * MAX_VALUE));
				}
			};
		SwingUtilities.invokeLater(r);
    }

    public void setText(final String text)
    {
		Runnable r = new Runnable()
			{
				public void run()
				{
					statusLabel.setText(GUIHelper.tt(text));
					pack();
				}
			};
		SwingUtilities.invokeLater(r);
    }

	public void showDialog()
	{
		if (disposed) {
			disposed = false;
			return;
		}
		super.setVisible(true);
	}

	public Component getComponent()
	{
		return this;
	}

}
