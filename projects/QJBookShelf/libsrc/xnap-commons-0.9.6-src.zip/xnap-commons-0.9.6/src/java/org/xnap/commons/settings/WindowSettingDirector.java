/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.awt.Window;

/**
 * @author Steffen Pingel 
 */
public class WindowSettingDirector
{

	private IntSetting xSetting;
	private IntSetting ySetting;
	private IntSetting widthSetting;
	private IntSetting heightSetting;
	
	public WindowSettingDirector(SettingResource backend, String key, 
			int defaultX, int defaultY, int defaultWidth, int defaultHeight)
	{
		xSetting = new IntSetting(backend, key + ".x", defaultX);
		ySetting = new IntSetting(backend, key + ".y", defaultY);
		widthSetting = new IntSetting(backend, key + ".width", defaultWidth);
		heightSetting = new IntSetting(backend, key + ".height", defaultHeight);
	}

	public WindowSettingDirector(SettingResource backend, String key)
	{
		this(backend, key, 0, 0, 0, 0);
	}
	
	public void save(Window window) {
		xSetting.setValue(window.getX());
		ySetting.setValue(window.getY());
		widthSetting.setValue(window.getWidth());
		heightSetting.setValue(window.getHeight());
	}

	public void restore(Window window) {
		window.setLocation(xSetting.getValue(), ySetting.getValue());
		window.setSize(widthSetting.getValue(), heightSetting.getValue());
	}

}
