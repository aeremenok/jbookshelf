/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.awt.Color;

/**
 * Provides a setting for <code>Color</code> objects.
 */
public class ColorSetting extends AbstractSetting<Color> {

    public ColorSetting(SettingResource backend, String key, Color defaultValue, Validator validator)
    {
    	super(backend, key, defaultValue, validator);
    }

    public ColorSetting(SettingResource backend, String key, Color defaultValue)
    {
    	super(backend, key, defaultValue, null);
    }

    protected Color fromString(String value)
	{
		int val = Integer.parseInt(value);
		return new Color(val & 0xFF, (val >> 8) & 0xFF, (val >> 16) & 0xFF);
	}

	protected String toString(Color value)
	{
		Color color = (Color)value;
		int c = color.getRed() 
			| color.getGreen() << 8 
			| color.getBlue() << 16;
		return c + "";
	}

}
