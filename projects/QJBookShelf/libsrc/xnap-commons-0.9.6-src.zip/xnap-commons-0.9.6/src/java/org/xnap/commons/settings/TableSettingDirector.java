/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import org.xnap.commons.gui.table.SortableModel;
import org.xnap.commons.gui.table.TableLayout;
import org.xnap.commons.gui.table.TableLayoutListener;


/**
 * @author Steffen Pingel 
 */
public class TableSettingDirector implements TableLayoutListener
{

	private EnumSetting<SortableModel.Order> sortOrderSetting;
	private IntSetting sortedColumnSetting;
	private IntArraySetting columnWidthsSetting;
	private StringArraySetting visibleColumnsSetting;
	private BooleanSetting maintainSortOrderSetting;
	private TableLayout tableLayout;
	
	public TableSettingDirector(SettingResource backend, String key, TableLayout tableLayout)
	{
		setTableLayout(tableLayout);
		
		columnWidthsSetting = new IntArraySetting(backend, "table." + key + ".columnWidths", null);
		sortOrderSetting = new EnumSetting<SortableModel.Order>(backend, "table." + key + ".sortOrder", SortableModel.Order.UNSORTED);
		sortedColumnSetting = new IntSetting(backend, "table." + key + ".sortedColumn", -1);
		visibleColumnsSetting = new StringArraySetting(backend, "table." + key + ".visibleColumns", new String[0]);
		maintainSortOrderSetting = new BooleanSetting(backend, "table." + key + ".maintainSortOrder", false);
	}
	
	public TableSettingDirector(SettingResource backend, String key)
	{
		this(backend, key, null);
	}
	
	public TableSettingDirector setDefaults(String[] visibleColumns) 
	{
		visibleColumnsSetting.setDefaultValue(visibleColumns);
		return this;
	}
	
	public void setTableLayout(TableLayout tableLayout) 
	{
		if (this.tableLayout != null) {
			this.tableLayout.removeTableLayoutListener(this);
		}
		this.tableLayout = tableLayout;
		if (this.tableLayout != null) {
			this.tableLayout.addTableLayoutListener(this);
		}
	}

	public void restore(TableLayout tableLayout)
	{
		for (int i = 0; i < tableLayout.getColumnCount(); i++) {
			tableLayout.setColumnVisible(i, false);
		}
		String[] visibleColumns = visibleColumnsSetting.getValue();
		tableLayout.setAllColumnsVisible(false);
		boolean visible = false;
		for (int i = 0; i < visibleColumns.length; i++) {
			int index = tableLayout.getColumnIndex(visibleColumns[i]);
			if (index != -1) {
				tableLayout.setColumnVisible(index, true);
				visible = true;
			}
		}
		if (!visible && tableLayout.getColumnCount() > 0) {
			// make sure at least a single column is visible
			tableLayout.setColumnVisible(0, true);
		}
		
		Integer[] columnWidths = columnWidthsSetting.getValue();
		if (columnWidths != null) {
			for (int i = 0; i < columnWidths.length && i < tableLayout.getColumnCount(); i++) {
				tableLayout.getColumnAt(i).setPreferredWidth(columnWidths[i]);
				tableLayout.getColumnAt(i).setWidth(columnWidths[i]);			
			}
		}
		
		int column = sortedColumnSetting.getValue();
		if (column >= 0 && column < tableLayout.getColumnCount()) {	
			tableLayout.sortByColumn(sortedColumnSetting.getValue(),
					sortOrderSetting.getValue(), false);
		}
		
		tableLayout.setMaintainSortOrder(maintainSortOrderSetting.getValue());
	}
	
	public void restore() {
		restore(tableLayout);
	}
	
	public void save(TableLayout tableLayout) 
	{
		Integer[] widths = new Integer[tableLayout.getColumnCount()];
		int visibleColumnsCount = 0;
		for (int i = 0; i < widths.length; i++) {
			widths[i] = tableLayout.getColumnAt(i).getWidth();
		}
		columnWidthsSetting.setValue(widths);

		String[] visibleColumns = new String[tableLayout.getVisibleColumnsCount()];
		for (int i = 0; i < visibleColumns.length; i++) {
			visibleColumns[i] = tableLayout.getTable().getColumnModel().getColumn(i).getIdentifier().toString();
		}
		visibleColumnsSetting.setValue(visibleColumns);
		
		sortOrderSetting.setValue(tableLayout.getSortOrder());
		sortedColumnSetting.setValue(tableLayout.getSortedColumn());
		
		maintainSortOrderSetting.setValue(tableLayout.getMaintainSortOrder());
	}
	
	public void save() {
		save(tableLayout);
	}
	
	public void columnLayoutChanged()
	{
		save();
	}

	public void sortedColumnChanged()
	{
		save();
	}

	public void columnOrderChanged()
	{
		save();
	}

	public void columnNameChanged(int index, String newName)
	{
		// does not concern us as this is the user visible name, not the identifier
	}

	public void columnVisibilityChanged(int index, boolean visible)
	{
		save();
	}

	public void maintainSortOrderChanged(boolean newValue)
	{
	}
	
}
