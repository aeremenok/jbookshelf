/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.util;

import java.awt.Component;
import java.awt.Container;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.NoSuchElementException;
import javax.swing.JMenu;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JViewport;

/**
 * Provides an iterator that traverses a component's hierarchy in preorder. 
 * 
 * @author Steffen Pingel
 */
public class ComponentIterator implements Iterator<Component> {

	private LinkedList<Component> stack = new LinkedList<Component>();
	private Component lookAhead = null;
	
	/**
	 * Iterate over hierarchy of <code>component</code>. First call to next
	 * will return <code>component</code>.
	 */
	public ComponentIterator(Component component)
	{
		stack.add(component);
	}

	/**
	 *  Not supported.
	 *  
	 *  @throws UnsupportedOperationException
	 */
	public void remove()
	{
		throw new UnsupportedOperationException();
	}

	public boolean hasNext()
	{
		if (lookAhead == null) {
			lookAhead = findNext();
		}
		return lookAhead != null;
	}

	public Component next()
	{
		if (lookAhead == null) {
			lookAhead = findNext();
			if (lookAhead == null) {
				throw new NoSuchElementException();
			}
		}
		Component result = lookAhead;
		lookAhead = null;
		return result;
	}

	private Component findNext()
	{
		while (!stack.isEmpty()) {
			Component c = (Component)stack.removeLast();
			if (c instanceof JMenu) {
				c = ((JMenu)c).getPopupMenu();
			}
			else if (c instanceof JScrollPane) {
				c = ((JScrollPane)c).getViewport();
			}
			if (c instanceof JPanel 
				|| c instanceof JPopupMenu
				|| c instanceof JViewport) {
				
				for (int i = ((Container)c).getComponentCount() - 1; i >= 0; i--) {
					Component component = ((Container)c).getComponent(i);
					stack.addLast(component);
				}
			}
			else {
				return c;
			}
		}
		return null;
	}

}
