/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.util;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.StringTokenizer;
import org.xnap.commons.settings.PortRangeValidator;

/**
 * Provides a data container for port ranges. All methods make sure
 * that only valid ports are added.
 *
 * @see org.xnap.commons.settings.PortRangeValidator 
 */
public class PortRange {

    public static final int MIN_PORT = 1;
    public static final int MAX_PORT = 65535;

	/**
	 * The set of valid ports.
	 */
    private Set<Integer> list = new LinkedHashSet<Integer>();
    
    public PortRange(int first, int last) 
    {
		add(first, last);
    }

    public PortRange(String range)
    {
		add(range);
    }

    public PortRange()
    {
    }

    /**
     * Adds all ports that are <code>first</code> <= port <= <code>last</code>.
     */
    public void add(int first, int last)
    {
		if (first < MIN_PORT || first > MAX_PORT) {
			throw new IllegalArgumentException();
		}
		if (last < MIN_PORT || last > MAX_PORT) {
			throw new IllegalArgumentException();
		}
		if (first > last) {
			throw new IllegalArgumentException("first must be smaller than or equal to last (" + first + ">" + last + ")");
		}

		for (int i = first; i <= last; i++) {
			list.add(i);
		}
    }

    /**
     * Adds <code>port</code> to the range.
     */
    public void add(int port)
    {
		if (port < MIN_PORT || port > MAX_PORT) {
			throw new IllegalArgumentException();
		}
		
		list.add(new Integer(port));
    }

    /**
     * Adds a range as a string.
     *
     * @see PortRangeValidator
     */
    public void add(String range)
    {
		StringTokenizer t = new StringTokenizer(range, ";");
		while (t.hasMoreTokens()) {
			String ports = t.nextToken().trim();

			if (ports.length() == 0) {
				continue;
			}

			try {
				if (ports.indexOf("-") != -1) {
					StringTokenizer u = new StringTokenizer(ports, "-");
					if (u.countTokens() == 2) {
						add(Integer.parseInt(u.nextToken()),
							Integer.parseInt(u.nextToken()));
					}
				}
				else {
					add(Integer.parseInt(ports));
				}
			}
			catch (NumberFormatException e) {
			}
		}
    }

    /**
     * Tries to bind random ports from the range and returns the 
     * {@link ServerSocket} object if successful. 
     *
     * @return null, if no port could be bound
     */
    public ServerSocket bindRandom()
    {
		// bind to next free port
		for (Iterator<Integer> it = randomIterator(); it.hasNext();) {
			try {
				return new ServerSocket(it.next());
			} 
			catch (IOException e) {
			}
		}

		return null;
    }

    /**
     * Returns true, if port is in the range.
     */
    public boolean contains(int port)
    {
		return list.contains(new Integer(port));
    }

    /**
     * Returns a random port from the range.
     *
     * @param defaultPort a default port
     * @return default, if range is empty
     */
    public int getRandom(int defaultPort)
    {
		if (size() > 0) {
			List<Integer> copy = new ArrayList<Integer>(list);
			int index = (new Random()).nextInt(copy.size());
			return copy.get(index);
		}
	
		return defaultPort;
    }
    
    /**
     * Returns an iterator over all contained ports.
     */
    public Iterator<Integer> iterator()
    {
		return list.iterator();
    }

    /**
     * Returns an iterator over a shuffeled instance.
     */
    public Iterator<Integer> randomIterator()
    {
		List<Integer> copy = new ArrayList<Integer>(list);
		Collections.shuffle(copy);
		return copy.iterator();
    }

    /**
     * Returns the number of ports.
     */
    public int size()
    {
		return list.size();
    }

    /**
     * Returns an ordered string representation.
     */
    public String toString()
    {
		StringBuilder sb = new StringBuilder();

		List<Integer> copy = new ArrayList<Integer>(list);
		Collections.sort(copy);

		int start = 0;
		int last = -1;
		for (Iterator<Integer> it = copy.iterator(); it.hasNext();) {
			int current = it.next();
			if (last == -1) {
				start = current;
			}
			else if (current - last > 1) {
				sb.append(start);
				if (start != last) {
					sb.append("-");
					sb.append(last);
				}
				sb.append(";");
				start = current;
			}
			last = current;
		}

		if (last != -1) {
			sb.append(start);
			if (start != last) {
				sb.append("-");
				sb.append(last);
			}
			sb.append(";");
		}

		// return with trailing ';' removed
		return (sb.length() > 0) ? sb.substring(0, sb.length() - 1) : "";
    }

}

 
