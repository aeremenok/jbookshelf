/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import java.awt.ComponentOrientation;
import java.awt.Dimension;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.JList;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.text.JTextComponent;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This class presents completed objects in a popup menu below a {@link
 * JTextComponent}.
 * 
 * @author Felix Berger
 */
public class CompletionPopup extends JPopupMenu
{
		
	/**
	 * The completion mode handling when and how to complete.
	 */
	private Completion completion;
	/**
	 * The list presenting the completed items.
	 */
	private JList list = new JList();

	private KeyListener keyListener = new KeyHandler();

	private FocusListener focusListener = new FocusHandler();

	private ComponentListener componentListener = new SizeHandler();
	
	private PropertyChangeListener propertyListener = new PropertyChangeHandler();
		
	private static Log logger = LogFactory.getLog(CompletionPopup.class);
	
	
	/**
	 * Constructs a new completion popup.
	 */
	public CompletionPopup()
	{
		list.setVisibleRowCount(4);
		list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane jsp = new JScrollPane(list);
		add(jsp);

		list.setFocusable(false);
		jsp.setFocusable(false);
		setFocusable(false);

		list.addMouseListener(new MouseHandler());
	}

    
	public void enablePopup(Completion comp)
	{
		completion = comp;

		applyComponentOrientation(completion.getTextComponent().getComponentOrientation());
		
		completion.getTextComponent().addKeyListener(keyListener);
		completion.getTextComponent().addFocusListener(focusListener);
		completion.getTextComponent().addPropertyChangeListener
		("componentOrientation", propertyListener);

		// set the model
		list.setModel(completion.getModel());
		
		if (completion.isWholeTextCompletion()) {
			setPreferredSize(new Dimension(completion.getTextComponent().getWidth(),
										   getPreferredSize().height));
			completion.getTextComponent().addComponentListener(componentListener);
		}
	}
	
	public void disablePopup()
	{
		/* this breaks completion popup navigateion for the history text field,
		   but I guess completion + history is a bit too much anyway.  */
		completion.getTextComponent().removeKeyListener(keyListener);
		completion.getTextComponent().removeFocusListener(focusListener);
		completion.getTextComponent().removePropertyChangeListener
			("componentOrientation", propertyListener);
		if (completion.isWholeTextCompletion()) {
			completion.getTextComponent().removeComponentListener(componentListener);
		}
	}

	private void selectNextCompletion()
	{
		if (completion.getModel().getSize() > 0) {
			int cur = (list.getSelectedIndex() + 1) % completion.getModel().getSize();
			list.setSelectedIndex(cur);
			list.ensureIndexIsVisible(cur);
		}
	}

	private void selectPreviousCompletion()
	{
		if (completion.getModel().getSize() > 0) {
			int cur = (list.getSelectedIndex() == -1) ? 0 
				: list.getSelectedIndex();
			cur = (cur == 0) ? completion.getModel().getSize() - 1 : cur - 1;
			list.setSelectedIndex(cur);
			list.ensureIndexIsVisible(cur);
		}
	}

	/**
	 * Accessor for testing.
	 */
	JList getList()
	{
		return list;
	}

	/**
	 * Listens for size changes of the text component and updates the popup's
	 * width appropriately.
	 *
	 * This makes only sense for {@link JTextField}s.
	 */
	public class SizeHandler extends ComponentAdapter
	{
		public void componentResized(ComponentEvent e)
		{
			setPreferredSize
				(new Dimension(completion.getTextComponent().getWidth(), 
							   getPreferredSize().height));
		}
	}

	/**
	 * Listens for key events in the text component responsible for navigation
	 * and confirmation.
	 */
	private class KeyHandler extends KeyAdapter
	{
		public void keyPressed(KeyEvent e)
		{
			int code = e.getKeyCode();
			int modifiers = e.getModifiers();

			// catch all up an down events
			if (CompletionPopup.this.isVisible()) {
				if (code == KeyEvent.VK_DOWN) {
					selectNextCompletion();
					e.consume();
				}
				else if (code == KeyEvent.VK_UP) {
					selectPreviousCompletion();
					e.consume();
				}
				else if (code == KeyEvent.VK_ENTER) {
					if (list.getSelectedValue() != null) {
						/* object violation, maybe we should throw an event or
                           do nothing at all.  */
						completion.setText(list.getSelectedValue().toString());
						e.consume();
					}
					CompletionPopup.this.setVisible(false);
				} 
				else if (code == KeyEvent.VK_ESCAPE) {
					CompletionPopup.this.setVisible(false);
					e.consume();
				}
			}
		}
	}

	/**
	 * Listens for the loss of focus and hides the popup if necessary.
	 */
	private class FocusHandler extends FocusAdapter
	{
		public void focusLost(FocusEvent e)
		{
			if (!e.isTemporary()) {
				setVisible(false);
			}
		}
	}

	/**
	 * Listens for click events in the completion list to update the text
	 * component's text appropriately.
	 */
	private class MouseHandler extends MouseAdapter
	{
		public void mouseClicked(MouseEvent e)
		{
			completion.setText(list.getSelectedValue().toString());
			CompletionPopup.this.setVisible(false);
		}
	}
	
	private class PropertyChangeHandler implements PropertyChangeListener
	{

		public void propertyChange(PropertyChangeEvent evt) 
		{
			ComponentOrientation o = (ComponentOrientation)evt.getNewValue();
			applyComponentOrientation(o);
		}
		
	}
}
