/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * 
 */
public class SerializableSetting<T extends Serializable> extends AbstractSetting<T> {

    public SerializableSetting(SettingResource backend, String key, T defaultValue, Validator validator)
    {
    	super(backend, key, defaultValue, validator);
    }

    public SerializableSetting(SettingResource backend, String key, T defaultValue)
    {
    	super(backend, key, defaultValue, null);
    }

    @SuppressWarnings("unchecked")
	protected T fromString(String value)
	{
//    	ByteArrayInputStream buffer = new ByteArrayInputStream(value.getBytes());
    	ByteArrayInputStream buffer = new ByteArrayInputStream(toByteArray(value));
    	
    	ObjectInputStream in;
		try {
			in = new ObjectInputStream(buffer);
			return (T)in.readObject();
		}
		catch (IOException e) {
			return null;
		}
		catch (ClassNotFoundException e) {
			return null;
		}
	}

	protected String toString(T value)
	{
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		ObjectOutputStream out = null;
		try {
			out = new ObjectOutputStream(buffer);
			out.writeObject(value);
//			return buffer.toString();
			return toString(buffer.toByteArray());
		}
		catch (IOException e) {
			throw new IllegalArgumentException("Could not serialize value");
		}
		finally {
			if (out != null) {
				try {
					out.close();
				}
				catch (IOException e1) {}
			}
		}
	}
	
	private String toString(byte[] array)
	{
		char[] chars = new char[array.length];
		for (int i = 0; i < chars.length; i++) {
			chars[i] = (char)array[i];
		}
		return new String(chars);
	}
	
	private byte[] toByteArray(String s)
	{
		char[] chars = s.toCharArray();
		byte[] bytes = new byte[chars.length];
		for (int i = 0; i < bytes.length; i++) {
			bytes[i] = (byte)chars[i];
		}
		return bytes;
	}

}
