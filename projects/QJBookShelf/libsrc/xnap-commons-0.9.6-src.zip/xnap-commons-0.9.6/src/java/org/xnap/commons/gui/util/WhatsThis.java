/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.util;

import java.awt.AWTEvent;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.AWTEventListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.JToolTip;
import javax.swing.SwingUtilities;
import javax.swing.border.EmptyBorder;

/**
 * Static helper class, that allows to enrich components with What's This help.
 * <p>
 * See {@link #setText(JComponent, String)} and {@link #enterWhatsThisMode()}.
 *
 * @see org.xnap.commons.gui.util.WhatsThisAction
 * 
 * @author Felix Berger
 */
public class WhatsThis {

	private static EventHandler listener = new EventHandler();

	private static HashMap<Component, Cursor> cursorsByComponent = 
		new HashMap<Component, Cursor>();
	
	private static boolean justEntered;
	
	// TODO cleanup
	private static Cursor gotHelpCursor = Toolkit.getDefaultToolkit().
		createCustomCursor(((ImageIcon)IconHelper.getIcon("idea.png", 16)).getImage(),
				new Point(0, 0), "gotHelpCursor"); 
	
	private static Cursor noHelpCursor = Toolkit.getDefaultToolkit().
		createCustomCursor(((ImageIcon)IconHelper.getIcon("contexthelp.png", 16)).getImage(),
				new Point(0, 0), "noHelpCursor");
	
	/**
	 * Sets the what's this text for the component.
	 * @param c the component
	 * @param text the text that should be displayed in the what's this popup
	 * for this component
	 */
	public static void setText(JComponent c, String text) 
	{
		c.putClientProperty(Action.LONG_DESCRIPTION, text);
	}
	
	/**
	 * Removes the what's this text for the component
	 * @param c the component
	 */
	public static void removeText(JComponent c)
	{
		c.putClientProperty(Action.LONG_DESCRIPTION, null);
	}
	
	/**
	 * Retrieves the what's this text for the component. If 
	 * <code>searchParents</code> is true their text is retrieved as fallback.
	 * 
	 * @param c the component
	 * @param searchParents if true the component hierarchy is searched
	 * @return the text; null, if no what's this text has been set
	 */
	public static String getText(Component c, boolean searchParents) 
	{
		String text = null;
		if (c instanceof AbstractButton) {
			// ask action
			AbstractButton button = (AbstractButton)c;
			if (button.getAction() != null) {
				text = (String)button.getAction().getValue(Action.LONG_DESCRIPTION);
			}
		}
		if (text == null && c instanceof JComponent) {
			JComponent jc = (JComponent)c;
			text = (String)jc.getClientProperty(Action.LONG_DESCRIPTION);
		}
		if (text == null && searchParents && c.getParent() != null) {
			return getText(c.getParent(), searchParents);
		}
		return text;
	}
	
	/**
	 * Enters What's This mode.
	 * <p>
	 * A global mouse listener is added to the awt event queue looking for
	 * mouse movement and mouse clicks.
	 * <p>
	 * A special cursor is displayed for components that provide a What's this
	 * help text, another special cursor is displayed for components that don't.
	 * <p>
	 * The mode is exited automatically after the first mouse button click on
	 * any component. If the component in question has a What's this help
	 * text, the text is displayed in a popup.
	 */
	public static void enterWhatsThisMode()
	{
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				justEntered = true;
				Toolkit.getDefaultToolkit().addAWTEventListener(listener,
						AWTEvent.MOUSE_EVENT_MASK | AWTEvent.KEY_EVENT_MASK);
			}
		});
		
	}
	
	/**
	 * Exits What's this mode.
	 * <p>
	 * See {@link #enterWhatsThisMode()}. The global mouse listener is
	 * deregistered and the original cursors for all components are restored.
	 */
	public static void exitWhatsThisMode()
	{
		Toolkit.getDefaultToolkit().removeAWTEventListener(listener);
		Set<Map.Entry<Component, Cursor>> pairs = cursorsByComponent.entrySet();
		for (Iterator<Map.Entry<Component, Cursor>> i = pairs.iterator(); i.hasNext();) {
			Map.Entry<Component, Cursor> entry = i.next();
			entry.getKey().setCursor(entry.getValue());
		}
		cursorsByComponent.clear();
	}
	
	private static class WhatsThisPopup extends JPopupMenu
	{
		public WhatsThisPopup(String text)
		{
			setBorder(new EmptyBorder(0, 0, 0, 0));
			JToolTip tip = new JToolTip();
			add(tip);
			tip.setTipText(GUIHelper.tt(text, 200));
		}
	}
	
	private static class EventHandler implements AWTEventListener
	{

		public void eventDispatched(AWTEvent event) 
		{
			
			switch (event.getID()) {
			case MouseEvent.MOUSE_MOVED:
				if (justEntered) {
					justEntered = false;
					entered((MouseEvent)event);
				}
			case MouseEvent.MOUSE_ENTERED:
				entered((MouseEvent)event);
				break;
			case MouseEvent.MOUSE_EXITED:
				exited((MouseEvent)event);
				break;
			case MouseEvent.MOUSE_CLICKED:
				((MouseEvent)event).consume();
				break;
			case MouseEvent.MOUSE_PRESSED:
				showPopup((MouseEvent)event);
				break;
			case MouseEvent.MOUSE_RELEASED:
				((MouseEvent)event).consume();
				break;
			case KeyEvent.KEY_PRESSED:
				keyPressed((KeyEvent)event);
				break;
			}
		}
		
		private void showPopup(MouseEvent e)
		{
			e.consume();
					
			if (e.getSource() instanceof Component) {
				Component c = (Component)e.getSource();
				String whatsThisText = getText(c, true);
				if (whatsThisText != null) {
					WhatsThisPopup popup = new WhatsThisPopup(whatsThisText);
					popup.show(c, e.getX(), e.getY());
				}
			}
			
			exited(e);
			
			WhatsThis.exitWhatsThisMode();
		}
		
		private void keyPressed(KeyEvent e)
		{
			if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
				WhatsThis.exitWhatsThisMode();
				e.consume();
			}
		}
		
		private void entered(MouseEvent e)
		{
			if (e.getSource() instanceof Component) {
				Component c = (Component)e.getSource();
				if (c.isCursorSet()) {
					if (cursorsByComponent.containsKey(c)) {
						// TODO bflat1
					}
					cursorsByComponent.put(c, c.getCursor());
				}
				String whatsThisText = getText(c, true);
				if (whatsThisText != null) {
//					c.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
					c.setCursor(gotHelpCursor);
				}
				else {
//					c.setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
					c.setCursor(noHelpCursor);
				}
			}
		}
		
		private void exited(MouseEvent e)
		{
			// set mouse cursor back to what is was, which is either
			// stored in the map or null
			if (e.getSource() instanceof Component) {
				((Component)e.getSource()).setCursor((Cursor)cursorsByComponent.get(e.getSource()));
			}
		}
	}
}
