/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.shortcut;

import java.awt.BorderLayout;
import java.util.List;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import org.xnap.commons.gui.ColoredTable;
import org.xnap.commons.gui.table.AbstractSimpleTableModel;
import org.xnap.commons.gui.table.TableLayoutManager;
import org.xnap.commons.gui.table.TableSorter;
import org.xnap.commons.gui.util.GUIHelper;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * Provides controls to manage {@link org.xnap.commons.gui.shortcut.Shortcut} 
 * objects.
 * 
 * @author Steffen Pingel
 */
public class ShortcutPanel extends JPanel {

	private static I18n i18n = I18nFactory.getI18n(ShortcutPanel.class);
	
	private KeyStrokePanel keyStrokePanel;
    private ColoredTable shortcutTable;
	private TableLayoutManager shortcutTableLayoutManager;
	private ShortcutTableModel shortcutTableModel;
	private ShortcutProxy selectedProxy;
	
    public ShortcutPanel()
    {
		setLayout(new BorderLayout());

		shortcutTableModel = new ShortcutTableModel();
		TableSorter sorter = new TableSorter(shortcutTableModel);
		shortcutTable = new ColoredTable(sorter);
		shortcutTableLayoutManager = new TableLayoutManager(shortcutTable);
		shortcutTableLayoutManager.addColumnProperties("description", i18n.tr("Action"), 80, true);
		shortcutTableLayoutManager.addColumnProperties("category", i18n.tr("Category"), 60, true);
		shortcutTableLayoutManager.addColumnProperties("shortcut", i18n.tr("Shortcut"), 40, true);
		shortcutTableLayoutManager.getTableLayout().setMaintainSortOrder(true);
		shortcutTableLayoutManager.initializeTableLayout();
		shortcutTable.setIntercellSpacing(new java.awt.Dimension(2, 1));
		shortcutTable.setShowVerticalLines(true);
		shortcutTable.setShowHorizontalLines(false);
		shortcutTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		shortcutTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			public void valueChanged(ListSelectionEvent event)
			{
				applySelectedKeyStroke();
				
				selectedProxy = getSelectedShortcut();
				if (selectedProxy != null) {
					keyStrokePanel.setKeyStroke(selectedProxy.getKeyStroke());
					keyStrokePanel.setDefaultKeyStroke(selectedProxy.getDefaultKeyStroke());
					keyStrokePanel.setEnabled(true);
				}
				else {
					keyStrokePanel.setKeyStroke(null);
					keyStrokePanel.setDefaultKeyStroke(null);
					keyStrokePanel.setEnabled(false);
				}
			}			
		});
		//shortcutTable.setPreferredScrollableViewportSize(new Dimension(50, 50));	
		add(new JScrollPane(shortcutTable), BorderLayout.CENTER);
		
		keyStrokePanel = new KeyStrokePanel();
		keyStrokePanel.setBorder(GUIHelper.createTitledBorder(i18n.tr("Shortcut for Selected Action"), 5));
		keyStrokePanel.addChangeListener(new ChangeListener() {
			public void stateChanged(ChangeEvent e)
			{
				applySelectedKeyStroke();
			}
		});
		// disable by default, will be enabled when a node is selected
		keyStrokePanel.setEnabled(false);
		add(keyStrokePanel, BorderLayout.SOUTH);
    }
    
    public void add(Shortcut shortcut, KeyStroke defaultKeyStroke)
    {
    	shortcutTableModel.add(new ShortcutProxy(shortcut, defaultKeyStroke));
    }

    public void apply() 
    {
    	applySelectedKeyStroke();
    	
		List<ShortcutProxy> data = shortcutTableModel.getData();
		for (ShortcutProxy proxy : data) {
			proxy.getShortcut().setKeyStroke(proxy.getKeyStroke());
		}
    }
    
    public void applySelectedKeyStroke()
    {
    	if (selectedProxy != null) {
			selectedProxy.setKeyStroke(keyStrokePanel.getKeyStroke());
			shortcutTableModel.changed(selectedProxy);
		}
    }

	protected int getSelectedRow() 
	{
		int row = shortcutTable.getSelectedRow();
		return (row == -1) ? -1 : ((TableSorter)shortcutTable.getModel()).mapToIndex(row);
	}

	protected ShortcutProxy getSelectedShortcut()
	{
		int row = getSelectedRow();
		return (row == -1) ? null : shortcutTableModel.getItem(row); 
	}

    public String getTitle()
    {
		return i18n.tr("Shortcuts");
    }

    private class ShortcutProxy {

		private KeyStroke defaultKeyStroke;
		private KeyStroke keyStroke;
		private Shortcut shortcut;

		public ShortcutProxy(Shortcut shortcut, KeyStroke defaultKeyStroke)
		{
			this.shortcut = shortcut;
			this.keyStroke = shortcut.getKeyStroke();
			this.defaultKeyStroke = defaultKeyStroke;
		}
		
		public KeyStroke getDefaultKeyStroke()
		{
			return defaultKeyStroke;
		}

		public KeyStroke getKeyStroke()
		{
			return keyStroke;
		}

		public Shortcut getShortcut()
		{
			return shortcut;
		}
		
		public void setKeyStroke(KeyStroke keyStroke) 
		{
			this.keyStroke = keyStroke;
		}

    }

    private class ShortcutTableModel extends AbstractSimpleTableModel<ShortcutProxy> {

		public ShortcutTableModel()
		{
			super(new Class[] {
					String.class,
					String.class,
					String.class,
			});
		}

		public void changed(ShortcutProxy selectedProxy)
		{
			int i = getData().indexOf(selectedProxy);
			if (i != -1) {
				fireTableRowsUpdated(i, i);
			}
		}

		@Override
		public Object getValueAt(int row, int column)
		{
			ShortcutProxy proxy = getItem(row);
			switch (column) {
			case 0:
				return proxy.getShortcut().getValue(Shortcut.DESCRIPTION);
			case 1:
				return proxy.getShortcut().getValue(Shortcut.CATEGORY);
			case 2:
				return (proxy.getKeyStroke() != null) 
					? KeyStrokePanel.toString(proxy.getKeyStroke())
					: null;
			default:
				return null;
			}
		}

    }

}
