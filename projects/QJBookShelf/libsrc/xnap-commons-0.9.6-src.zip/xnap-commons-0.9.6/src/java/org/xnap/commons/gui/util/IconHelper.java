/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.util;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Image;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Icon;
import javax.swing.ImageIcon;

/**
 * @author Steffen Pingel
 */
public class IconHelper {

	/**
	 * The default path to search for icons.
	 */
    public static final String DEFAULT_ICON_PATH = "icons/";
	
	public static ClassLoader classLoader = IconHelper.class.getClassLoader();

    /**
     * List bigger sizes first. Scaling down looks nicer than scaling up.
     */
    private static final int[] DEFAULT_ICON_SUBDIRECTORIES = {
		64, 52, 32, 22, 16
    };

    private static String iconPath = DEFAULT_ICON_PATH;
    private static int[] subDirectories = DEFAULT_ICON_SUBDIRECTORIES;
    
    public static final Icon getIcon(String filename, int size, boolean createEmptyIcon)
	{
    	if (filename == null) {
    		return createEmptyIcon ? new EmptyIcon(size) : null;
    	}
	
    	ImageIcon icon = getImage(size, filename);
    	if (icon != null) {
    		if (icon.getIconWidth() != size || icon.getIconHeight() != size) {
    			// scale icon to fit size requirements
    			icon = new ImageIcon(icon.getImage().getScaledInstance
    				(size, size, Image.SCALE_SMOOTH));
    		}

    		return icon;
    	}
    	else {
    		return createEmptyIcon ? new EmptyIcon(size) : null;
    	}
	}

    /**
     * @return never returns null
     * @see #getIcon(String, int, boolean)
     */
    public static final Icon getIcon(String filename, int size)
    {
		return getIcon(filename, size, true);
    }
    
    /**
     * Searches {@link #iconPath} for <code>filename</code>. 
     * @return null, if <code>filename</code> does not exists
     */
    public static final ImageIcon getImage(String filename)
    {
		URL url = classLoader.getResource(iconPath + filename);
		return (url != null) ? getImageIcon(url) : null;
    }

	public static final ImageIcon getImage(int size, String filename)
    {
		URL url = getImageURL(size, filename);
		if (url != null) {
			return getImageIcon(url);
		}
		
		// look for the icon in other subdirecotries
		for (int subDirectory : subDirectories) {
			if (subDirectory == size) {
				continue;
			}
			url = getImageURL(subDirectory, filename);
			if (url != null) {
				return getImageIcon(url);
			}
		}
		
		return null;
	}

	public static final URL getImageURL(int size, String filename)
    {
		return classLoader.getResource(DEFAULT_ICON_PATH + size + "/" + filename);
    }
	
	public static final ImageIcon getImageIcon(URL url) 
	{
		return new ImageIcon(url);
	}
	
    public static final Icon getEmptyIcon(int size)
    {
		return new EmptyIcon(size);
    }	

	public static final List<? extends Image> getApplicationIcons(String filename) {
		List<Image> icons = new ArrayList<Image>();
		for (int subDirectory : subDirectories) {
			URL url = getImageURL(subDirectory, filename);
			if (url != null) {
				icons.add(getImageIcon(url).getImage());
			}
		}
		return (icons.isEmpty()) ? null : icons;
	}
	
    public static final Icon getListIcon(String filename)
    {
		return getIcon(filename, 32, false);
    }

    public static final Icon getButtonIcon(String filename)
    {
		return getIcon(filename, 16, false);
    }

    public static final Icon getMenuIcon(String filename)
    {
		return getIcon(filename, 16);
    }

    public static final Icon getStatusBarIcon(String filename)
    {
		return getIcon(filename, 16, false);
    }

    public static final ImageIcon getSystemTrayIcon(String filename)
    {
    	Icon icon = getIcon(filename, 16, false);
		return (icon instanceof ImageIcon) ? (ImageIcon) icon : null;
    }

    public static final Icon getTableIcon(String filename)
    {
		return getIcon(filename, 14, true);
    }

    public static final Icon getTabTitleIcon(String filename)
    {
		return getIcon(filename, 16, false);
    }

    public static final Icon getTreeIcon(String filename)
    {
		return getIcon(filename, 16, false);
    }

    public static final Icon getToolBarIcon(String filename)
    {
		return getIcon(filename, 22);
    }

    public static final Icon getTitleIcon(String filename)
	{
		return getIcon(filename, 32, false);
	}
    
    public static void setIconPath(String iconPath)
    {
    	IconHelper.iconPath = iconPath;
    }

    public static void setSubDirectories(int[] subDirectories)
    {
    	IconHelper.subDirectories = subDirectories;
    }

    /**
     * Provides an empty, transparent icon.
     */
    public static class EmptyIcon implements Icon
    {
		private int size;

		/**
		 * Constructs an empty icon with a width and heigt of 
		 * <code>size</code>.
		 */
		public EmptyIcon(int size)
		{
			this.size = size;
		}
	
		public int getIconHeight() 
		{
			return size;
		}
	
		public int getIconWidth() 
		{
			return size;
		}
	
		public void paintIcon(Component c, Graphics g, int x, int y) 
		{
		}	
	
    }

	public static Icon getActionIcon(String filename)
	{
		return getIcon(filename, 16, false);
	}

}
