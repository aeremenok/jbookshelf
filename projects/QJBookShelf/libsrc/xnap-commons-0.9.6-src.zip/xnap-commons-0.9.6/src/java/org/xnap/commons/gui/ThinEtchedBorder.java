/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.AbstractBorder;

/**
 * Provides a simple 2 line bevel border. If the Border is raised it will look
 * like a tiny wall around the component it is used with. If it is lowered it
 * will look like a thin trench.
 */
public class ThinEtchedBorder extends AbstractBorder {

    public static final int RAISED  = 0;

    public static final int LOWERED = 1;

    protected int etchType;

    /**
     * Constructs a border with the given <code>etchType</code>.
     * 
	 * @see javax.swing.border.BevelBorder#BevelBorder(int)
	 * @param etchType either <code>BevelBoder.RAISED</code> or <code>BevelBorder.LOWERED</code> 
	 */
    public ThinEtchedBorder(int etchType)
    {
        this.etchType = etchType;
    }

    /**
     * Constructs a lowered border.
     *  
	 * @see javax.swing.border.BevelBorder#BevelBorder(int)
     */
    public ThinEtchedBorder()
    {
        this(LOWERED);
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int w,
							int h) 
	{
		g.translate(x, y);
	
		g.setColor((etchType == LOWERED) 
				   ? c.getBackground().darker() 
				   : c.getBackground().brighter());
		g.drawLine(0, h - 2, w - 1, h - 2);

		g.setColor((etchType == LOWERED)
				   ? c.getBackground().brighter() 
				   : c.getBackground().darker());
		g.drawLine(0, h - 1, w - 1, h - 1);
	
		g.translate(-x, -y);
    }

    public Insets getBorderInsets(Component c)       
	{
        return new Insets(2, 2, 2, 2);
    }

    public Insets getBorderInsets(Component c, Insets insets) 
	{
        insets.left = insets.top = insets.right = insets.bottom = 2;
        return insets;
    }

    /**
     * Returns true.
     */
    public boolean isBorderOpaque() 
	{ 
		return true; 
	}

    /**
     * Returns the etch type.
     */
    public int getEtchType() 
	{
        return etchType;
    }

}
