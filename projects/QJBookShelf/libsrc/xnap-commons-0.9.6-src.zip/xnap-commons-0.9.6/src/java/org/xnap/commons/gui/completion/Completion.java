/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import java.text.BreakIterator;
import java.util.ArrayList;
import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;
import javax.swing.text.Utilities;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * The Completion class follows the mediator pattern.
 * <p>
 * It manages the text component and the completion model and decouples
 * them from the {@link CompletionMode} which decides when and how to 
 * offer completion to the user.
 * <p> 
 * If you want to provide your own completion modes, install them in the
 * {@link org.xnap.commons.gui.completion.CompletionModeFactory}.
 * <p>
 * During its lifetime the completion object is coupled to only one 
 * JTextComponent, it's a one-to-one mapping. To disable it, use 
 * {@link #setEnabled(boolean) setEnabled(false)}.
 * <p>
 * A completion object can be used as follows:
 * 
 * <pre>
 * JTextField jtf = new JTextField();
 * Completion comp = new Completion(jtf, new FileCompletionModel());
 * comp.setMode(new AutomaticDropDownCompletionMode());
 * </pre>
 * 
 * When typing into the text field above the text is matched against existing
 * files on the filesystem and possible completions are presented according
 * to the {@link org.xnap.commons.gui.completion.AutomaticDropDownCompletionMode}.
 * 
 * @author Felix Berger
 */
public class Completion
{
	private static Log logger = LogFactory.getLog(Completion.class);

	private CompletionModel model;
	private CompletionMode mode;
	private JTextComponent jtc;
	private boolean wholeText;
	private boolean enabled = true;
	private BreakIterator wordIterator = null;
	
	/**
	 * The list of CompletionModeListeners for this Completion instance. 
	 */
	private ArrayList<CompletionModeListener> listeners = 
		new ArrayList<CompletionModeListener>();

	/**
	 * Constructs a new Completion object.
	 * 
	 * {@link GlobalDefaultCompletionMode} is set as the default completion mode.
	 * 
	 * @param textComponent the text component completion will be done for
	 * @param model the completion model that provides the possible completions
	 * @param wholeText if true the whole text of the text component is used
	 * for completion otherwise only the last word before the cursor is 
	 * completed. 
	 * 
	 * @throws NullPointerException if <code>textComponent</code> is null.
	 */
	public Completion(JTextComponent textComponent, CompletionModel model,
			boolean wholeText)
	{
		if (textComponent == null) {
			throw new NullPointerException("textComponent must not be null");
		}
		this.jtc = textComponent;
		this.model = model;
		this.wholeText = wholeText;
		this.mode = new GlobalDefaultCompletionMode();
		mode.enable(this);
	}

	/**
	 * Convenience wrapper for {@link #Completion(JTextComponent,
	 * CompletionModel, boolean)}.
	 *
	 * The missing completion model defaults to the {@link
	 * DefaultCompletionModel}.  
	 */
	public Completion(JTextComponent textComponent, boolean wholeText)
	{
		this(textComponent, new DefaultCompletionModel(), wholeText);
	}

	/**
	 * Convenience wrapper for {@link #Completion(JTextComponent,
	 * CompletionModel, boolean)}.
	 * 
	 * The missing boolean defaults to <code>true</code>.  
	 */
	public Completion(JTextComponent textComponent, CompletionModel model)
	{
		this(textComponent, model, true);
	}

	/**
	 * Convenience wrapper for {@link #Completion(JTextComponent, boolean)}.
	 * 
	 * The missing boolean defaults to <code>true</code>.
	 */
	public Completion(JTextComponent textComponent)
	{
		this(textComponent, true);
	}

	/**
	 * Sets a new completion mode for the managed text component and enables it
	 * if the completion is currently enabled.
	 * 
 	 * The old mode is disabled and {@link CompletionModeListener
	 * CompletionModeListeners} are notified of the mode change.
	 * 
	 * @param newMode the new completion mode
	 * @throws NullPointerException if <code>newMode</code> is 
	 * <code>null</code>
	 */
	public void setMode(CompletionMode newMode)
	{
		Class oldMode = mode.getClass();
		if (enabled) {
			mode.disable();
		}
		mode = newMode;
		if (enabled) {
			mode.enable(this);
		}
		fireModeChanged(oldMode, mode.getClass());
	}

	/**
	 * Sets the completion model.
	 * 
	 * The current completion mode is disabled and enabled in order to be
	 * notified of this change.
	 * 
	 * @param model the new completion model which will be used henceforth
	 */
	public void setModel(CompletionModel model)
	{
		mode.disable();
		this.model = model;
		if (enabled) {
			mode.enable(this);
		}
	}
	
	/**
	 * Enables or disables the currently set completion mode.
	 */
	public void setEnabled(boolean enabled)
	{
		if (this.enabled == enabled) {
			return;
		}
		this.enabled = enabled;
		if (enabled) {
			mode.enable(this);
		}
		else {
			mode.disable();
		}
	}
	
	/**
	 * Returns whether the currently set completion mode is enabled.
	 */
	public boolean isEnabled()
	{
		return enabled;
	}

	/**
	 * Returns the currently used model.
	 */
	public CompletionModel getModel()
	{
		return model;
	}

	/**
	 * Returns the currently active completion mode.
	 */
	public CompletionMode getMode()
	{
		return mode;
	}

	/**
	 * Returns the text component this completion mode is responsible for
	 */
	public JTextComponent getTextComponent()
	{
		return jtc;
	}

	/**
	 * Returns whether this completion mode is supposed to complete the whole
	 * text of its text component made availabe through {@link
	 * JTextComponent#getText()} or just the last word before the cursor.
	 */
	public final boolean isWholeTextCompletion()
	{
		return wholeText;
	}

	/**
	 * Convenience wrapper for {@link #setText(String, int, int)}.
	 * 
	 * Sets the text without any selection and setts the cursor to the end of
	 * the set text.
	 * 
	 * @param text
	 *            the text to set
	 */
	public void setText(String text)
	{
		setText(text, text.length(), text.length());
	}

	/**
	 * Sets the given text honoring the whole text mode.
	 * 
	 * @param text
	 *            the text to set
	 * @param selectionStart
	 *            the offset of the selection start relative to the beginning of
	 *            the set text. Can be greater than <code>selectionEnd</code>.
	 * @param selectionEnd
	 *            the offset of the selection end relative to the beginning of
	 *            the set text. This is where the cursor is afterwards.
	 *         
	 *  TODO why is this not public?
	 */
	protected void setText(String text, int selectionStart, int selectionEnd)
	{
		if (isWholeTextCompletion()) {
			jtc.setText(text);
			jtc.setCaretPosition(selectionStart);
			jtc.moveCaretPosition(selectionEnd);
		}
		// TODO test this part and maybe update it to the getPreviousWord() code
		else {
			int offs = -1;
			try {
				offs = Utilities.getPreviousWord(jtc, jtc.getCaretPosition());
			}
			catch (BadLocationException e) {
				logger.debug(e);
			}
			jtc.moveCaretPosition(offs);
			jtc.replaceSelection(text);
			jtc.setCaretPosition(offs + selectionStart);
			jtc.moveCaretPosition(offs + selectionEnd);
		}
	}

	private String getPreviousWord()
	{
		if (wordIterator == null) {
			wordIterator = BreakIterator.getWordInstance();
		}
		int start = jtc.getCaretPosition();
		try {
			start = Utilities.getPreviousWord(jtc, start);
			int length = jtc.getCaretPosition() - start;
			if (length > 1) {
				String ret = jtc.getText(start, length);
				wordIterator.setText(ret);
				if (!wordIterator.isBoundary(length - 1)) {
					return ret;
				}
			}
			// special case, because wordIterator would tell us it's a boundary at any rate
			else if (length == 1) {
				String ret = jtc.getText(start, length);
				if (Character.isLetterOrDigit(ret.charAt(0))) {
					return ret;
				}
			}
		}
		catch (BadLocationException ble) {
		}
		return "";
	}

	/**
	 * Returns the text which should be completed.
	 * 
	 * @return Returns {@link JTextComponent#getText()}if wholeText is true
	 *         otherwise the word before the cursor.
	 */
	public String getText()
	{
		if (wholeText) {
			return jtc.getText();
		}
		else {
			return getPreviousWord();
		}
	}
	
	/**
	 * Adds a CompletionModeListener to the listener list.
	 * @param l the CompletionModeListener to be added
	 */
	public void addCompletionModeListener(CompletionModeListener l)
	{
		synchronized (listeners) {
			listeners.add(l);
		}
	}
	
	/**
	 * Removes a CompletionModeListener from the listener list.
	 * @param l the CompletionModeListener to be removed
	 */
	public void removeCompletionModeListener(CompletionModeListener l)
	{
		synchronized (listeners) {
			listeners.remove(l);
		}
	}

	/**
	 * Can be used by subclasses to fire a completion mode change in case they
	 * provide their own implementation of {@link #setMode(CompletionMode)}.
	 * @param oldMode the class of the old completion mode
	 * @param newMode the class of the new completion mode
	 */
	protected void fireModeChanged(Class oldMode, Class newMode)
	{
		CompletionModeListener[] array;
		synchronized (listeners) {
			array = listeners.toArray(new CompletionModeListener[0]);
		}
		for (int i = array.length - 1; i >= 0; i--) {
			array[i].modeChanged(oldMode, newMode);
		}
	}
}
