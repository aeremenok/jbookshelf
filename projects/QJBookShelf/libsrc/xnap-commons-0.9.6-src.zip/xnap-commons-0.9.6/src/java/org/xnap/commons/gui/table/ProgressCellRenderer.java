/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.table;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import javax.swing.table.DefaultTableCellRenderer;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.util.Progress;
import org.xnap.commons.util.StringHelper;

/**
 * Renders progress in a progress bar with a text for a table cell.
 *
 * @see Progress
 */
public class ProgressCellRenderer extends DefaultTableCellRenderer {

	private static final I18n i18n = I18nFactory.getI18n(ProgressCellRenderer.class);
	
    private static Color runningColor  = Color.magenta;
    private static Color finishedColor = Color.green;

    private Progress value = new Progress();
    private String text;

    public ProgressCellRenderer() 
    {
    }

    protected void setValue(Object value) 
    {
		this.value
			= (value instanceof Progress) 
			? (Progress)value
			: new Progress();

		this.text = getProgressText();
		setToolTipText(String.format("%f.2", this.value.getPercent())
					   + "%" + ((text.length() == 0) ? "" : ", " + text));

		super.setValue(null);
    }

    public String getProgressText()
    {
		long rate = value.getRate();
		if (rate < 0) {
			return "";
		}
		else if (rate == 0) {
			return i18n.tr("stalled");
		}
		else {
			return i18n.tr(StringHelper.formatSize(rate) + "/s");
		}
    }

    public void paint(Graphics g) 
    {
		super.paint(g);

		double progress = value.getPercent();

		int xoff = 1;
		int yoff = 1;
		int height = getHeight() - 3;
		int width = getWidth() - 2;

		// draw progress
		if (progress > 0) {
			g.setColor((progress < 100) ? runningColor : finishedColor);
			g.fillRect(xoff, yoff, (width * (int)progress) / 100, height);
		}

		// draw text
		if (text != null && text.length() > 0) {
			FontMetrics fm = g.getFontMetrics();
			int w = fm.stringWidth(text);

			int x = (getWidth() - w) / 2;
			int y = getHeight() - 4;

			g.setColor(getForeground());
			g.drawString(text, (x > 1) ? x : 1, y);
		}						

		// draw frame
		g.setColor(Color.lightGray);
		g.drawRect(1, 1, getWidth() - 2, getHeight() - 3);
    }

}
