/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Insets;
import javax.swing.border.BevelBorder;

/**
 * Provides a simple 1 line bevel border. If the Border is raised it will look
 * like the component it is used with is raised a little bit. If it is lowered it
 * will look like the component is lowered a bit.
 * 
 * <p>Very similiar to Swing's {@link javax.swing.border.BevelBorder} except
 * it looks a bit prettier.
 */
public class ThinBevelBorder extends BevelBorder {

	/**
     * Constructs a border with the given <code>etchType</code>.
     * 
	 * @see BevelBorder#BevelBorder(int)
	 * @param bevelType either <code>BevelBoder.RAISED</code> or <code>BevelBorder.LOWERED</code> 
	 */
    public ThinBevelBorder(int bevelType)
    {
		super(bevelType);
    }

	public Insets getBorderInsets(Component c)       
	{
		return new Insets(1, 1, 1, 1);
    }

    public Insets getBorderInsets(Component c, Insets insets) 
	{
        insets.left = insets.top = insets.right = insets.bottom = 1;
        return insets;
    }

    protected void paintLoweredBevel(Component c, Graphics g, int x, int y,
									 int width, int height)  
	{
        Color oldColor = g.getColor();
        int h = height;
        int w = width;

        g.translate(x, y);

        g.setColor(getShadowOuterColor(c));
        g.drawLine(0, 0, 0, h - 2);
        g.drawLine(1, 0, w - 1, 0);

        g.setColor(getHighlightOuterColor(c));
        g.drawLine(0, h - 1, w - 1, h - 1);
        g.drawLine(w - 1, 1, w - 1, h - 2);

        g.translate(-x, -y);
        g.setColor(oldColor);

    }

    protected void paintRaisedBevel(Component c, Graphics g, int x, int y,
                                    int width, int height)  
	{
        Color oldColor = g.getColor();
        int h = height;
        int w = width;

        g.translate(x, y);

        g.setColor(getHighlightOuterColor(c));
        g.drawLine(0, 0, 0, h - 2);
        g.drawLine(1, 0, w - 1, 0);

        g.setColor(getShadowOuterColor(c));
        g.drawLine(0, h - 1, w - 1, h - 1);
        g.drawLine(w - 1, 1, w - 1, h - 2);

        g.translate(-x, -y);
        g.setColor(oldColor);
    }

}
