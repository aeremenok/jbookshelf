/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.wizard;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import org.xnap.commons.gui.Builder;
import org.xnap.commons.gui.DefaultDialog;
import org.xnap.commons.gui.action.AbstractXNapAction;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;


/**
 * 
 * @author Steffen Pingel
 */
public class WizardDialog extends DefaultDialog
{

	private static final I18n i18n = I18nFactory.getI18n(WizardDialog.class);
	
	private JLabel titleLabel;
	private JLabel iconLabel;
	private JLabel descriptionLabel;
    
    private JPanel pagePanel;
    private CardLayout pageCardLayout;

    private List<WizardPage> pages = new LinkedList<WizardPage>();
    private int selectedIndex = -1;

    private AbstractButton nextButton;
    private AbstractButton finishButton;

    private PreviousAction previousAction = new PreviousAction();
    private NextAction nextAction = new NextAction();
    private FinishAction finishAction = new FinishAction();

	private List<WizardDialogListener> listeners 
		= new ArrayList<WizardDialogListener>();

    public WizardDialog(int buttons)
    {
		super(buttons);

		initialize();
    }

    public WizardDialog(Dialog owner, int buttons)
    {
		super(owner, buttons);
		
		initialize();
    }

    public WizardDialog(Frame owner, int buttons)
    {
		super(owner, buttons);
		
		initialize();
    }

	public WizardDialog()
	{
		super(BUTTON_CANCEL);
		
		initialize();
	}

    public WizardDialog(Dialog owner)
    {
		super(owner, BUTTON_CANCEL);
		
		initialize();
    }

    public WizardDialog(Frame owner)
    {
		super(owner, BUTTON_CANCEL);
		
		initialize();
    }

	private void initialize()
	{
		JPanel jpTop = new JPanel(new BorderLayout());
		jpTop.setBackground(Color.white);
		jpTop.setBorder(BorderFactory.createEtchedBorder());
		getContentPane().add(jpTop, BorderLayout.NORTH);

		JPanel jpTitle = new JPanel(new BorderLayout());
		jpTitle.setBackground(Color.white);
		jpTop.add(jpTitle, BorderLayout.CENTER);
		
		titleLabel = new JLabel(" ");
		titleLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		titleLabel.setFont(new Font("Dialog", Font.BOLD, 16));
		titleLabel.setForeground(Color.black);
		jpTitle.add(titleLabel, BorderLayout.NORTH);

		descriptionLabel = new JLabel(" ");
		descriptionLabel.setBackground(Color.white);
		descriptionLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		descriptionLabel.setForeground(Color.black);
		jpTitle.add(descriptionLabel, BorderLayout.CENTER);

		iconLabel = new JLabel();
		iconLabel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		jpTop.add(iconLabel, BorderLayout.EAST);

		// center
		pageCardLayout = new CardLayout();
		pagePanel = new JPanel();
		pagePanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		pagePanel.setLayout(pageCardLayout);

		// bottom
		JPanel jpButtons = getButtonPanel();

		jpButtons.add(Builder.createButton(previousAction), 0);

		nextButton = Builder.createButton(nextAction);
		nextButton.setHorizontalTextPosition(SwingConstants.LEFT);
		jpButtons.add(nextButton, 1);

		finishButton = Builder.createButton(finishAction);
		jpButtons.add(finishButton, 2);

		// set me up
		setMainComponent(pagePanel);
		setSize(640, 480);
	}

    public void addPage(WizardPage page, String identifier)
    {
    	// TODO check if page was already added?
		pages.add(page);
		pagePanel.add(page.getPanel(), identifier);
    	if (selectedIndex == -1) {
    		selectedIndex = 0;
    	}
		updateHeader();
    }

    public void addPage(int index, WizardPage page, String identifier)
    {
    	// TODO check if page was already added?
		pages.add(index, page);
		pagePanel.add(page.getPanel(), identifier);
		if (selectedIndex == -1) {
    		selectedIndex = 0;
    	}
    	else if (index <= selectedIndex) {
    		selectedIndex++;
    	}
		updateHeader();
	}

    public void addWizardDialogListener(WizardDialogListener listener)
    {
    	listeners.add(listener);
    }
    
	public void finish()
	{
		boolean canClose = true;
		for (WizardPage page : pages) {
			canClose &= page.apply();
		}
		
		if (canClose) {
			isOkay = true;
			close();
		}
	}

	public Action getFinishAction()
	{
		return finishAction;
	}

	public Action getNextAction()
	{
		return nextAction;
	}

	public int getSelectedIndex()
	{
		return selectedIndex;
	}

	public WizardPage getSelectedPage()
	{
		return (WizardPage)pages.get(getSelectedIndex());
	}

	// TODO define what is to happen on add/remove on first/last page
	protected void firePageChaned(WizardPage oldPage, WizardPage newPage)
	{
		WizardDialogListener[] array 
			= listeners.toArray(new WizardDialogListener[0]);
		for (int i = array.length - 1; i >= 0; i--) {
			array[i].pageChanged(oldPage, newPage);
		}
	}
	
	/**
	 * Removes <code>page</code> from the dialog. Does nothing if page has not
	 * been previously added to the dialog.
	 * @param page the page to remove
	 */
    public void removePage(WizardPage page)
    {
    	int index = pages.indexOf(page);
    	if (index == -1) {
    		return;
    	}
		pagePanel.remove(page.getPanel());
		pages.remove(index);
		if (index <= selectedIndex) {
			selectedIndex--;
		}
		if (selectedIndex == -1) {
			clearHeader();
		} else {
			updateHeader();
		}
	}

    public void removeWizardDialogListener(WizardDialogListener listener)
    {
    	listeners.remove(listener);
    }

    private void updateActions()
    {
		previousAction.setEnabled(selectedIndex > 0);
		nextAction.setEnabled(selectedIndex < pages.size() - 1);
		if (nextAction.isEnabled()) {
			nextButton.requestFocus();
		}
		else {
			finishButton.requestFocus();
		}
    }

    public void showNextPage()
    {
    	if (selectedIndex == pages.size() - 1) {
    		throw new IllegalStateException("no more pages");
    	}
    	
		WizardPage oldPage = getSelectedPage();

		pageCardLayout.next(pagePanel);
		selectedIndex++;
		updateHeader();

		firePageChaned(oldPage, getSelectedPage());
    }
    
    public void showPreviousPage()
    {
    	if (selectedIndex <= 0) {
    		throw new IllegalStateException("no more pages");
    	}

    	WizardPage oldPage = getSelectedPage();

		pageCardLayout.previous(pagePanel);
		selectedIndex--;
		updateHeader();

		firePageChaned(oldPage, getSelectedPage());
    }
    
    private void updateHeader() 
	{
		WizardPage panel = getSelectedPage();
		titleLabel.setText(panel.getTitle());
		iconLabel.setIcon(panel.getIcon());
		descriptionLabel.setText(panel.getDescription());
	
		updateActions();
	}

    private void clearHeader()
    {
		titleLabel.setText(" ");
		iconLabel.setIcon(null);
		descriptionLabel.setText(" ");    	
    }
    
    public class PreviousAction extends AbstractXNapAction {
	
		public PreviousAction()
		{
			putValue(Action.NAME, i18n.tr("Previous"));
			putValue(ICON_FILENAME, "1leftarrow.png");
        }

        public void actionPerformed(ActionEvent event) 
		{
			showPreviousPage();
        }

    }

    public class NextAction extends AbstractXNapAction {
	
		public NextAction()
		{
			putValue(Action.NAME, i18n.tr("Next"));
			putValue(ICON_FILENAME, "1rightarrow.png");
        }

        public void actionPerformed(ActionEvent event) 
		{
        	showNextPage();
        }

    }

    public class FinishAction extends AbstractXNapAction {
	
		public FinishAction()
		{
			putValue(Action.NAME, i18n.tr("Finish"));
        }

        public void actionPerformed(ActionEvent event) 
		{
			finish();
        }

    }

    protected class PContainer extends JPanel
    {
		Dimension maxDim = new Dimension(0, 0);

		public void add(Component comp, Object constraints) 
		{
			Dimension d = comp.getPreferredSize();
			if (d.height > maxDim.height) {
				maxDim.height = d.height;
			}
			if (d.width > maxDim.width) {
				maxDim.width = d.width;
			}

			super.add(comp, constraints);
		}

		public Dimension getPreferredSize()
		{
			// looks like the height is too small
			return new Dimension(maxDim.width + 10, maxDim.height + 30);
		}
    }

}
