/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.io.File;
import java.util.LinkedList;
import javax.swing.Action;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;
import org.xnap.commons.gui.action.AbstractXNapAction;
import org.xnap.commons.gui.dnd.DefaultTreeFileTransferHandler;
import org.xnap.commons.gui.tree.FileCellRenderer;
import org.xnap.commons.gui.tree.FileNode;
import org.xnap.commons.gui.tree.FileTreeModel;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * Provides a dialog with a {@link JTree} that contains the local
 * directory structure for directory selection and a button for quick selection
 * of the user's home directory.
 * 
 * <p>The usage of this class is similar to {@link javax.swing.JFileChooser}.
 * 
 * TODO add auto completed input field for entering directory
 */
public class DirectoryChooser extends DefaultDialog
	implements TreeSelectionListener
{

	private static final I18n i18n = I18nFactory.getI18n(DirectoryChooser.class);
	
    public static final int APPROVE_OPTION = 1;
    public static final int CANCEL_OPTION = 2;

    private JTree directoryTree;
    private FileTreeModel directoryTreeModel;
	private HomeAction homeAction;
	private int selectedOption;

	/**
	 * Creates a directory chooser.
	 * 
	 * @param owner the dialog's parent
	 */
    public DirectoryChooser(JFrame owner)
    {
    	super(owner, BUTTON_OKAY | BUTTON_CANCEL);
    	
    	initialize();
    }	

	/**
	 * Creates a directory chooser.
	 * 
	 * @param owner the dialog's parent
	 */
    public DirectoryChooser(JDialog owner)
    {
    	super(owner, BUTTON_OKAY | BUTTON_CANCEL);
    	
    	initialize();
    }	

	/**
	 * Creates a directory chooser.
	 */
    public DirectoryChooser()
    {
    	super(BUTTON_OKAY | BUTTON_CANCEL);
    	
    	initialize();
    }	
    
    private void initialize()
    {
		// center
		directoryTreeModel = new FileTreeModel(i18n.tr("Folders"), 
				File.listRoots());
		directoryTree = new JTree(directoryTreeModel);
		directoryTree.setRootVisible(false);
		directoryTree.setCellRenderer(new FileCellRenderer());
		directoryTree.putClientProperty("JTree.lineStyle", "Angled");
		directoryTree.addTreeSelectionListener(this);
		directoryTree.setTransferHandler(new DefaultTreeFileTransferHandler());
		directoryTree.setDragEnabled(true);

        JScrollPane jspDirectories = new JScrollPane(directoryTree);

		// bottom
		homeAction = new HomeAction();
		getButtonPanel().add(Builder.createButton(homeAction), 0);

		// set me up
		getMainPanel().setLayout(new BorderLayout());
		getMainPanel().add(jspDirectories, BorderLayout.CENTER);

		pack();
    }

    @Override
	public boolean apply()
	{
		selectedOption = APPROVE_OPTION;
		return true;
	}

    @Override
	public void cancelled()
	{	
		selectedOption = CANCEL_OPTION;
	}
	
	/**
	 * Returns the currently selected directory.
	 *  
	 * @return the selected directory; null, if no directory is selected 
	 */
	public File getSelectedDirectory()
    {
		Object selectedItem = directoryTree.getLastSelectedPathComponent();
		return (selectedItem instanceof File) ? (File)selectedItem : null;
    }

	/**
	 * Selects the specified directory in the tree. The tree is expanded
	 * as necessary and scrolled to ensure visibility of the directory. 
	 * 
	 * @param dir the directory to be selected
	 */
    public void setSelectedDirectory(File dir)
    {
		LinkedList<FileNode> files = new LinkedList<FileNode>();
		File parent = dir;
		while (parent != null) {
			files.addFirst(new FileNode(parent));
			parent = parent.getParentFile();
		}
		Object[] path = new Object[files.size() + 1];
		path[0] = directoryTreeModel.getRoot();
		System.arraycopy(files.toArray(), 0, path, 1, path.length - 1);
		TreePath tp = new TreePath(path);
		directoryTree.setSelectionPath(tp);
		directoryTree.scrollPathToVisible(tp);
    }

    public int showChooseDialog(Component c)
    {
		setTitle(i18n.tr("Choose a Folder"));
		setModal(true);
		pack();
		show(c);

		return selectedOption;
    }

    public void valueChanged(TreeSelectionEvent e)
    {
		getOkayAction().setEnabled(directoryTree.getLastSelectedPathComponent()
								  instanceof File);
    }

    public class HomeAction extends AbstractXNapAction {
	
		public HomeAction()
		{
			putValue(Action.NAME, i18n.tr("Home"));
            putValue(Action.SHORT_DESCRIPTION,
					 i18n.tr("Jump to home folder"));
			putValue(ICON_FILENAME, "folder_home.png");					 
        }

        public void actionPerformed(ActionEvent event) 
		{
			setSelectedDirectory(new File(System.getProperty("user.home")));
        }

    }

}
