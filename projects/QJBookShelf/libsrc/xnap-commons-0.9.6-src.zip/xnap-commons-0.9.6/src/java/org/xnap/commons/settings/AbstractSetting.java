/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.beans.PropertyChangeListener;
import java.util.Arrays;

/**
 * Provides a default implementation of a setting.
 */
public abstract class AbstractSetting<T> implements Setting<T> {

    public static final String ARRAY_SEPARATOR = ";";
    
    protected SettingResource backstore;
	private String key;
	private Validator validator;
	private T defaultValue;
	
	public AbstractSetting(SettingResource backstore, String key, T defaultValue, Validator validator)
	{
		this.backstore = backstore;
		this.key = key;
		this.defaultValue = defaultValue;
		this.validator = validator;
	}

    /**
     * Adds a preferences listener.
     */
    public synchronized void addPropertyChangeListener(PropertyChangeListener l)
    {
		backstore.addPropertyChangeListener(getKey(), l);
    }

    /**
     * Determine if 2 objects are equal, or both point to null.
     */
    public static boolean areObjectsEqual(Object obj1, Object obj2) 
    {
		return (obj1 != null) ? obj1.equals(obj2) : (obj1 == obj2);
    }

    /**
     * Determine if 2 arrays are equal, or both point to null.
     */
    public static boolean areObjectsEqual(Object[] obj1, Object[] obj2) 
    {
		return (obj1 != null) ? obj2 == null : Arrays.equals(obj1, obj2);
    }

	/**
	 * Sets the value of the setting from s.
	 */
	protected abstract T fromString(String s);

	public String getKey()
	{
		return key;
	}

	public T getDefaultValue()
	{
		return defaultValue;
	}

	public SettingResource getProperties()
	{
		return backstore;
	}

	public T getValue()
	{
		T value = null;
		String s = backstore.get(getKey(), null);
		if (s != null) {
			 value = fromString(s);
		}
		return (value != null) ? value : defaultValue;
	}
	
	public Validator getValidator()
	{
		return validator;
	}
	
	public void removePropertyChangeListener(PropertyChangeListener l)
	{
		backstore.removePropertyChangeListener(getKey(), l);
	}
	
	public void revert()
	{
		setValue(defaultValue);
	}

	protected void setDefaultValue(T defaultValue)
	{
		this.defaultValue = defaultValue;
	}

	public void setProperties(PropertyResource properties)
	{
		this.backstore = properties;
	}

	public void setValue(T newValue)
	{
		T oldValue = getValue();
        if (!areObjectsEqual(newValue, oldValue)) {
        	if (newValue == null || areObjectsEqual(newValue, defaultValue)) {
        		// null essentially means default value
        		backstore.remove(getKey());
        	}
        	else {
        		String stringValue = toString(newValue);
        		if (validator != null) {
        			validator.validate(stringValue);
        		}
        		backstore.put(getKey(), stringValue);
        	}
        	
        	// notify listeners of new value
			backstore.firePropertyChange(getKey(), oldValue, newValue);
        }
	}
	
	public void setValidator(Validator validator)
	{
		this.validator = validator;
	}
	
    /**
     * Returns a string representation of the setting. The string is
     * written to the settings file.
	 *
	 * @see #fromString(String)
	 */
	protected abstract String toString(T object);
	
}
