/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import javax.swing.JToggleButton;
import org.xnap.commons.gui.action.ToggleAction;

/**
 * This class provides a toggelable toolbar button with an appropriate sized
 * icon that can display a little arrow as a hint for a menu. The border of the 
 * button is only visible when the mouse hovers over the button.
 */
public class ToolBarToggleButton extends JToggleButton {

	private boolean showBorder;
	private boolean showMenuHint;

	public ToolBarToggleButton(ToggleAction action, boolean showMenuHint)
	{
		super(action);

		this.showMenuHint = showMenuHint;
		
		setContentAreaFilled(false);
		setText(null);
		setMargin(new Insets(1, 1, 1, 1));

		putClientProperty("hideActionText", Boolean.TRUE);
	}

	/**
	 * Returns true, if the mouse is currently over the button.
	 */
	public boolean isMouseOver()
	{
		return showBorder;
	}

	@Override
	protected void paintBorder(Graphics g)
	{
		if (showBorder || isSelected()) {
			super.paintBorder(g);
		}
	}

	@Override
	protected void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		if (showMenuHint) {
			int w = getWidth();
			int h = getHeight();

			g.setColor(Color.black);

			// draw bottom up: yoff = -3, xoff = -8
			for (int i = 0; i < 4; i++) {
				g.drawLine(w - 8 - i, h - 3 - i, w - 8 + i, h - 3 - i);
			}
			g.drawLine(w - 8 - 4, h - 3 - 4, w - 8 + 4, h - 3 - 4);
		}
	}

	@Override
	protected void processMouseEvent(MouseEvent e)
	{
		super.processMouseEvent(e);
		
		if (e.getID() == MouseEvent.MOUSE_ENTERED) {
			showBorder = true;
			setContentAreaFilled(true);
			repaint();
		}
		else if (e.getID() == MouseEvent.MOUSE_EXITED) {
			showBorder = false;
			setContentAreaFilled(false);
			repaint();
		}
	}
	
}
