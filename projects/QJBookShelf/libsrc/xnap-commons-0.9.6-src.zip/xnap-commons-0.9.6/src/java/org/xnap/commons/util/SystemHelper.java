/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.util;

/**
 * Provides static variables that describe properties of the underlying 
 * platform and runtime environment. Sometimes it is necessary to work 
 * around certain differences between platforms or bugs of a specific JDK
 * release. 
 *  
 * @author Steffen Pingel
 */
public class SystemHelper {
	
    /**
     * True, if is system is Apple Mac OS X; false, otherwise.
     */
    public static final boolean IS_MACOSX;

    /**
     * True, if system is Microsoft Windows; false, otherwise.
     */
    public static final boolean IS_WINDOWS;
    
    /**
     * True, if system is Microsoft Windows XP; false, otherwise.
     */
    public static final boolean IS_WINDOWS_XP;    

    /**
     * True, if Java version is higher or equal than 1.6.0.
     */
    public static final boolean IS_JAVA6_OR_HIGHER;

    static {
		String ver = System.getProperty("java.version", "");
		IS_JAVA6_OR_HIGHER = (VersionParser.compare(ver, "1.6") >= 0);

		String os = System.getProperty("os.name").toLowerCase();
		IS_WINDOWS = (os.indexOf("windows") != -1);
		IS_WINDOWS_XP = IS_WINDOWS && (os.indexOf("xp") != -1);
		IS_MACOSX = (os.indexOf("mac os x") != -1);
    }

}
