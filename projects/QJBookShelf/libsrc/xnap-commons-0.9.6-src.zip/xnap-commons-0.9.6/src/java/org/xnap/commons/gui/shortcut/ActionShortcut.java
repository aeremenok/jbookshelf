/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.shortcut;

import java.util.Iterator;
import java.util.LinkedList;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

/**
 * Provides an action based shortcut.
 * 
 * <p>The action has to provide several values to make use of the shortcut.</p>
 * 
 * <p>It must provide the following values:</p>
 * 
 * <p>Action.ACTION_COMMAND_KEY, the preferences key</p>
 *
 * <p>It should provide values for the following keys:</p>
 * 
 * <pre>
 * </pre>
 */
public class ActionShortcut extends AbstractShortcut
{

	private Action action;

	private LinkedList<JComponent> components = new LinkedList<JComponent>();
	private JMenuItem menuItem;
	
    public ActionShortcut(Action action, JComponent c) 
    {
    	this.action = action;
		addComponent(c, action);
    }   

	public ActionShortcut(Action action) 
	{
		if (action == null) {
			throw new NullPointerException("action must not be null");
		}
		this.action = action;
	}
	
	/**
	 * Installs the action into the action map of the component and sets up
	 * the shortcut mapping.  
	 */
	public void addComponent(JComponent c, Action a)
	{
		// install action into action map
		c.getActionMap().put(this, a);
		components.add(c);
		setKeyStroke(getKeyStroke(), c);
	}

	public JMenuItem getMenuItem()
	{
		return menuItem;
	}

	public Action getAction()
	{
		return action;
	}
	
	public void setMenuItem(JMenuItem menuItem)
	{
		if (this.menuItem != null) {
			this.menuItem.setAccelerator(null);
		}
		this.menuItem = menuItem;
		if (this.menuItem != null) {
			this.menuItem.setAccelerator(getKeyStroke());
		}
	}

	/**
	 * Removes the action mapping from the given component and removes it
	 * from its list of components.
	 * @param c the component this shortcuts is registered on
	 */
	public void removeComponent(JComponent c)
	{
		// remove action from action map
		c.getActionMap().remove(this);
		components.remove(c);
	}

	/**
	 * Returns the number of components this shortcut is registered upon.
	 */
	public int getNumberOfComponents()
	{
		return components.size();
	}

	private void setKeyStroke(KeyStroke stroke, JComponent c)
	{
		InputMap m = c.getInputMap
			(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);

		// remove old mapping
		if (getKeyStroke() != null) {
			m.remove(getKeyStroke());
		}
		// install new mapping
		if (stroke != null) {
			m.put(stroke, this);
		}
	}

    public void setKeyStroke(KeyStroke stroke) 
    {
		for (Iterator<JComponent> i = components.iterator(); i.hasNext();) {
			setKeyStroke(stroke, i.next());
		}
		if (menuItem != null) {
			menuItem.setAccelerator(stroke);
		}
		super.setKeyStroke(stroke);
    }
}

