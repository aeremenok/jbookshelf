/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.util;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.JTree;

/**
 * Convenience class for a double click listener in a table. Use it like this:
 * 
 * <pre>
 * table.addMouseListener(new DoubleClickListener(action));
 * </pre>
 */
public class DoubleClickListener extends MouseAdapter {
    
	public static final int DOUBLE_CLICK_ID = 0;
	
    private String actionCommand;
    private List<ActionListener> listeners = new ArrayList<ActionListener>();
    
    public DoubleClickListener() 
    {
    }

    public DoubleClickListener(ActionListener listener)
    {
		addActionListener(listener);
    }
        
	public void addActionListener(ActionListener listener)
    {
    	listeners.add(listener);
    }
	
	public String getActionCommand()
	{
		return actionCommand;
	}

	public void mousePressed(MouseEvent e) 
    {
    	Component component = e.getComponent();
		if (e.getClickCount() == 2) {
			int row = 0;
			if (component instanceof JTable) {
				row = ((JTable)component).rowAtPoint(e.getPoint());
				//jta.getSelectionModel().setSelectionInterval(row, row);
			}
			else if (component instanceof JList) {
				row = ((JList)component).locationToIndex(e.getPoint());
			}
			else if (component instanceof JTree) {
				row = ((JTree)component).getRowForLocation(e.getX(), e.getY());
			}

			if (row != -1) {
				ActionListener[] array = listeners.toArray(new ActionListener[0]);
				if (array.length > 0) {
					ActionEvent event = new ActionEvent(component, DOUBLE_CLICK_ID, getActionCommand());
					for (int i = array.length - 1; i >= 0; i--) {
						array[i].actionPerformed(event);
					}
				}
			}
        }
    }

    public void removeActionListener(ActionListener listener)
    {
    	listeners.remove(listener);
    }

    public void setActionCommand(String actionCommand)
	{
		this.actionCommand = actionCommand;
	}
    
}

