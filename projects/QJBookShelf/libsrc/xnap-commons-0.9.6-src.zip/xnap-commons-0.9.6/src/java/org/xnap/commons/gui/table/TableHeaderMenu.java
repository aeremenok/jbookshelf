/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.table;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import org.xnap.commons.gui.Builder;
import org.xnap.commons.gui.action.AbstractToggleAction;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * Used for menus that control table column visibility.
 */
public class TableHeaderMenu extends JMenu
{
    
    private List<AbstractButton> buttons = new ArrayList<AbstractButton>();
	private TableLayout tableLayout;
	private TableLayoutListener layoutListener;
	private CheckBoxHandler checkBoxListener;
	private MaintainSortOrderAction sortOrderAction;

    public TableHeaderMenu(String name, TableLayout tableLayout, int skip)
    {
		super(name);

		layoutListener = new TableLayoutHandler();
		checkBoxListener = new CheckBoxHandler();
		
		setTableLayout(tableLayout);
    }

	public TableHeaderMenu(String name, TableLayout handler)
	{
		this(name, handler, 0);
	}
	
    /**
     * Updates buttons.
     */
    public void updateVisibleColumns()
    {
		
		/*
		HashSet visiblesKeys 
			= new HashSet(Arrays.asList(tpp.getTableColumns(table)));

		for (Iterator i = buttons.iterator(); i.hasNext();) {
			JCheckBoxMenuItem jcb = (JCheckBoxMenuItem)i.next();
			jcb.setSelected(visiblesKeys.contains(jcb.getActionCommand()));
		}
		*/
    }

	public void setTableLayout(TableLayout tableLayout) 
	{
		if (this.tableLayout != null) {
			this.tableLayout.removeTableLayoutListener(layoutListener);
			
			for (AbstractButton button : buttons) {
				button.removeActionListener(checkBoxListener);
				remove(button);
			}
			buttons.clear();
			
			// TODO remove the maintain sort order items from the menu as well
		}
		this.tableLayout = tableLayout;
		if (this.tableLayout != null) {
			for (int i = 0; i < tableLayout.getColumnCount(); i++) {
				JCheckBoxMenuItem checkBox = new JCheckBoxMenuItem(tableLayout.getColumnAt(i).getHeaderValue().toString());
				checkBox.setActionCommand(Integer.toString(i));
				checkBox.addActionListener(checkBoxListener);
				checkBox.setSelected(tableLayout.isColumnVisible(i));
				buttons.add(checkBox);
				add(checkBox);
			}

			sortOrderAction = new MaintainSortOrderAction();
			addSeparator();
			add(Builder.createMenuItem(sortOrderAction));

			updateVisibleColumns();
			tableLayout.addTableLayoutListener(layoutListener);
		}
	}

    private class TableLayoutHandler implements TableLayoutListener
    {
		public void columnLayoutChanged()
		{
		}

		public void sortedColumnChanged()
		{
		}

		public void columnOrderChanged()
		{
		}

		public void columnNameChanged(int index, String newName)
		{
			buttons.get(index).setText(newName);
		}

		public void columnVisibilityChanged(int index, boolean visible)
		{
			buttons.get(index).setSelected(visible);
		}

		public void maintainSortOrderChanged(boolean newValue)
		{
			if (sortOrderAction != null) {
				sortOrderAction.setSelected(newValue);
			}
		}
		
    }

    private class CheckBoxHandler implements ActionListener
    {
		public void actionPerformed(ActionEvent event)
		{
			JCheckBoxMenuItem checkBox = (JCheckBoxMenuItem)event.getSource();
			if (!checkBox.isSelected() && tableLayout.getVisibleColumnsCount() == 1) {
				// make sure that there is always at least a single column visible
				checkBox.setSelected(true);
				return;
			}
			
			int index = Integer.parseInt(checkBox.getActionCommand());
			tableLayout.setColumnVisible(index, checkBox.isSelected());
		}
    }

	/**
	 * Provides an action that enables or disables the maintain sort order 
	 * setting of a table.
	 */
	protected class MaintainSortOrderAction extends AbstractToggleAction 
	{
	    public MaintainSortOrderAction()
	    {
	    	I18n i18n = I18nFactory.getI18n(TableHeaderMenu.class);
			putValue(Action.NAME, i18n.tr("Maintain Sort Order"));
			putValue(Action.SHORT_DESCRIPTION,
					 i18n.tr("If enabled, the sort order will be maintained as newitems are added to the table"));
	    }

	    public void toggled(boolean visible) 
	    {
			tableLayout.setMaintainSortOrder(visible);
	    }
	}

}
