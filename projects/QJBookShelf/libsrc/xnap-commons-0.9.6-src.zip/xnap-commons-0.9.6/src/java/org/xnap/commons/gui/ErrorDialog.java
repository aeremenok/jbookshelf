/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.io.ByteArrayOutputStream;
import java.io.PrintWriter;
import java.text.MessageFormat;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import org.xnap.commons.gui.action.AbstractToggleAction;
import org.xnap.commons.gui.action.AbstractXNapAction;
import org.xnap.commons.gui.util.GUIHelper;
import org.xnap.commons.gui.util.IconHelper;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.settings.BooleanSetting;
import org.xnap.commons.util.UncaughtExceptionManager;

/**
 * A dialog to display error messages. The dialog displays a prominent icon 
 * along with an error message.  
 * 
 * @author Steffen Pingel
 */
public class ErrorDialog extends DefaultDialog {

	private static I18n i18n = I18nFactory.getI18n(ErrorDialog.class);
	
	private JPanel detailsPanel;
	private JTextArea detailsTextArea;

	private JCheckBox doNotShowExceptionAgainCheckBox;
	private JCheckBox doNotShowDialogAgainCheckBox;
	
	private ContinueAction continueAction = new ContinueAction();
    private DetailsAction detailsAction;
    private ExitAction exitAction = new ExitAction();
    private SendAction sendAction;
    
	private List<Thread> threads = new LinkedList<Thread>();
	private List<Throwable> throwables = new LinkedList<Throwable>();

	/**
	 * If true, the dialog can not handle more exceptions.
	 */
	private boolean busy = false;
	private UncaughtExceptionManager exceptionManager;
	private BooleanSetting detailsVisibleSetting;
	private BooleanSetting showDialogAgainSetting;

	/**
	 * TODO clean this mess and make constructor public
	 * @param description
	 * @param exceptionManager
	 * @param showExitAction
	 * @param showDialogAgainSetting
	 * @param detailsVisibleSetting
	 */
    ErrorDialog(String description, UncaughtExceptionManager exceptionManager,
			boolean showExitAction,
			BooleanSetting showDialogAgainSetting, 
			BooleanSetting detailsVisibleSetting)
    {
		super(BUTTON_NONE);

		this.exceptionManager = exceptionManager;
		this.showDialogAgainSetting = showDialogAgainSetting;
		this.detailsVisibleSetting = detailsVisibleSetting;
		
		Box mainBox = Box.createVerticalBox();
		setMainComponent(mainBox);
		
		
		// top	
		JLabel infoLabel = new JLabel(GUIHelper.tt(description), 
									  IconHelper.getIcon("error.png", 32),
									  SwingConstants.LEADING);
		infoLabel.setIconTextGap(10);
		infoLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
		mainBox.add(infoLabel);
		mainBox.add(Box.createVerticalStrut(10));
		
		// details, instantiate prior to action
		detailsPanel = new JPanel(new BorderLayout());
		detailsPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		updateBorder();

		detailsTextArea = new JTextArea(12, 80);
		detailsTextArea.setEditable (false);
		detailsTextArea.setFont(new Font("Monospaced", Font.PLAIN, 10));
		detailsPanel.add(new JScrollPane(detailsTextArea), BorderLayout.CENTER);

		// details button
		JPanel detailsButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		detailsButtonPanel.setAlignmentX(Component.LEFT_ALIGNMENT);
		mainBox.add(detailsButtonPanel);
		
		detailsAction = new DetailsAction((detailsVisibleSetting != null) ? detailsVisibleSetting.getValue() : false);
		detailsButtonPanel.add(Builder.createButton(detailsAction));

		// add details panel
		mainBox.add(detailsPanel);
		
		// check boxes
		if (exceptionManager != null) {
			doNotShowExceptionAgainCheckBox 
				= new JCheckBox(i18n.tr("Do not show this exception again"));
			doNotShowExceptionAgainCheckBox.setAlignmentX(Component.LEFT_ALIGNMENT);
			mainBox.add(doNotShowExceptionAgainCheckBox);
		}
		
		if (showDialogAgainSetting != null) {
			doNotShowDialogAgainCheckBox 
				= new JCheckBox(i18n.tr("Do not show this dialog again"),
								showDialogAgainSetting.getValue());
			doNotShowDialogAgainCheckBox.setAlignmentX(Component.LEFT_ALIGNMENT);
			mainBox.add(doNotShowDialogAgainCheckBox);
		}
			
		if (exceptionManager != null) {
			sendAction = new SendAction();
			getButtonPanel().add(Builder.createButton(sendAction));
		}
		GUIHelper.bindEscapeKey(getTopPanel(), continueAction);
		getButtonPanel().add(Builder.createButton(continueAction));
		if (showExitAction) {
			getButtonPanel().add(Builder.createButton(exitAction));
		}
    }

    public ErrorDialog(String description)
    {
    	this(description, null, false, null, null);
    }
    
    ErrorDialog()
    {
    	// XXX what the hell, if we remove this, ErrorHandle gets really upset
    }
    
	public void add(Thread t, Throwable e)
	{
		threads.add(t);
		throwables.add(e);

		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintWriter writer = new PrintWriter(out);
		e.printStackTrace(writer);
		writer.close();
		
		detailsTextArea.append(out.toString() + "\n");

		if (threads.size() == 1) {
			resetCaretPosition();
		}
		
		updateBorder();
	}

	public void close()
	{
		/*
		prefs.set("errorDialogWidth", getBounds().getSize().width);
		prefs.set("errorDialogHeight", getBounds().getSize().height);
		*/
		
		if (showDialogAgainSetting != null) {
			showDialogAgainSetting.setValue(!doNotShowDialogAgainCheckBox.isSelected());
		}
		if (detailsVisibleSetting != null) {
			detailsVisibleSetting.setValue(detailsPanel.isVisible());
		}
		
		if (exceptionManager != null && doNotShowExceptionAgainCheckBox.isSelected()) {
			for (Iterator<Throwable> it = throwables.iterator(); it.hasNext();) {
				exceptionManager.addToBlacklist(it.next());
			}
		}
		
		busy = true;
		dispose();
	}
	
	public boolean isBusy()
	{
		return busy;
	}

	public void resetCaretPosition()
	{
		detailsTextArea.setCaretPosition(0);
	}
	
	public void updateBorder()
	{
		detailsPanel.setBorder
			(GUIHelper.createDefaultBorder
			 (i18n.trn("Details - {0} Problem", "Details - {0} Problems", threads.size())));
	}

	public static void show(Component c, String message, String title,
							Throwable e)
	{
		ErrorDialog d = new ErrorDialog(message);
		d.setTitle(title);
		d.pack();
		d.setModal(true);
		d.add(Thread.currentThread(), e);
		d.show(c);
	}

	public static void showError(Component c, String message, String title,
			Throwable e)
	{
		if (e.getLocalizedMessage() != null) {
			show(c, MessageFormat.format("{0}:<br><br>{1}", new Object[] {
				message, e.getLocalizedMessage()}), title, e);
		}
		else {
			show(c, message, title, e);
		}
	}

	public static void showUnexpected(Component c, String message, String title,
			Throwable e)
	{
		ErrorDialog d = new ErrorDialog(message, null, true, null, null);
		d.setTitle(title);
		d.pack();
		d.setModal(true);
		d.add(Thread.currentThread(), e);
		d.show(c);
	}

    private class DetailsAction extends AbstractToggleAction
    {
        public DetailsAction(boolean visible)
		{
        	super(visible);
        	
            putValue(Action.NAME, i18n.tr("Show Details"));
            putValue(ICON_FILENAME, "2downarrow.png");

			toggled(isSelected());
        }

        public void toggled(boolean visible)
		{
			detailsPanel.setVisible(visible);
			pack();
		}

    }

    private class ContinueAction extends AbstractXNapAction
    {
        public ContinueAction()
		{
            putValue(Action.NAME, i18n.tr("Continue"));
            putValue(ICON_FILENAME, "1rightarrow.png");
        }

        public void actionPerformed(ActionEvent event) 
		{
			close();
        }

    }

    private class ExitAction extends AbstractXNapAction {
    	
        public ExitAction()
		{
            putValue(Action.NAME, i18n.tr("Quit"));
            putValue(ICON_FILENAME, "exit.png");
            putValue(Action.SHORT_DESCRIPTION, 
					 i18n.tr("Quits the application"));
        }

        public void actionPerformed(ActionEvent event) 
		{
			close();
			System.exit(1);
        }

    }

    private class SendAction extends AbstractXNapAction
    {
        public SendAction()
		{
            putValue(Action.NAME, i18n.tr("Send Report"));
            putValue(ICON_FILENAME, "mail_send.png");
            putValue(Action.SHORT_DESCRIPTION, 
					 i18n.tr("Sends the details to a remote site for analysis"));
        }

        public void actionPerformed(ActionEvent event) 
		{
			busy = true;

			Thread t = new Thread(new SendWorker(), "SendFeedback");
			t.start();
        }
    }

    private class SendWorker implements Runnable
    {

		public void run()
		{
			sendAction.setEnabled(false);
			getCancelAction().setEnabled(false);

			setTitle(i18n.tr("Sending Error Report") + "...");
/*
			try {
				Iterator i1 = threads.iterator();
				Iterator i2 = throwables.iterator();
				while (i1.hasNext() && i2.hasNext()) {
					exceptionManager.sendProblemReport
						((Thread)i1.next(), (Throwable)i2.next());
				}
			}
			catch(final IOException e) {
				Runnable runner = new Runnable()
					{
						public void run()
						{
							failed(NetHelper.getErrorMessage(e));
						}
					};
				SwingUtilities.invokeLater(runner);
				return;
			}
*/
			Runnable runner = new Runnable()
				{
					public void run()
					{
						JOptionPane.showMessageDialog
							(ErrorDialog.this, i18n.tr("Thank you."),
							 i18n.tr("XNap Error"), 
							 JOptionPane.INFORMATION_MESSAGE);
						close();
					}
				};
			SwingUtilities.invokeLater(runner);
		}

		public void failed(String response)
		{
			JOptionPane.showMessageDialog
				(ErrorDialog.this, 
				 i18n.tr("Could not send error report: {0}.", response),
				 i18n.tr("XNap Error"), 
				 JOptionPane.ERROR_MESSAGE);
			
			setTitle(i18n.tr("XNap Error"));

			sendAction.setEnabled(true);
			getCancelAction().setEnabled(true);

			busy = false;
		}
    }

}







