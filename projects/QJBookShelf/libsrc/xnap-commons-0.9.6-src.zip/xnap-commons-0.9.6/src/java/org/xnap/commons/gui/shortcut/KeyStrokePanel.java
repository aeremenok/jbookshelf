/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.shortcut;

import java.awt.BorderLayout;
import java.awt.Event;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JToggleButton;
import javax.swing.KeyStroke;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import org.xnap.commons.gui.Builder;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * A panel to enter a keystroke.
 * 
 * @author Steffen Pingel
 */
public class KeyStrokePanel extends JPanel implements ActionListener {
    
	private static I18n i18n = I18nFactory.getI18n(KeyStrokePanel.class);
	
	public static String toString(KeyStroke stroke)
	{
		StringBuilder sb = new StringBuilder();

		int m = stroke.getModifiers();
		if ((m & Event.CTRL_MASK) != 0) {
			sb.append(KeyEvent.getKeyModifiersText(Event.CTRL_MASK));
			sb.append("+");
		}
		if ((m & Event.ALT_MASK) != 0) {
			sb.append(KeyEvent.getKeyModifiersText(Event.ALT_MASK));
			sb.append("+");
		}
		if ((m & Event.META_MASK) != 0) {
			sb.append(KeyEvent.getKeyModifiersText(Event.META_MASK));
			sb.append("+");
		}
		if ((m & Event.SHIFT_MASK) != 0) {
			sb.append(KeyEvent.getKeyModifiersText(Event.SHIFT_MASK));
			sb.append("+");
		}
		sb.append(KeyEvent.getKeyText(stroke.getKeyCode()));
		return sb.toString();
	}
	
    private JCheckBox altCheckBox;
	protected transient ChangeEvent changeEvent;
	private JToggleButton charButton;
	private JCheckBox ctrlCheckBox;
	private KeyStroke defaultKeyStroke;
	private int keyCode;
	private CharButtonListener keyListener = new CharButtonListener();
    private JCheckBox metaCheckBox;
    private JCheckBox shiftCheckBox;
	private DefaultAction defaultAction;
	private NoneAction noneAction;

	public KeyStrokePanel()
    {
		defaultAction = new DefaultAction();
		noneAction = new NoneAction();
		
		setLayout(new BorderLayout());

		// check boxes
		JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		add(topPanel, BorderLayout.NORTH);
		
		ctrlCheckBox 
			= new JCheckBox(KeyEvent.getKeyModifiersText(Event.CTRL_MASK));
		ctrlCheckBox.addActionListener(this);
		topPanel.add(ctrlCheckBox);

		altCheckBox 
			= new JCheckBox(KeyEvent.getKeyModifiersText(Event.ALT_MASK));
		altCheckBox.addActionListener(this);
		topPanel.add(altCheckBox);

		metaCheckBox
			= new JCheckBox(KeyEvent.getKeyModifiersText(Event.META_MASK));
		metaCheckBox.addActionListener(this);
		topPanel.add(metaCheckBox);
		
		shiftCheckBox
			= new JCheckBox(KeyEvent.getKeyModifiersText(Event.SHIFT_MASK));
		shiftCheckBox.addActionListener(this);
		topPanel.add(shiftCheckBox);

		charButton = new JToggleButton(" ");
		charButton.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent event)
			{
				if (event.getStateChange() == ItemEvent.SELECTED) {
					// record the key that is pressed next
					charButton.addKeyListener(keyListener);
				}
				else {
					charButton.removeKeyListener(keyListener);
					fireChangeEvent();
				}
			}
		});
		charButton.addFocusListener(new UntoggleListener());
		topPanel.add(charButton);
		
		// buttons
		JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		add(bottomPanel, BorderLayout.SOUTH);
		
		bottomPanel.add(Builder.createButton(defaultAction));
		bottomPanel.add(Builder.createButton(noneAction));
    }

    /**
	 *  @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e)
	{
		fireChangeEvent();
	}
    
    public void addChangeListener(ChangeListener l) 
    {
        listenerList.add(ChangeListener.class, l);
    }

    protected void fireChangeEvent() {
        Object[] listeners = listenerList.getListenerList();

        for (int i = listeners.length - 2; i >= 0; i -= 2) {
            if (listeners[i] == ChangeListener.class) {
				// Lazily create the event:
                if (changeEvent == null) {
                    changeEvent = new ChangeEvent(this);
                }
                ((ChangeListener)listeners[i + 1]).stateChanged(changeEvent);
            }          
        }
    }   

    public KeyStroke getKeyStroke()
	{
    	if (keyCode == KeyEvent.VK_UNDEFINED) {
			return null;
    	}
    	else {
    		int m = 0;
    		m |= (ctrlCheckBox.isSelected()) ? Event.CTRL_MASK : 0;
    		m |= (altCheckBox.isSelected()) ? Event.ALT_MASK : 0;
    		m |= (metaCheckBox.isSelected()) ? Event.META_MASK : 0;
    		m |= (shiftCheckBox.isSelected()) ? Event.SHIFT_MASK : 0;
    		return KeyStroke.getKeyStroke(keyCode, m);
    	}
    }
    
    public void removeChangeListener(ChangeListener l) 
    {
        listenerList.remove(ChangeListener.class, l);
    }

    @Override
    public void setEnabled(boolean enabled)
    {
    	super.setEnabled(enabled);

		ctrlCheckBox.setEnabled(enabled);
		altCheckBox.setEnabled(enabled);
		metaCheckBox.setEnabled(enabled);
		shiftCheckBox.setEnabled(enabled);
		charButton.setEnabled(enabled);
		
		defaultAction.setEnabled(enabled);
		noneAction.setEnabled(enabled);
    }
    
	public void setDefaultKeyStroke(KeyStroke defaultKeyStroke)
	{
		this.defaultKeyStroke = defaultKeyStroke;
	}

	public void setKeyStroke(KeyStroke keyStroke)
	{
		if (keyStroke != null) {
			int m = keyStroke.getModifiers();
			ctrlCheckBox.setSelected((m & Event.CTRL_MASK) != 0);
			altCheckBox.setSelected((m & Event.ALT_MASK) != 0);
			metaCheckBox.setSelected((m & Event.META_MASK) != 0);
			shiftCheckBox.setSelected((m & Event.SHIFT_MASK) != 0);
			keyCode = keyStroke.getKeyCode();
			charButton.setText(KeyEvent.getKeyText(keyCode));
		}
		else {
			ctrlCheckBox.setSelected(false);
			altCheckBox.setSelected(false);
			metaCheckBox.setSelected(false);
			shiftCheckBox.setSelected(false);
			charButton.setText(" ");
			keyCode = KeyEvent.VK_UNDEFINED;
		}
	}

	private class CharButtonListener extends KeyAdapter {

		public void keyPressed(KeyEvent e) 
		{
			keyCode = e.getKeyCode();
			
			charButton.setSelected(false);
			charButton.setText(KeyEvent.getKeyText(keyCode));
			//  charButton.setText(KeyStroke.getKeyStrokeForEvent(e).toString());
		}

	}

    /**
     * Reperforms a search.
     */
    private class DefaultAction extends AbstractAction {

        public DefaultAction() 
		{
            putValue(Action.NAME, i18n.tr("Default"));
            putValue(Action.SHORT_DESCRIPTION, i18n.tr("Reset to default"));
        }

        public void actionPerformed(ActionEvent event) 
		{
			setKeyStroke(defaultKeyStroke);
			fireChangeEvent();
        }
    }

    /**
     * Reperforms a search.
     */
    private class NoneAction extends AbstractAction {

        public NoneAction() 
		{
            putValue(Action.NAME, i18n.tr("None"));
            putValue(Action.SHORT_DESCRIPTION,
					 i18n.tr("Assigns no keystroke"));
        }

        public void actionPerformed(ActionEvent event) 
		{
        	setKeyStroke(null);
			fireChangeEvent();
		}
        
    }

	private class UntoggleListener extends FocusAdapter {

		public void focusLost(FocusEvent e)
		{
			charButton.setSelected(false);
		}

	}

}
