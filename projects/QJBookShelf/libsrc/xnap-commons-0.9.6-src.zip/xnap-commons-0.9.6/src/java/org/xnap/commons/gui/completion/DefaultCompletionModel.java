/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;
import javax.swing.DefaultComboBoxModel;

/**
 * This classl uses a ternary search tree for completion.
 * <p>
 * You can easily add arrays of objects to it and remove single object if
 * they should not show up as possible completions anymore.
 * <p>
 * A {@link #toArray()} method gives access to all objects stored in the model
 * and can be used for serialization.
 * <p>
 * See also {@link org.xnap.commons.settings.CompletionSettingDirector}.
 * 
 * @author Felix Berger
 */
public class DefaultCompletionModel extends DefaultComboBoxModel
    implements CompletionModel
{
    private CharNode root = null;

    /**
     * Constructs a new model with no items.
     */
    public DefaultCompletionModel() 
	{
	}

    /**
     * Constructs a new model using the given items for completion.
     *
     * @param items the objects used for completion
     */
    public DefaultCompletionModel(Object[] items)
    {
        this(items, false);
    }

    /**
     * Constructs a new model using the given items for completion.
     *
     * @param items the array of objects used for completion
     * @param sorted whether the array of items is sorted or not
     */
    public DefaultCompletionModel(Object[] items, boolean sorted)
    {
        insert(items, sorted);
    }

    public boolean complete(String prefix)
    {
        removeAllElements();

        if (prefix.length() == 0) {
            //  collectElements(root);
        }
        else {
            CharNode node = search(prefix);

            if (node != null) {
                if (node.obj != null) {
                    addElement(node.obj);
                }
                collectElements(node.eqkid);
            }
        }
        return getSize() > 0;
    }

    public String completeUniquePrefix(String prefix)
    {
        CharNode node = search(prefix);

        if (node != null && node.obj == null && node.eqkid != null) {
            StringBuilder sb = new StringBuilder(prefix);
			node = node.eqkid;

            while ((node != null) && (node.lokid == null) 
				   && (node.hikid == null)) {
                sb.append(node.splitchar);
				if (node.obj != null) {
					break;
				}
                node = node.eqkid;
            }
            return sb.toString();
        }
        return prefix;
    }

    /**
     * Adds an object to the completion model's ternary search tree.
	 *
	 * The object is inserted using its {@link Object#toString()} method. If
	 * another object with the same name exists it is simply replaced by this
	 * one, no equality tests are carried out.
     *
     * @param object the object which is completed using its {@link
     * Object#toString()} method 
	 */
    public void insert(Object object)
    {
        char[] key = object.toString().toCharArray();
        root = insert(root, key, 0, object);
    }
    
    /**
     * Adds an array of objects to the completion model's ternary search tree.
     * 
     * For large arrays adding the items in one chunk is recommended, this
     * ensures the search tree is more balanced.
     * 
     * @param items the array of objects used for completion
     * @param sorted whether the array of items is sorted or not
     */
    public void insert(Object[] items, boolean sorted)
    {
    	if (!sorted) {
            Arrays.sort(items, new StringComparator());
        }
        insert(items, 0, items.length);
    }

    /**
     * Adds an array of objects to the completion model's ternary search tree.
     * 
     * The array will be sorted before it is added.
     * 
     * @param items the array of objects used for completion
     * @see #insert(Object[], boolean)
     */
    public void insert(Object[] items)
    {
    	insert(items, false);
    }

	/**
	 * Removes the object from the ternary search tree.
	 * 
	 * Equality is tested with the {@link Object#equals(Object)} method.
	 * 
	 * @param object the object to be removed from the search tree
	 */
    public void remove(Object object)
    {
		CharNode node = root;
        int index = 0;
		Stack<CharNode> stack = new Stack<CharNode>();
		String prefix = object.toString();
		int prefixLength = prefix.length();

        while (node != null && index < prefixLength) {
			stack.push(node);
            char c = prefix.charAt(index);

            if (c < node.splitchar) {
                node = node.lokid;
            }
            else if (c == node.splitchar) {
                if (index == (prefixLength - 1)) {
                    break;
                }
                else {
                    node = node.eqkid;
                    index++;
                }
            }
            else {
                node = node.hikid;
            }
        }
		
        // cleanup, free nodes
		if (node != null && node.obj.equals(object)) {
			node.obj = null;
			stack.pop();
			while (node.obj == null && node.lokid == null
				   && node.hikid == null && !stack.empty()) {
				node.eqkid = null;
				node = stack.pop();
			}
		}
	}

    /**
     * Returns an array containing all of the elements in this completion model.
     * 
     * The array's elements are sorted alphabetically according to the return 
     * values of {@link Object#toString()}.
     * 
     * @return an array containing all of the elements in this completion model
     */
    public Object[] toArray()
    {
    	List<Object> list = new LinkedList<Object>();
    	collectElements(root, list);
    	return list.toArray();
    }
    
    /**
     * Clears the model.
     * <p>
     * Subsequent calls to {@link #complete(String)} will return 
     * <code>false</code>.
     */
    public void clear()
    {
    	root = null;
    }
    
    /**
     * Adds all child elements of the node to a collection in preorder fashion.
     * @param node
     * @param col
     */
    private void collectElements(CharNode node, Collection<Object> col)
    {
    	if (node != null) {
    		collectElements(node.lokid, col);
    		if (node.obj != null) {
    			col.add(node.obj);
    		}
    		collectElements(node.eqkid, col);
    		collectElements(node.hikid, col);
    	}
    }
    
    /**
     * Traverses the tree preorder wise and adds all elements to the model.
     */
    private void collectElements(CharNode node)
    {
        if (node != null) {
            collectElements(node.lokid);

            if (node.obj != null) {
                addElement(node.obj);
            }
            collectElements(node.eqkid);
            collectElements(node.hikid);
        }
    }

    private void insert(Object[] items, int left, int right)
    {
        if (left < right) {
            int m = left + (int)Math.floor((right - left) / 2);
            insert(items[m]);
            insert(items, left, m);
            insert(items, m + 1, right);
        }
    }

    private CharNode insert(CharNode node, char[] key, int index, Object object)
    {
        if (node == null) {
            node = new CharNode(key[index]);

            if (index == (key.length - 1)) {
                node.obj = object;
            }
        }

        if (key[index] < node.splitchar) {
            node.lokid = insert(node.lokid, key, index, object);
        }
        else if (key[index] == node.splitchar) {
            if (++index < key.length) {
                node.eqkid = insert(node.eqkid, key, index, object);
            }
            else {
                // the newly inserted object replaces the old one
                node.obj = object;
            }
        }
        else {
            node.hikid = insert(node.hikid, key, index, object);
        }

        return node;
    }

    /**
     * Returns node.
     */
    private CharNode search(String prefix)
    {
        CharNode node = root;
        int index = 0;
        int prefixLength = prefix.length();
        

        while (node != null && index < prefixLength) {
            //logger.debug("Visiting " + node.obj);

            char c = prefix.charAt(index);
            //logger.debug("checking char " + c);

            if (c < node.splitchar) {
                node = node.lokid;
            }
            else if (c == node.splitchar) {
                if (index == (prefixLength - 1)) {
                    return node;
                }
                else {
                    node = node.eqkid;
                    index++;
                }
            }
            else {
                node = node.hikid;
            }
        }

        return node;
    }

    /**
     * Implementation of ternary search trees.
     */
    private class CharNode
    {
        public char splitchar;
        public CharNode lokid;
        public CharNode eqkid;
        public CharNode hikid;
        public Object obj;

        public CharNode(char value)
        {
            splitchar = value;
        }
    }
    
    /**
     *  Comparator used for sorting the elements which are inserted.
     */
    private class StringComparator implements Comparator<Object>
	{
    	public int compare(Object obj1, Object obj2)
    	{
			return obj1.toString().compareTo(obj2.toString());
    		
    	}
	}
}
