/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.event.ActionEvent;
import javax.swing.Action;
import javax.swing.JTextField;
import org.xnap.commons.gui.action.AbstractXNapAction;
import org.xnap.commons.i18n.I18nFactory;

/**
 * Erases the text of a {@link javax.swing.JTextField JTextField}.
 */
public class EraseTextFieldAction extends AbstractXNapAction {

    private JTextField textField;
    
    /**
     * Constructs an erase action, that has its text field set to
     * <code>jtf</code>.  
     *
     * @param textField the text field to erase
     */
    public EraseTextFieldAction(JTextField textField) 
    {
		this.textField = textField;
	
		putValue(Action.SHORT_DESCRIPTION, 
				I18nFactory.getI18n(EraseTextFieldAction.class).tr("Erases text"));
		putValue(ICON_FILENAME, "locationbar_erase.png");
    }

    /**
     * Constructs an erase action, that has no text field set. Use 
     * {@link #setTextField(JTextField) setTextField} to set a text field.
     */
    public EraseTextFieldAction()
    {
		this(null);
    }

    /**
     * Erases the text field.
     */
    public void actionPerformed(ActionEvent event) 
    {
		if (textField != null) {
			textField.setText("");
			textField.grabFocus();
		}
    }

    public JTextField getTextField()
    {
    	return textField;
    }
    
    /**
     * Sets the text field to <code>newValue</code>.
     */
    public void setTextField(JTextField newValue)
    { 
		textField = newValue;
    }

}
