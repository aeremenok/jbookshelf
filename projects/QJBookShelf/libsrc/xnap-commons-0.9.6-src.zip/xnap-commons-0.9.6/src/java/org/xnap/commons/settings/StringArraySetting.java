/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import org.xnap.commons.util.QuotedStringTokenizer;

/**
 * Provides a setting for arrays of <code>String</code> objects.
 */
public class StringArraySetting extends AbstractSetting<String[]> {

    public StringArraySetting(SettingResource backend, String key, String[] defaultValue, Validator validator)
    {
    	super(backend, key, defaultValue, validator);
    }

    public StringArraySetting(SettingResource backend, String key, String[] defaultValue)
    {
    	super(backend, key, defaultValue, null);
    }

    protected String[] fromString(String value)
	{
		QuotedStringTokenizer t = new QuotedStringTokenizer(value, ARRAY_SEPARATOR);

		String[] values = new String[t.countTokens()];
		for (int i = 0; i < values.length; i++) {
			values[i] = t.nextToken();
		}
		return values;
	}

	protected String toString(String[] value)
	{
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < value.length; i++) {
			sb.append(QuotedStringTokenizer.QUOTE);
			sb.append(value[i]);
			sb.append(QuotedStringTokenizer.QUOTE);
			sb.append(ARRAY_SEPARATOR);
		}
		return sb.toString();
	}

}
