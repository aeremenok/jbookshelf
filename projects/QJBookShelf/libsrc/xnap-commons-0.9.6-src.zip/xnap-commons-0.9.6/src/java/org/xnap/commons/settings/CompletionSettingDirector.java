/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import org.xnap.commons.gui.completion.Completion;
import org.xnap.commons.gui.completion.CompletionMode;
import org.xnap.commons.gui.completion.DefaultCompletionModel;

/**
 * @author Steffen Pingel
 */
public class CompletionSettingDirector
{
	
	private ClassNameSetting<CompletionMode> modeSetting;
	// TODO shouldn't we write out the objects themselves, instead of their strings
	private StringArraySetting dataSetting;

	public CompletionSettingDirector(SettingResource backstore, String key)
	{
		this.modeSetting = new ClassNameSetting<CompletionMode>(backstore, "completion." + key + ".mode", null);
		this.dataSetting = new StringArraySetting(backstore, "completion." + key + ".data", null);
	}

	public void save(Completion completion) 
	{
		if (!(completion.getModel() instanceof DefaultCompletionModel)) {
			throw new IllegalArgumentException("completion.getModel() must inherit DefaultCompletionModel");
		}

		modeSetting.setValue(completion.getMode());
		DefaultCompletionModel model = (DefaultCompletionModel)completion.getModel();
		Object[] objectData = model.toArray();
		String[] data = new String[objectData.length];
		for (int i = 0; i < objectData.length; i++) {
			data[i] = objectData[i].toString();
		}
		dataSetting.setValue(data);
	}
	
	public void restore(Completion completion)
	{
		if (!(completion.getModel() instanceof DefaultCompletionModel)) {
			throw new IllegalArgumentException("completion.getModel() must inherit DefaultCompletionModel");
		}
		
		CompletionMode mode = modeSetting.getValue();
		if (mode != null) {
			completion.setMode(mode);
		}
		String[] data = dataSetting.getValue();
		if (data != null) {
			DefaultCompletionModel model = (DefaultCompletionModel)completion.getModel();			
			model.insert(data);
		}
	}
	
}
