/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.util.StringTokenizer;

/**
 * Provides a setting for <code>Font</code> objects.
 */
public class IntArraySetting extends AbstractSetting<Integer[]> {

    public IntArraySetting(SettingResource backend, String key, Integer[] defaultValue, Validator validator)
    {
    	super(backend, key, defaultValue, validator);
    }

    public IntArraySetting(SettingResource backend, String key, Integer[] defaultValue)
    {
    	super(backend, key, defaultValue, null);
    }

    protected Integer[] fromString(String value)
	{
		StringTokenizer t = new StringTokenizer(value, ARRAY_SEPARATOR);

		try {
			Integer[] values = new Integer[t.countTokens()];
			for (int i = 0; i < values.length; i++) {
				values[i] = new Integer(t.nextToken());
			}
			return values;
		} 
		catch (NumberFormatException e) {
			return null;
		}
	}

	protected String toString(Integer[] value)
	{
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < value.length; i++) {
			sb.append(value[i]);
			sb.append(ARRAY_SEPARATOR);
		}
		return sb.toString();
	}

}
