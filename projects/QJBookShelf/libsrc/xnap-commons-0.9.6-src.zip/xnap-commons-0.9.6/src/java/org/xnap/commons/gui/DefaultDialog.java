/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.border.EmptyBorder;
import org.xnap.commons.gui.util.GUIHelper;
import org.xnap.commons.gui.util.WhatsThis;
import org.xnap.commons.gui.util.WhatsThisAction;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.util.SystemHelper;

/**
 * This class provides a default implementation for a dialog. A dialog consists
 * of two areas. The main area, located at the center of the dialog, contains
 * the user interaction components. The button area, located at the south
 * west of the dialog, is surrounded by an empty border and contains the 
 * buttons.
 *
 * <p>The most common buttons are provided with default actions.</p>
 *
 * <p>When you extend this class make sure <code>pack()</code> is called after
 * all components have been added.</p>
 */
public class DefaultDialog extends JDialog {
    
	// TODO can we make this enums, please, please? ;-)
	
	/* Yeah, but how would we implement that?
 
	public static enum Buttons { None, Okay, Cancel }
	static {
		Buttons[] button = new Buttons[] { Buttons.Okay, Buttons.Cancel }; 
	}
	*/
	
	private static final I18n i18n = I18nFactory.getI18n(DefaultDialog.class);

    /**
     * The button type for no buttons.
     */
    public static int BUTTON_NONE = 0;

    /**
     * The button type for the okay button.
     */
    public static int BUTTON_OKAY = 1;

    /**
     * The button type for the apply button.
     */
    public static int BUTTON_APPLY = 2;

    /**
     * The button type for the cancel button.
     */
    public static int BUTTON_CANCEL = 4;

    /**
     * The button type for the close button.
     */
    public static int BUTTON_CLOSE = 8;

    /**
     * The button type for the help button.
     */
    public static int BUTTON_HELP = 16;

	/**
	 * The button type for the context help button.
	 */
	public static int BUTTON_CONTEXT_HELP = 32;

	/**
	 * The button type for the defaults button.
	 */
	public static int BUTTON_DEFAULTS = 64;

    private ApplyAction applyAction = new ApplyAction();
    private CancelAction cancelAction = new CancelAction();
    private CloseAction closeAction = new CloseAction();
    private OkayAction okayAction = new OkayAction();
    private HelpAction helpAction = new HelpAction();
    private DefaultsAction defaultsAction = new DefaultsAction();
    private ContextHelpAction contextHelpAction = new ContextHelpAction();
    private JPanel buttonsLeftPanel;
    private JPanel buttonsRightPanel;
    private JPanel mainPanel;
	private JPanel topPanel;
	
    protected boolean isOkay = false;

	private JPanel bottomPanel;

	private JSeparator buttonSeparator;

    /**
     * Constructs a dialog showing the specified buttons and a
     * <code>mainComponent</code>.
     * @param owner the dialog owner
     * @param buttons the ored value of button codes, 
     * e.g BUTTON_CANCEL | BUTTON_OKAY
     * @param mainComponent the main component of the dialog, shown
     * in the center of the dialog.
     */
    public DefaultDialog(Dialog owner, int buttons, JComponent mainComponent)
    {
		super(owner);
		
		initialize(buttons, mainComponent);
    }

    /**
     * Constructs a dialog showing the specified buttons and a
     * <code>mainComponent</code>.
     * @param owner the dialog owner
     * @param buttons the ored value of button codes, 
     * e.g BUTTON_CANCEL | BUTTON_OKAY
     * @param mainComponent the main component of the dialog, shown
     * in the center of the dialog.
     */
    public DefaultDialog(Frame owner, int buttons, JComponent mainComponent)
    {
    	super(owner);
    	
    	initialize(buttons, mainComponent);
    }

    /**
     * Constructs a dialog. The escape key is by default bound to the cancel
     * button.
     *
     * @param buttons a logical and combination of button type constants
     * @param mainComponent the main component that is centered in the dialog
     */
    public DefaultDialog(int buttons, JComponent mainComponent)
    {
		initialize(buttons, mainComponent);
    }
   
    /**
     * Convenience wrapper for 
     * {@link DefaultDialog#DefaultDialog(Dialog, int, JComponent)
     * DefaultDialog(Dialog, int, null)}.
     */
    public DefaultDialog(Dialog owner, int buttons)
    {
		this(owner, buttons, null);
    }

    /**
     * Convenience wrapper for 
     * {@link DefaultDialog#DefaultDialog(Frame, int, JComponent)
     * DefaultDialog(Frame, int, null)}.
     */
    public DefaultDialog(Frame owner, int buttons)
    {
		this(owner, buttons, null);
    }

    /**
     * Convenience wrapper for 
     * {@link DefaultDialog#DefaultDialog(int, JComponent)
     * DefaultDialog(int, null)}.
     * @param buttons
     */
    public DefaultDialog(int buttons)
    {
		this(buttons, null);
    }

    /**
     * Convenience wrapper for
     * {@link DefaultDialog#DefaultDialog(Dialog, int)
     * DefaultDialog(Dialog, BUTTON_OKAY | BUTTON_CANCEL)}.
     */
    public DefaultDialog(Dialog owner)
    {
		this(owner, BUTTON_OKAY | BUTTON_CANCEL);
    }
    
    /**
     * Convenience wrapper for
     * {@link DefaultDialog#DefaultDialog(Frame, int)
     * DefaultDialog(Frame, BUTTON_OKAY | BUTTON_CANCEL)}.
     */
    public DefaultDialog(Frame owner)
    {
		this(owner, BUTTON_OKAY | BUTTON_CANCEL);
    }
    
    /**
     * Constructs a dialog with an okay and cancel button.
     */
    public DefaultDialog()
    {
		this(BUTTON_OKAY | BUTTON_CANCEL);
    }

    private void initialize(int buttons, JComponent mainComponent) {
		// the top most panel
		topPanel = new JPanel(new BorderLayout());
		topPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

		mainPanel = new JPanel();
		topPanel.add(mainPanel, BorderLayout.CENTER);
		if (mainComponent != null) {
			setMainComponent(mainComponent);
		}

		buttonsLeftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		if ((buttons & BUTTON_HELP) > 0) {
			buttonsLeftPanel.add(new JButton(helpAction));
		}

		if ((buttons & BUTTON_CONTEXT_HELP) > 0) {
			buttonsLeftPanel.add(new JButton(contextHelpAction));
		}

		buttonsRightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		if ((buttons & BUTTON_OKAY) > 0) {
			JButton jbOkay = new JButton(okayAction);
			buttonsRightPanel.add(jbOkay);
		}
		if ((buttons & BUTTON_CLOSE) > 0) {
			buttonsRightPanel.add(new JButton(closeAction));
		}
		if ((buttons & BUTTON_DEFAULTS) > 0) {
			buttonsRightPanel.add(new JButton(defaultsAction));
		}
		if ((buttons & BUTTON_APPLY) > 0) {
			buttonsRightPanel.add(new JButton(applyAction));
		}
		if ((buttons & BUTTON_CANCEL) > 0) {
			JButton jbCancel = new JButton(cancelAction);
			GUIHelper.bindEscapeKey(topPanel, jbCancel.getAction());
			buttonsRightPanel.add(jbCancel);
		}

		/* the aqua look and feel adds a small resize control in the lower
		   right corner which overlaps the status panel therefore we add a
		   little offset.  */
		if (SystemHelper.IS_MACOSX) {
			buttonsRightPanel.add(Box.createHorizontalStrut(15));
		}

		bottomPanel = new JPanel(new BorderLayout());
		bottomPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 0, 0));
		bottomPanel.add(buttonsLeftPanel, BorderLayout.WEST);
		bottomPanel.add(buttonsRightPanel, BorderLayout.EAST);
		topPanel.add(bottomPanel, BorderLayout.SOUTH);

		setButtonSeparatorVisible(true);
		
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(topPanel, BorderLayout.CENTER);

		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new CloseListener());
		/*addComponentListener(new ResizeListener());*/
		
		if (mainComponent != null) {
			pack();
		}
    }
 
    /**
     * Called by ApplyAction and OkayAction when the dialog is closed.
     * 
	 * @return true, if apply was successful and close() should be
	 *         invoked; false, otherwise
     */
    public boolean apply()
    {
		return true;
    }

    protected void cancelled()
    {
    }

    protected void defaults()
    {
    }

    /**
     * Disposes the dialog. Called by the actions to close the dialog. Sub
     * classes can reimplement this. 
     *
     * @see #isOkay()
     */
    public void close()
    {
		dispose();
    }

    /**
     * Returns the button panel. Sub classes can add aditional buttons to this
     * panel.
     */
    public JPanel getButtonPanel()
    {
		return buttonsRightPanel;
    }

    /**
     * Returns the apply action.
     */
    public Action getApplyAction() 
	{
		return applyAction;
	}

    /**
     * Returns the cancel action.
     */
    public Action getCancelAction()
    {
		return cancelAction;
    }

	/**
	 * Returns the defaults action.
	 */
	public Action getDefaultsAction()
	{
		return defaultsAction;
	}

	/**
	 * Returns the cancel action.
	 */
	public Action getOkayAction()
	{
		return okayAction;
	}

	/**
	 * Returns the cancel action.
	 */
	public Action getHelpAction()
	{
		return helpAction;
	}

	/**
	 * Returns the cancel action.
	 */
	public Action getContextHelpAction()
	{
		return contextHelpAction;
	}

    /**
     * Returns the close action.
     */
    public Action getCloseAction()
    {
		return closeAction;
    }

    /**
	 * Invoked when the context help button is selected.
	 * 
	 * <p>
	 * Invokes {@link WhatsThis#enterWhatsThisMode()}. Sub-classes may override
	 * this method.
	 */
    public void contextHelp()
    {
    	WhatsThis.enterWhatsThisMode();
    }

    /**
	 * Invoked when the context help is selected.
	 * 
	 * <p>
	 * Does nothing. Sub-classes may override this method.
	 */
    public void help()
    {
    }

    public void setApplyOnEnter(boolean apply)
    {
    	if (apply) {
    		GUIHelper.bindEnterKey(topPanel, getOkayAction());
    	}
    	else {
    		// TODO depends on the GUIHelper implementation, move this code there
    		topPanel.getActionMap().remove(getOkayAction());
    	}
	}

    /**
     * Sets the main component to <code>component</code>.
     * TODO can this be called multiple times?, it can they are all added, don't
     * know how this looks then
     */
    public void setMainComponent(Component component)
    {
		getMainPanel().setLayout(new BorderLayout());
		getMainPanel().add(component, BorderLayout.CENTER);
    }
    
    /**
     * Returns the main panel. Sub classes can add components to this panel.
     */
    public JPanel getMainPanel()
    {
		return mainPanel;
    }

	/**
	 * Returns the top most panel.
	 */
	public JPanel getTopPanel()
	{
		return topPanel;
	}

	public void setButtonSeparatorVisible(boolean visible)
	{
		if (visible) {
			if (buttonSeparator == null) {
				buttonSeparator = new JSeparator();
				bottomPanel.add(buttonSeparator, BorderLayout.NORTH);
			}
		}
		else {
			if (buttonSeparator != null) {
				bottomPanel.remove(buttonSeparator);
				buttonSeparator = null;
			}
		}
	}
	
    /**
     * Returns true, if the dialog was closed with the Okay button.
     */
    public boolean isOkay()
    {
		return isOkay;
    }

	/*
	public void pack() {
		setMinimumSize(null);
		super.pack();
		setMinimumSize(getSize());
	}
	*/
	
    /**
     * Sets this dialogs position relative to <code>c</code> and makes it 
     * visible.
     */
    public void show(Component c)
    {
		if (!isVisible()) {
			if (c != null) {
				setLocationRelativeTo(c);
			}
			setVisible(true);
		}
		else {
			toFront();
		}
    }

    /**
     * Handles the apply button. Invokes <code>apply()</code> when pressed.
     * 
     * @see #apply()
     */
    private class ApplyAction extends AbstractAction {

        public ApplyAction() 
		{
			putValue(Action.NAME, i18n.tr("Apply"));
			putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_A));
		}
	
        public void actionPerformed(ActionEvent event) 
		{
			apply();
        }
	
    }

    /**
     * Handles the Cancel button. Invokes <code>close()</code> when pressed.
     * 
     * @see #close()
     */
    private class CancelAction extends AbstractAction {

        public CancelAction()
		{
            putValue(Action.NAME, i18n.tr("Cancel"));
			putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_C));
		}

        public void actionPerformed(ActionEvent event) 
		{
			isOkay = false;
			cancelled();
			close();
		}
	
    }

    /**
     * Handle the Close button. Invokes <code>close()</code> when pressed.
     * 
     * @see #close()
     */
    private class CloseAction extends AbstractAction {

        public CloseAction() 
		{
			putValue(Action.NAME, i18n.tr("Close"));
			putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_S));
		}
	
        public void actionPerformed(ActionEvent event) 
		{
			isOkay = false;
			close();
        }
	
    }

    /**
     * Handles the Help button. Shows the help dialog registered for the
     * <code>rootPane</code> of this dialog.
     *
     * It suffices to register a help id and a helpset for the dialog using
     * {@link xnap.gui.util.HelpManager#enableHelpKeys(JComponent, String, HelpSet)} like this:
     *
     * <pre>
     *  HelpManager.enableHelpKeys(getRootPane(), "id-string", helpSet);
     * </pre>
     */
    private class HelpAction extends AbstractAction
    {

        public HelpAction() 
		{
			putValue(Action.NAME, i18n.tr("Help"));
			putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_H));
		}
	
        public void actionPerformed(ActionEvent event) 
		{
			help();
        }
	
    }

    private class DefaultsAction extends AbstractAction
    {

        public DefaultsAction() 
		{
			putValue(Action.NAME, i18n.tr("Defaults"));
			putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_D));
		}
	
        public void actionPerformed(ActionEvent event) 
		{
			defaults();
        }
	
    }

    private class ContextHelpAction extends WhatsThisAction
    {

        public void actionPerformed(ActionEvent event) 
		{
			contextHelp();
        }
	
    }


    /**
     * Handle the Okay button. Invokes <code>apply()</code> and
     * <code>close()</code> when pressed.
     * 
     * @see #apply()
     * @see #close()
     */
    private class OkayAction extends AbstractAction {

        public OkayAction() 
		{
			putValue(Action.NAME, i18n.tr("OK"));
			putValue(Action.MNEMONIC_KEY, new Integer(KeyEvent.VK_O));
		}
	
        public void actionPerformed(ActionEvent event) 
        {
			if (!apply()) {
				return;
			}

			isOkay = true;
			close();
        }
	
    }

    private class CloseListener extends WindowAdapter {
    	
		public void windowClosing (java.awt.event.WindowEvent evt) 
		{
			isOkay = false;
			close();
		}
    }
	
	/**
	 * Tries to enforce a minimum size for a dialog.
	 * 
	 * <p>This class is not used, since it does not work: The events are thrown 
	 * while the resize is in progress causing calls to setSize() to get lost.
	 * Can we come up with a working solution?
	 * 
	 * @author Steffen Pingel
	 */
	class ResizeListener extends ComponentAdapter {
		
		public void componentResized(ComponentEvent event)
		{
			Dimension minimumSize = getMinimumSize();
			if (minimumSize == null 
					|| (minimumSize.width <= getWidth()
						&& minimumSize.height <= getHeight())) {
				return;
			}
					
			Dimension newSize = getSize();
			if (getWidth() < minimumSize.width) {
				newSize.width = minimumSize.width;
			}
			if (getHeight() < minimumSize.height) {
				newSize.height = minimumSize.height;
			}
			setSize(newSize);
		}
		
	}

	 	
}
