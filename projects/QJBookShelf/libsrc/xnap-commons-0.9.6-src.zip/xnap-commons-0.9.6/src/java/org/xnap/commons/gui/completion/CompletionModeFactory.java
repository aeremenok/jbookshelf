/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * Factory class that manages all installed completion modes and creates 
 * them.
 * 
 * @author Felix Berger
  */
public class CompletionModeFactory 
{
	static final I18n I18N = I18nFactory.getI18n(CompletionModeFactory.class); 
	
	private static CompletionModeInfo[] infos;
	static {
		infos = new CompletionModeInfo[] {
				new CompletionModeInfo(I18N.tr("No Completion"),
						NoCompletionMode.class.getName()),
				new CompletionModeInfo(I18N.tr("Automatic"),
						AutomaticCompletionMode.class.getName()),
				new CompletionModeInfo(I18N.tr("Automatic Dropdown"),
						AutomaticDropDownCompletionMode.class.getName()),
				new CompletionModeInfo(I18N.tr("Dropdown List"),
						DropDownListCompletionMode.class.getName()),
				new CompletionModeInfo(I18N.tr("Emacs Completion"), 
						EmacsCompletionMode.class.getName()),
				new CompletionModeInfo(I18N.tr("Manual"),
						ManualCompletionMode.class.getName()),
				new CompletionModeInfo(I18N.tr("Short Automatic"),
						ShortAutomaticCompletionMode.class.getName()),
		};
	}
	
	/**
	 * Returns all installed completion mode info objects.
	 * @return an array that contains the objects; if no completion modes have
	 * been installed an empty array is returned, never returns null
	 */
	public static CompletionModeInfo[] getInstalledCompletionModes()
	{
		CompletionModeInfo[] result = new CompletionModeInfo[infos.length];
		System.arraycopy(infos, 0, result, 0, result.length);
		return result;
	}
	
	/**
	 * Returns the completion mode info object for the <code>className</code>.
	 * 
	 * @return <code>null</code> if no object for that class name was found
	 */
	public static CompletionModeInfo getCompletionModeInfoByClassName(String className)
	{
		for (CompletionModeInfo info : infos) {
			if (info.getClassName().equals(className)) {
				return info;
			}
		}
		return null;
	}
	
	/**
	 * Installs a completion mode info object.
	 * <p> 
	 * It is then returned in {@link #getInstalledCompletionModes()}.
	 * 
	 * Completion modes can not be uninstalled, since they may already be
	 * actively used in {@link Completion} objects and provided as possible options
	 * in {@link CompletionModeMenu CompletionModeMenus}.
	 * @param info
	 */
	public static void installCompletionMode(CompletionModeInfo info) 
	{
		CompletionModeInfo[] newInfos 
			= new CompletionModeInfo[infos.length + 1];
		System.arraycopy(infos, 0, newInfos, 0, infos.length);
		newInfos[infos.length] = info;
		infos = newInfos;
	}
	
	/**
	 * Creates a completion mode using the class name information from info.
	 * @param info
	 * @throws ClassNotFoundException
	 * @throws NoSuchMethodException
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public static CompletionMode createCompletionMode(CompletionModeInfo info)
		throws ClassNotFoundException, NoSuchMethodException, 
					NoSuchMethodException, InvocationTargetException,
					InstantiationException, IllegalAccessException,
					InvocationTargetException
	{
		return createCompletionMode(info.getClassName());
	}
	
	/**
	 * Creates a completion mode object with the given class name.
	 * @param className
	 * @throws IllegalArgumentException if the created object is not an
	 * instance of type {@link CompletionMode}.
	 * @throws ClassNotFoundException
	 * @throws NoSuchMethodException
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws InstantiationException
	 * @throws IllegalAccessException
	 * @throws InvocationTargetException
	 */
	public static CompletionMode createCompletionMode(String className)
		throws ClassNotFoundException, NoSuchMethodException, 
					NoSuchMethodException, InvocationTargetException,
					InstantiationException, IllegalAccessException,
					InvocationTargetException
	{
		Class clazz = Class.forName(className);
		Constructor constructor = clazz.getConstructor(new Class[0]);
		Object obj;
		obj = constructor.newInstance(new Object[0]);
		if (obj instanceof CompletionMode) {
			return (CompletionMode)obj;
		}
		else {
			throw new IllegalArgumentException("Set completion mode is not a CompetionMode");
		}
	}

	/**
	 * Info class that associates a {@link CompletionMode} with a name that
	 * can be shown to the user.
	 *
	 * @author Felix Berger
	 */
	public static class CompletionModeInfo
	{
		private String name;
		private String className;
		
		/**
		 * Constructs a new completion mode info object which can then be
		 * installed using 
		 * {@link CompletionModeFactory#installCompletionMode(CompletionModeInfo)}.
		 * @param name a possibly localized descriptive name of the completion 
		 * mode, like {@link i18n#tr(String) i18n.tr("Drop down Completion")}. 
		 * @param className the class name of the completion mode
		 * @throws NullPointerException if one of the arguments is <code>null</code>
		 */
		public CompletionModeInfo(String name, String className)
		{
			if (name == null) {
				throw new NullPointerException("name must not be null");
			}
			if (className == null) {
				throw new NullPointerException("className must not be null");
			}
			this.name = name;
			this.className = className;
		}
		
		/**
		 * Returns the descriptive name of the completion mode.
		 */
		public String getName()
		{
			return name;
		}
		
		/**
		 * Returns the class name of the completion mode.
		 */
		public String getClassName()
		{
			return className;
		}
		
		/**
		 * Returns the descriptive name of the completion mode, thus  
		 * CompletionModeInfo object can be directly used in comobobox or list 
		 * models without the need of providing a CellRenderer.
		 */
		public String toString()
		{
			return name;
		}
	}
}
