/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.awt.Window;
import javax.swing.JSplitPane;
import org.xnap.commons.gui.table.TableLayout;

/**
 * The idea is to provide a store that can save and restore GUI settings
 * that are only accessed on startup and shutdown of the application.
 * 
 * @author Steffen Pingel
 */
public class SettingStore {

	private SettingResource backStore;

	public SettingStore(SettingResource backStore)
	{
		this.backStore = backStore;
	}
	
	public SettingResource getBackStore()
	{
		return backStore;
	}
	
	public void saveSplitPane(String key, JSplitPane splitPane)
	{
		new IntSetting(getBackStore(), key, 0).setValue(splitPane.getDividerLocation());
	}
	
	public void saveWindow(String key, Window window)
	{
		new WindowSettingDirector(getBackStore(), key).save(window);
	}
	
	public void saveTable(String key, TableLayout tableLayout)
	{
		new TableSettingDirector(getBackStore(), key).save(tableLayout);
	}
	
	public void restoreSplitPane(String key, int defaultDividerLocation, JSplitPane splitPane)
	{
		splitPane.setDividerLocation(new IntSetting(getBackStore(), key, defaultDividerLocation, 0).getValue());
	}

	public void restoreWindow(String key, int defaultX, int defaultY, int defaultWidth, int defaultHeight, Window window)
	{
		new WindowSettingDirector(getBackStore(), key, defaultX, defaultY, defaultWidth, defaultHeight).restore(window);
	}

	public void restoreTable(String key, String[] defaultColumns, TableLayout tableLayout)
	{
		new TableSettingDirector(backStore, key)
			.setDefaults(defaultColumns)
			.restore(tableLayout);
	}
	
}
