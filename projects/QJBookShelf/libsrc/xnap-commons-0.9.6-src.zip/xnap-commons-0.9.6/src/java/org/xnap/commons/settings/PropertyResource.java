/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This class provides a default implementation for a preferences framework.
 * Methods are provided that can read and write native types, arrays and a few
 * custom types.
 */
public class PropertyResource implements SettingResource {

    protected static Log logger = LogFactory.getLog(PropertyResource.class);

    protected transient PropertyChangeSupport propertyChange
		= new PropertyChangeSupport(this);

    /**
     * Determines if preferences need to be saved.
     */
    protected boolean changedFlag = false;

    /**
     * Version of database format.
     */
    protected int version;

    /**
     * Version of database when read.
     */
    protected int oldVersion = -1;

    /**
     * The namespace is prefixed to each key.
     */
    protected String namespace;

    /**
     * Preferences.
     */
    protected Properties properties = new Properties();
    
    /**
     * Constructs a <code>PreferencesSupport</code> object.
     * @param version the current version of the preferences, this version
     *                can be more recent than the version of the file
     * @param namespace the namespace, used as a prefix for all keys
     */
    public PropertyResource(int version, String namespace)
    {
		this.version = version;

		if (namespace == null || namespace.length() == 0) {
			this.namespace = "";
		}
		else if (!namespace.endsWith(".")) {
			this.namespace = namespace + ".";
		}
		else {
			this.namespace = namespace;
		}
    }

    public PropertyResource()
    {
    	this(0, "");
    }
    
    /**
     * Reads preferences from <code>prefsFile</code>. 
     */
    public void load(File prefsFile) throws IOException
    {
		logger.info("Reading settings from " + prefsFile);

		FileInputStream in = new FileInputStream(prefsFile);
		try {
			properties.load(in);

			try {
				oldVersion = Integer.parseInt
					(properties.getProperty("props.ver", "-1"));
			} 
			catch (NumberFormatException e) {
				oldVersion = -1;
			}

			if (oldVersion != -1 && oldVersion < getVersion()) {
				logger.debug("converting from version " + oldVersion + " to "
							 + getVersion());
				convert(oldVersion);
            }
		} 
		finally {
			try {
				in.close();
			} catch (Exception e) {}
		}
		
		// FIXME need to notify all properties that their value may have
		// changed!
    }

    /**
     * Writes preferences to default preferences file. If preferences have not
     * changed since the last read or write operation, no action is taken.
     *
     * @return true, if file is written successfully or preferences were not 
     *         changed; false, if an <code>IOException</code> has occured
     * @throws IOException 
     */
    public boolean store(File prefsFile) throws IOException
    {
		if (!changedFlag) {
			logger.info("nothing changed, not writing " + prefsFile);
			return true;
		}

		logger.info("writing " + prefsFile);

		FileOutputStream out = new FileOutputStream(prefsFile);

		try {
			properties.put("props.ver", version + "");
			properties.store(out, "This file was automatically generated.");
		} 
		finally {
			try {
				out.close();
			} catch (IOException e) {}
		}

        changedFlag = false;
		return true;
    }
    
    /**
     * Returns true if <code>o</code> is the same object or if its 
     * version number, namespace and properties map are equal to
     * this' fields.
     */
    @Override
    public boolean equals(Object o) {
    	if (o == this) {
    		return true;
    	}
    	if (!(o instanceof PropertyResource)) {
    		return false;
    	}
    	PropertyResource r = (PropertyResource)o;
    	return version == r.version && namespace.equals(r.namespace)
    		&& properties.equals(r.properties);
    }

    /**
     * Returns the version of the preferences in the file at the point 
     * of the last read operation.
     */
    public int getOldVersion()
    {
		return oldVersion;
    }

    /**
     * Returns the current version of the preferences.
     */
    public int getVersion()
    {
		return version;
    }

    /**
     * Invoked by {@link #load(File)} to converts preferences from 
     * <code>oldVersion</code> to current version.
     */
    protected void convert(int oldVersion)
    {
    }

    /**
     * Adds a preferences listener.
     */
    public synchronized	void addPropertyChangeListener(PropertyChangeListener l)
    {
		propertyChange.addPropertyChangeListener(l);
    }

    /**
     * Adds a preferences listener for a specific key.
     */
    public synchronized	void addPropertyChangeListener(String key, PropertyChangeListener l)
    {
		propertyChange.addPropertyChangeListener(key, l);
    }

    /**
     * Fires PropertyChangeEvent without namespace.
     */
    public void firePropertyChange(String key, Object oldValue, Object newValue) 
    {
		int i = key.lastIndexOf(".");
		if (key.length() > i + 1) {
			key = key.substring(i + 1);
		} 

        propertyChange.firePropertyChange(key, oldValue, newValue);
    }
    
    /**
     * Removes a preferences listener.
     */
    public synchronized	void removePropertyChangeListener(PropertyChangeListener l) 
    {
        propertyChange.removePropertyChangeListener(l);
    }

	public synchronized void removePropertyChangeListener(String key, PropertyChangeListener l) 
	{
		propertyChange.removePropertyChangeListener(key, l);
	}
    
    public String get(String key, String defaultValue)
    {
		return properties.getProperty(namespace + key, defaultValue);
    }

    public void put(String key, String newValue)
    {
		properties.setProperty(namespace + key, newValue);
		changedFlag = true;
    }

    /**
     * Ignores namespace.
     */
    public synchronized void remove(String key)
    {
		properties.remove(namespace + key);
		changedFlag = true;
    }

    /**
     * Renames a property, used for conversion of property file formats.
     * Ignores namespace. Does not fire change event.
     */
    public synchronized void renameProperty(String oldKey, String newKey)
    {
		String value = properties.getProperty(oldKey, null);
		if (value != null) {
			Object oldValue = properties.remove(oldKey);
			if (oldValue != null) {
				properties.setProperty(newKey, value);
				changedFlag = true;
			}
		}
    }

}
