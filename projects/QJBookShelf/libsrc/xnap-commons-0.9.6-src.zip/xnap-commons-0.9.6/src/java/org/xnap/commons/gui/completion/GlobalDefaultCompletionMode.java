/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * This mode acts as a proxy for another mode that can be set as global
 * default.
 *
 * @author Steffen Pingel
 */
public class GlobalDefaultCompletionMode implements CompletionMode
{
	
	private static String defaultMode = DropDownListCompletionMode.class.getName();
	private static List<WeakReference<GlobalDefaultCompletionMode>> instances 
		= new ArrayList<WeakReference<GlobalDefaultCompletionMode>>();
	
	private CompletionMode mode;
	private Completion completion;
	
	public GlobalDefaultCompletionMode() 
	{
		instances.add(new WeakReference<GlobalDefaultCompletionMode>(this));
	}
	
	public void enable(Completion completion) 
	{
		try {
			mode = CompletionModeFactory.createCompletionMode(defaultMode);
		}
		catch (IllegalArgumentException iae) {
			throw iae;
		} 
		catch (Exception e) {
			// TODO now what
			e.printStackTrace();
			return;
		}

		mode.enable(completion);
		this.completion = completion;
	}

	public void disable() 
	{
		mode.disable();
		mode = null;
		completion = null;
	}
	
	public void updateMode() 
	{
		Completion savedCompletion = completion;
		if (savedCompletion != null) {
			disable();
			enable(savedCompletion);
		}
	}
	
	/**
	 * Returns the class name of the currently used completion mode.
	 */
	public static String getCompletionMode()
	{
		return defaultMode;
	}
	
	/**
	 * Calls to this method need to be Swing thread synchronized. 
	 * @param className must not be <code>null</code>, must not be
	 * the class name of DefaultCompletionMode itself.
	 * @throws IllegalArgumentException if <code>className</code> violates
	 * one of the requirements stated above
	 */
	public static void setCompletionMode(String className)
	{ 
		if (className == null) {
			throw new IllegalArgumentException("class name must not be null");
		}
		else if (className.equals(GlobalDefaultCompletionMode.class.getName())) {
			throw new IllegalArgumentException("delegate mode must not be default completion mode itself");
		}
		
		defaultMode = className;
		
		for (Iterator<WeakReference<GlobalDefaultCompletionMode>> it = instances.iterator(); it.hasNext();) {
			WeakReference<GlobalDefaultCompletionMode> instance = it.next();
			GlobalDefaultCompletionMode mode = instance.get();
			if (mode != null) {
				mode.updateMode();
			}
			else {
				it.remove();
			}
		}
	}
	
}
