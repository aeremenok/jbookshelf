/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.action;

import java.awt.event.ActionEvent;
import javax.swing.AbstractButton;

/**
 * Provides a default implementation for toggeable <code>Action</code> objects.
 */
public abstract class AbstractToggleAction extends AbstractXNapAction 
    implements ToggleAction {
    
    public AbstractToggleAction(boolean selected)
    {
		putValue(ToggleAction.SELECTED, new Boolean(selected));
    }

    /**
     * Constructor an AbstractToggleAction that is not selected by default.
     */
    public AbstractToggleAction()
    {
		this(false);
    }

    /**
     * Returns the state of the action.
     * 
     * @return true, if the action is currently in active state, e.g. selected 
     * in case of a {@link javax.swing.JToggleButton}
     */
    public boolean isSelected()
    {
		return ((Boolean)getValue(ToggleAction.SELECTED)).booleanValue();
    }

    public void actionPerformed(ActionEvent event) 
    {
		if (event.getSource() instanceof AbstractButton) {
			AbstractButton ab = (AbstractButton)event.getSource();
			setSelected(ab.isSelected());
		}
    }

    /**
     * Invoked when the selection changes.
     */
    public abstract void toggled(boolean selected);
        
    /**
     * Sets the state of the action.
     * 
     * @param newValue if true, the action is set to active state
     */
    public void setSelected(boolean newValue)
    {
		if (newValue != isSelected()) {
			putValue(ToggleAction.SELECTED, new Boolean(newValue));
			toggled(newValue);
		}
    }
    
}
