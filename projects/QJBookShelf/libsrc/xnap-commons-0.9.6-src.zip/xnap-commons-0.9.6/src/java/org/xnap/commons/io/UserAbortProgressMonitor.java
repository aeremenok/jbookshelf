/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.io;

import java.awt.Component;


/**
 * A progress monitor that acts as a proxy and throws 
 * {@link org.xnap.commons.io.UserAbortException} the proxied monitor has been
 * cancelled. 
 *  
 * @author Steffen Pingel
 */
public class UserAbortProgressMonitor implements ProgressMonitor {

	protected ProgressMonitor monitor;

	public UserAbortProgressMonitor(ProgressMonitor monitor)
	{
		this.monitor = monitor;
	}
	
	public boolean isCancelled()
	{
		return monitor.isCancelled();
	}

	public void setCancelEnabled(boolean enabled)
	{
		monitor.setCancelEnabled(enabled);
	}

	public void setTotalSteps(long max)
	{
		if (monitor.isCancelled()) {
			throw new UserAbortException();
		}

		monitor.setTotalSteps(max);
	}

	public void setValue(long value)
	{
		if (monitor.isCancelled()) {
			throw new UserAbortException();
		}

		monitor.setValue(value);
	}

	public void setText(String text)
	{
		monitor.setText(text);
	}

	public void work(long amount)
	{
		if (monitor.isCancelled()) {
			throw new UserAbortException();
		}
		
		monitor.work(amount);
	}

	public Component getComponent()
	{
		return monitor.getComponent();
	}

}