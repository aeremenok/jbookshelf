/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.table;

/**
 * Defines the requirements for tables that can be sorted.
 *
 * @see TableLayout
 */
public interface SortableModel
{

	enum Order {
		
		ASCENDING { public Order next() { return DESCENDING; } },
		DESCENDING { public Order next() { return UNSORTED; } },
		UNSORTED { public Order next() { return ASCENDING; } };
		
		public abstract Order next();
		
	};
	
    /**
     * Returns the class of the data objects in column at
     * <code>index</code>.
     */
    Class getColumnClass(int index);

    /**
     * Returns the index of the column that was sorted last.
     */
    int getSortedColumn();

    public Order getSortOrder();
    
    /**
     * Sets the maintain sort order flag.
     */
    void setMaintainSortOrder(boolean maintainSortOrder);

    public void setSortOrder(Order newValue);
    
    /**
     * Sort the table by <code>column</code>.
     *
     * @param column the column to sort
     * @param sortOrder the sort order to sory by
     * @param revert automatically revert sort order 
     * @return order the new sort order
     */
    Order sortByColumn(int column, Order sortOrder, boolean revert);
        
}
