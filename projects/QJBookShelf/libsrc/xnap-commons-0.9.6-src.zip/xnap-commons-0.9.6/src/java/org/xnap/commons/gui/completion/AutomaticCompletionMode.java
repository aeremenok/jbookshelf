/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * This mode provides automatic completion similar to the one provided in
 * KDE.
 * 
 * It inserts the first match it finds into the text component after the
 * cursor.
 *
 * @author Felix Berger
 */
public class AutomaticCompletionMode extends ShortAutomaticCompletionMode
{

    protected void complete(String prefix)
    {
    	if (getModel().complete(prefix)) {
    		Object obj = getModel().getElementAt(0);
    		if (obj != null && obj.toString().length() > prefix.length()) {
    			setText(obj.toString(), obj.toString().length(), prefix.length());
    		}
    	}
    }
    
    private class DocumentHandler implements DocumentListener
    {
    	public void insertUpdate(DocumentEvent e)
    	{
    		if (e.getLength() == 1) {
    			final String text = getText();
    			Runnable r = new Runnable()
    			{
    				public void run()
    				{
    					complete(text);	
    				}
    			};
    			SwingUtilities.invokeLater(r);
    		}
    	}

		/*
		 * @see javax.swing.event.DocumentListener#removeUpdate(javax.swing.event.DocumentEvent)
		 */
		public void removeUpdate(DocumentEvent e)
		{

		}

		/*
		 * @see javax.swing.event.DocumentListener#changedUpdate(javax.swing.event.DocumentEvent)
		 */
		public void changedUpdate(DocumentEvent e)
		{

		}
    }
}
