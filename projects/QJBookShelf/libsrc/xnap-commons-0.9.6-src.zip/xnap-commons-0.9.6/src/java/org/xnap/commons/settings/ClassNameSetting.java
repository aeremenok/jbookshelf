/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

/**
 * Provides a setting for objects that are instanciated via reflection.
 */
public class ClassNameSetting<T> extends AbstractSetting<T> {

	public ClassNameSetting(SettingResource backend, String key, T defaultValue)
    {
    	super(backend, key, defaultValue, null);
    }
	
	@SuppressWarnings("unchecked")
	@Override
	protected T fromString(String value)
	{
		try {
			Class<?> clazz = Class.forName(value);
			return (T)clazz.newInstance();
		} 
		catch (IllegalArgumentException e) {
		}
		catch (InstantiationException e) {
		}
		catch (IllegalAccessException e) {
		}
		catch (ClassNotFoundException e) {
		}
		return null;
	}

	@Override
	protected String toString(T value)
	{
		return value.getClass().getName();
	}
	
}
