/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * An integer validator. A range can be defined.
 */
public class IntValidator implements Validator {

	private static I18n i18n = I18nFactory.getI18n(IntValidator.class);
	
    private int min;
    private int max;

    public IntValidator(int min, int max)
    {
		if (min > max) {
			throw new IllegalArgumentException("Min must not be greater than max (" + min + " > " + max + ")");
		}

		this.min = min;
		this.max = max;
    }

    public IntValidator(int min)
    {
		this(min, Integer.MAX_VALUE);
    }

    public IntValidator()
    {
		this(Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

	public int getMin()
	{
		return min;
	}
	
	public int getMax()
	{
		return max;
	}
    
    /**
     * Validates <code>String</code>.
     * @exception IllegalArgumentException if newValue is invalid.
     */
    public void validate(String value)
    {
		if (value == null) {
			throw new IllegalArgumentException(i18n.tr("Value must not be null"));
		}

		int i = Integer.parseInt(value);
		if (i < min || i > max) {
			throw(new IllegalArgumentException(i18n.tr("Value out of range.")));
		}
    }

}
