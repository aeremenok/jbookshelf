/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.io;

import java.awt.Component;

/**
 * Null pattern implementation of the {@link ProgressMonitor} interface.
 */
public class NullProgressMonitor implements ProgressMonitor {

	/**
	 * Static instance that can be used so no new null monitors have to be 
	 * allocated.
	 */
	public static final NullProgressMonitor MONITOR = new NullProgressMonitor(); 
	
	/**
	 * Returns <code>false</code>.
	 */
	public boolean isCancelled()
	{
		return false;
	}

	/**
	 * Does nothing.
	 */
	public void setCancelEnabled(boolean enabled)
	{
	}

	/**
	 * Does nothing.
	 */
	public void setTotalSteps(long max)
	{
	}

	/**
	 * Does nothing.
	 */
	public void setValue(long value)
	{
	}

	/**
	 * Does nothing.
	 */
	public void setText(String text)
	{
	}

	/**
	 * Does nothing.
	 */
	public void work(long amount)
	{
	}

	/**
	 * Returns <code>null</code>.
	 */
	public Component getComponent()
	{
		return null;
	}
	
}
