/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.shortcut;

import java.util.ArrayList;
import java.util.HashMap;
import javax.swing.Action;
import javax.swing.JComponent;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Manages Shortcut objects.
 */
public class ShortcutManager
{

    private static Log logger = LogFactory.getLog(ShortcutManager.class);

    private static ShortcutManager instance = new ShortcutManager();
	/**
	 * The list of unique shortcut objects.
	 */
    private ArrayList<Shortcut> shortcuts = new ArrayList<Shortcut>();
	
	private HashMap<String, ActionShortcut> shortcutsByCommandKey = 
		new HashMap<String, ActionShortcut>();

    private ShortcutManager()
    {
    }

    /**
     * Returns the instance of <code>ShortcutManager</code>.
     */
    public static ShortcutManager getInstance()
    {
		return instance;
    }

    /**
     * Adds a shortcut.
     */
    public synchronized void add(Shortcut shortcut)
    {
		shortcuts.add(shortcut);
    }

	/**
	 * Creates a new ActionShortcut for the action if there isn't already one
	 * and returns it.
	 * <br>
	 * <p>Only one action shortcut object can exist for the same preferences
	 * key. Additional components are all managed by the same action shortcut
	 * object.</p>
	 *
	 * @param action the action which should be performed when the shortcut is
	 * typed in the respective component
	 * @param c the component for which the shortcut and the action are 
	 * registered
	 */
	public synchronized ActionShortcut add(Action action, JComponent c) 
										   
	{
		String key = (String)action.getValue(Action.ACTION_COMMAND_KEY);
		if (shortcutsByCommandKey.containsKey(key)) {
			ActionShortcut a = shortcutsByCommandKey.get(key);
			a.addComponent(c, action);
			return a;
		}
		else {
			ActionShortcut a = new ActionShortcut(action, c);
			shortcuts.add(a);
			shortcutsByCommandKey.put(key, a);
			return a;
		}
	}

    /**
     * Returns the array of currently registered shorcuts.
     */
    public synchronized Shortcut[] getShortcuts()
    {
		return shortcuts.toArray(new Shortcut[0]);
    }

    /**
     * Removes a currently registered shortcut.
     */
    public synchronized void remove(Shortcut shortcut)
    {
		shortcuts.remove(shortcut);
    }
	
	/**
	 * Removes a component from a currently registered action shortcut.
	 *
	 * <p>If the action shortcut's component count {@link
	 * ActionShortcut#getNumberOfComponents()} drops to 0, it is removed from
	 * the shortcut manager.</p>
	 */
	public synchronized void remove(ActionShortcut shortcut, JComponent c)
	{
		shortcut.removeComponent(c);
		if (shortcut.getNumberOfComponents() == 0) {
			String key = (String)shortcut.getAction().getValue(Action.ACTION_COMMAND_KEY);
			shortcutsByCommandKey.remove(key);
			remove(shortcut);
		}
	}

}
