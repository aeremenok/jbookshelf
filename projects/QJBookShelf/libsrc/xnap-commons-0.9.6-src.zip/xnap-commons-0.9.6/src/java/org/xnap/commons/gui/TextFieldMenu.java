/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.event.ActionEvent;
import javax.swing.Action;
import javax.swing.JMenu;
import javax.swing.text.DefaultEditorKit;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;
import javax.swing.text.TextAction;
import org.xnap.commons.gui.action.AbstractXNapAction;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * A menu for {@link javax.swing.JTextField} objects that provides cut, copy
 * paste, clear and a select all action.
 * 
 * @author Steffen Pingel
 */
public class TextFieldMenu extends JMenu
{
	private static I18n i18n = I18nFactory.getI18n(TextFieldMenu.class);
	
	public final static Action cutAction = new CutAction();
	public final static Action copyAction = new CopyAction();
	public final static Action pasteAction = new PasteAction();
	public final static Action selectAllAction = new SelectAllAction();
	public final static Action clearAction = new ClearAction();

    public TextFieldMenu()
    {
		super(i18n.tr("Edit"));

		add(Builder.createMenuItem(cutAction));
		add(Builder.createMenuItem(copyAction));
		add(Builder.createMenuItem(pasteAction));
		add(Builder.createMenuItem(clearAction));
		addSeparator();
		add(Builder.createMenuItem(selectAllAction));
    }

	/**
	 * Default select all action that operates on any 
	 * <code>JTextComponent</code>.
	 */
    public static class SelectAllAction extends TextAction {
        
        public SelectAllAction()
        {
			super("select-all");
			
    		putValue(Action.NAME, i18n.tr("Select All"));
    		putValue(Action.SHORT_DESCRIPTION, 
    				 i18n.tr("Selects all text"));
        }

        public void actionPerformed(ActionEvent event) 
        {
            JTextComponent target = getTextComponent(event);
            if (target != null) {
                Document doc = target.getDocument();
                target.setCaretPosition(0);
                target.moveCaretPosition(doc.getLength());
            }
        }
        
    }

	/**
	 * Default clear action that operates on any 
	 * <code>JTextComponent</code>.
	 */
    public static class ClearAction extends TextAction {
        
        public ClearAction()
        {
			super("clear");
			
    		putValue(Action.NAME, i18n.tr("Clear"));
    		putValue(Action.SHORT_DESCRIPTION, 
    				 i18n.tr("Deletes all text"));
			putValue(AbstractXNapAction.ICON_FILENAME, "editclear.png");
        }

        public void actionPerformed(ActionEvent event) 
        {
            JTextComponent target = getTextComponent(event);
            if (target != null) {
                target.setText("");
            }
        }
        
    }

	/**
	 * Default clipboard copy action that operates on any 
	 * <code>JTextComponent</code>.
	 */
    public static class CopyAction extends DefaultEditorKit.CopyAction {
        
        public CopyAction()
        {
			putValue(Action.NAME, i18n.tr("Copy"));
			putValue(Action.SHORT_DESCRIPTION, 
					i18n.tr("Copies selected text to clipboard"));
			putValue(AbstractXNapAction.ICON_FILENAME, "editcopy.png");
        }
        
    }

	/**
	 * Default clipboard cut action that operates on any 
	 * <code>JTextComponent</code>.
	 */
    public static class CutAction extends DefaultEditorKit.CutAction {
        
        public CutAction()
        {
			putValue(Action.NAME, i18n.tr("Cut"));
			putValue(Action.SHORT_DESCRIPTION, 
					i18n.tr("Moves selected text to clipboard"));
			putValue(AbstractXNapAction.ICON_FILENAME, "editcut.png");
        }
		
    }

	/**
	 * Default clipboard paste action that operates on any 
	 * <code>JTextComponent</code>.
	 */
    public static class PasteAction extends DefaultEditorKit.PasteAction {
        
        public PasteAction()
        {
			putValue(Action.NAME, i18n.tr("Paste"));
			putValue(Action.SHORT_DESCRIPTION, 
					i18n.tr("Pastes clipboard contents"));
			putValue(AbstractXNapAction.ICON_FILENAME, "editpaste.png");
        }
		
    }
	
}
