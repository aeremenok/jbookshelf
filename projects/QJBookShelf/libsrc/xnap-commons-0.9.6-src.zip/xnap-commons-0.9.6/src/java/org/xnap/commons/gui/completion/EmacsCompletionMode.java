/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import static org.xnap.commons.gui.completion.CompletionModeFactory.I18N;
import java.awt.event.InputEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.KeyStroke;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xnap.commons.gui.shortcut.DefaultShortcut;
import org.xnap.commons.gui.shortcut.ShortcutManager;


/**
 * This completion mode mimics Emacs' <code>(dabbrev-expand)</code>.
 * 
 * The keys triggering the forward/backward completion can be configured
 * in the {@link ShortcutManager} framework.
 *
 * @author Felix Berger
 */
public class EmacsCompletionMode extends AbstractCompletionMode
{
	public static final DefaultShortcut SHORTCUT_FORWARD = new DefaultShortcut
		(KeyStroke.getKeyStroke(KeyEvent.VK_T, InputEvent.CTRL_MASK),
		 I18N.tr("Completion"), I18N.tr("Emacs Cycle Forward")); 

	
	public static final DefaultShortcut SHORTCUT_BACKWARD = new DefaultShortcut
		(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_MASK),
		 I18N.tr("Completion"), I18N.tr("Emacs Cycle Backward")); 
		 
    private static Log logger = LogFactory.getLog(EmacsCompletionMode.class);

    /**
    * Holds the key listener used for receiving the mode's trigger key events.
    */
    private KeyListener listener = new KeyHandler();
    /**
     * The current set of possible completions for the input which can be
     * traversed.
     */
    private Object[] matches = null;
    /**
     * The index of the currently shown completion.
     */
    private int index = 0;
    /**
     * The original string which triggered the completion.
     */
    private String orig = null;

    public void disable()
    {
        getTextComponent().removeKeyListener(listener);
    }

    protected void enable()
    {
        getTextComponent().addKeyListener(listener);
    }

    private Object[] getMatches()
    {
        int size = getModel().getSize();
        Object[] matches = new Object[size];

        for (int i = 0; i < size; i++) {
            matches[i] = getModel().getElementAt(i);
        }

        return matches;
    }

    private class KeyHandler extends KeyAdapter
    {
        public void keyPressed(KeyEvent e)
        {
            if (SHORTCUT_FORWARD.getKeyStroke() != null 
				&& SHORTCUT_FORWARD.getKeyStroke().equals
				(KeyStroke.getKeyStrokeForEvent(e))) {
                // scroll forwards
                if (matches != null) {
                    if ((index + 1) == matches.length) {
                        setText(orig);
                        getTextComponent().getToolkit().beep();
                        matches = null;
                    }
                    else {
                        setText(matches[++index].toString());
                    }
                }
                else if (getModel().complete(getText())) {
                    orig = getText();
                    matches = getMatches();
                    index = 0;
                    setText(matches[0].toString());
                }
                e.consume();
            }
            else if (SHORTCUT_BACKWARD.getKeyStroke() != null 
					 && SHORTCUT_BACKWARD.getKeyStroke().equals
					 (KeyStroke.getKeyStrokeForEvent(e))) {
				// scroll backwards
				if (matches != null) {
					if (index > 0) {
						setText(matches[--index].toString());
					}
					else {
						setText(orig);
						matches = null;
					}
				}
				e.consume();
			}
			else if (e.getKeyCode() != KeyEvent.VK_ALT 
					 && e.getKeyCode() != KeyEvent.VK_CONTROL
					 && e.getKeyCode() != KeyEvent.VK_SHIFT
					 && e.getKeyCode() != KeyEvent.VK_META) {
				matches = null;
			}
		}
    }
}
