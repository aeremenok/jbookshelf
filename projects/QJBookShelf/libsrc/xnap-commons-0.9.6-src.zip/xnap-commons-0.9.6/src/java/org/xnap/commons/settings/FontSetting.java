/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.awt.Font;
import java.util.StringTokenizer;

/**
 * Provides a setting for <code>Font</code> objects.
 */
public class FontSetting extends AbstractSetting<Font> {

    public FontSetting(SettingResource backend, String key, Font defaultValue, Validator validator)
    {
    	super(backend, key, defaultValue, validator);
    }

    public FontSetting(SettingResource backend, String key, Font defaultValue)
    {
    	super(backend, key, defaultValue, null);
    }

    protected Font fromString(String value)
	{
		// this could be way easier but there seems to be no serialize
		// method that can create the format recognized by getFont()
		//return Font.getFont(key);

		StringTokenizer t = new StringTokenizer(value, ARRAY_SEPARATOR);
		if (t.countTokens() >= 3) {
			try {
				String name = t.nextToken();
				int style = Integer.parseInt(t.nextToken());
				int size = Integer.parseInt(t.nextToken());

				return new Font(name, style, size);
			}
			catch (NumberFormatException e) {
			}
		}

		return null;
	}

	protected String toString(Font value)
	{
		Font font = (Font)value;
		
		// encode Font
		StringBuilder sb = new StringBuilder();
		sb.append(font.getName());
		sb.append(ARRAY_SEPARATOR);
		sb.append(font.getStyle());
		sb.append(ARRAY_SEPARATOR);
		sb.append(font.getSize());
		return sb.toString();
	}

}
