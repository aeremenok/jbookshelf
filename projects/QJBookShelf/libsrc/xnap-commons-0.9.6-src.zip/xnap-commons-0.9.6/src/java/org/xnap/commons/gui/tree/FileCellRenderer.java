/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.tree;

import java.awt.Component;
import java.io.File;
import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;
import org.xnap.commons.gui.util.IconHelper;

/**
 * Renders tree nodes of type {@link File} and {@link String}.
 * 
 * Files are displayed as green folders, Strings as yellow folders.
 */
public class FileCellRenderer extends DefaultTreeCellRenderer
{

    public static final Icon[] folders = {
		IconHelper.getMenuIcon("folder.png"), 
		IconHelper.getMenuIcon("folder_open.png"),
		IconHelper.getMenuIcon("folder_yellow.png"),
		IconHelper.getMenuIcon("folder_yellow_open.png")
    };

    public FileCellRenderer()
    {
    }

    public Component getTreeCellRendererComponent(JTree tree, Object node,
			boolean sel, boolean expanded, boolean leaf, int row,
			boolean hasFocus)
	{
		super.getTreeCellRendererComponent(tree, node, sel, expanded, leaf,
				row, hasFocus);
		if (node instanceof File) {
			if (expanded) {
				setIcon(folders[1]);
			}
			else {
				setIcon(folders[0]);
			}
		}
		else if (node instanceof String) {
			if (expanded) {
				setIcon(folders[3]);
			}
			else {
				setIcon(folders[2]);
			}
		}
		return this;
	}
}
