package org.xnap.commons.gui;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.text.JTextComponent;
import org.xnap.commons.gui.action.ToggleAction;
import org.xnap.commons.gui.completion.Completion;
import org.xnap.commons.gui.completion.CompletionModel;
import org.xnap.commons.gui.factory.DefaultFactory;
import org.xnap.commons.gui.factory.Factory;

public class Builder {
	
	private static Factory factory = new DefaultFactory();

	/**
	 * Sets the factory that is used by the builder.
	 * @param factory can <code>null</code> then the {@link DefaultFactory}
	 * is set.
	 */
	public static void setFactory(Factory factory)
	{
		if (factory == null) {
			Builder.factory = new DefaultFactory();
		}
		else {
			Builder.factory = factory; 
		}
	}
	
	/**
	 * Returns the factory used by the builder. This method never returns
	 * <code>null</code>.
	 * 
	 * @return a valid factory
	 */
	public static Factory getFactory()
	{
		return factory;
	}
	
	/**
	 * Adds completion and a completion mode menu to a text component.
	 * <p>
	 * Completion is done for the whole text of the component and not for the
	 * last word before the cursor.
	 * <p>
	 * The completion mode menu is added as context menu to the text 
	 * component.
	 */
	public static Completion addCompletion(JTextComponent textComponent)
	{
		Completion completion = new Completion(textComponent);
		// TODO menu reference is lost so orientation can't be applied to it
		factory.addCompletionModeMenu(textComponent, completion);
		return completion;
	}
	
	/**
	 * Adds completion and a completion mode menu to a text component.
	 * <p>
	 * Completion is done for the whole text of the component and not for the
	 * last word before the cursor.
	 * <p>
	 * The completion mode menu is added as context menu to the text 
	 * component.
	 */
	public static Completion addCompletion(JTextComponent textComponent,
										   CompletionModel model)
	{
		Completion completion = new Completion(textComponent, model);
		// TODO menu reference is lost so orientation can't be applied to it
		factory.addCompletionModeMenu(textComponent, completion);
		return completion;
	}

	/**
	 * Adds completion and a completion mode menu to a text component.
	 * <p>
	 * Completion is done for the whole text of the component and not for the
	 * last word before the cursor.
	 * <p>
	 * The completion mode menu is added as a submenu to the given menu.
	 */
	public static Completion addCompletion(JTextComponent textComponent,
										   JMenu menu)
	{
		Completion completion = new Completion(textComponent);
		// TODO menu reference is lost so orientation can't be applied to it
		factory.addCompletionModeMenu(menu, completion);
		return completion;
	}
	
	/**
	 * Adds completion and a completion mode menu to a text component.
	 * <p>
	 * Completion is done for the whole text of the component and not for the
	 * last word before the cursor.
	 * <p>
	 * The completion mode menu is added as a submenu to the given menu.
	 */
	public static Completion addCompletion(JTextComponent textComponent,
										   JMenu menu, CompletionModel model)
	{
		Completion completion = new Completion(textComponent, model);
		// TODO menu reference is lost so orientation can't be applied to it
		factory.addCompletionModeMenu(menu, completion);
		return completion;
	}

	public static AbstractButton createButton(Action action)
	{
		return factory.createButton(action);
	}

	public static AbstractButton createCheckBox(ToggleAction action)
	{
		return factory.createCheckBox(action);
	}

	public static AbstractButton createIconButton(Action action)
	{
		return factory.createIconButton(action);
	}
	
	public static AbstractButton createToolBarButton(Action action)
	{
		return factory.createToolBarButton(action);
	}

	public static JComponent createMenuItem(Action action) 
	{
		return factory.createMenuItem(action);
	}
	
	public static void setProperty(Object key, Object value)
	{
		factory.setProperty(key, value);
	}
	
}
