/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.Component;
import javax.swing.SwingUtilities;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.settings.BooleanSetting;
import org.xnap.commons.util.UncaughtExceptionListener;
import org.xnap.commons.util.UncaughtExceptionManager;

// TODO doc
public class ErrorHandler implements UncaughtExceptionListener {

	private ErrorDialog dialog;
	private BooleanSetting showDialogSetting;
	private Component parent;
	private UncaughtExceptionManager exceptionManager;
	private BooleanSetting detailsVisibleSetting;

    public ErrorHandler(Component parent, 
    					UncaughtExceptionManager exceptionManager,
						BooleanSetting showDialogSetting,
						BooleanSetting detailsVisibleSetting) 
    {
    	this.parent = parent;
    	this.exceptionManager = exceptionManager;
    	this.showDialogSetting = showDialogSetting;
    	this.detailsVisibleSetting = detailsVisibleSetting;
	}

    public void handle(Throwable e)
	{
		uncaughtException(Thread.currentThread(), e);
	}

	public void setParent(Component parent)
	{
		this.parent = parent;
	}
	
	public void uncaughtException(final Thread t, final Throwable e) 
	{
		if (showDialogSetting != null && !showDialogSetting.getValue()) {
			return;
		}
		
		Runnable runner = new Runnable() 
			{
				public void run()
				{
					if (dialog == null || dialog.isBusy()) {
						dialog = new ErrorDialog(I18nFactory.getI18n(ErrorDialog.class).tr("An unknown problem has occured!"),
												 exceptionManager, true, 
												 showDialogSetting, 
												 detailsVisibleSetting);
						dialog.show(parent);
					}
					dialog.add(t, e);
				}
			};
		SwingUtilities.invokeLater(runner);
	}

}
