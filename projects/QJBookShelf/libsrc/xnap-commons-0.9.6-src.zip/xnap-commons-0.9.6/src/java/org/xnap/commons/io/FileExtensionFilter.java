/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.io;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Provides a <code>FileFilter</code> that accepts a certain file
 * extension only.
 * 
 * @author Steffen Pingel
 */
public class FileExtensionFilter extends javax.swing.filechooser.FileFilter
	implements FileFilter
{

    private List<String> extensions = new ArrayList<String>();
	private String description;

    public FileExtensionFilter(String description, String extension)
    {
		this.description = description;
		this.extensions.add(extension);
    }

    public FileExtensionFilter(String description, String[] extensions)
    {
		this.description = description;
		this.extensions.addAll(Arrays.asList(extensions));
    }

    public boolean accept(File file)
    {
		if (file.isDirectory()) {
			return true;
		}
		
		String name = file.getName();
		for (String extension : extensions) {
			if (name.endsWith(extension)) {
				return true;
			}
		}
		return false;
    }
	
	public String getDescription()
	{
		return description;
	}

}

