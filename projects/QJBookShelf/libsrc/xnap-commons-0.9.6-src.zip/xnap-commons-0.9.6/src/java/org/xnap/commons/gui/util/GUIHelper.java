/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.util;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.StringTokenizer;
import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.BorderFactory;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JScrollBar;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.text.JTextComponent;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import org.xnap.commons.gui.ThinBevelBorder;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.util.FileHelper;
import org.xnap.commons.util.SystemHelper;

/**
 * Helps with gui related tasks.
 */
public class GUIHelper
{
	static final I18n I18N = I18nFactory.getI18n(GUIHelper.class);

	/**
	 * Kicker offset.
	 */
	public static final int POPUP_MENU_HEIGHT_INSET = 50;

	/**
	 * Adds a mapping between the enter key and <code>action</code> to the
	 * input map of <code>c</code>.
	 * 
	 * @return true, if successful; false, otherwise
	 */
	public static boolean bindEnterKey(JComponent c, Action action)
	{
		KeyStroke ks = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
		return bindKey(c, ks, action, true);
	}

	/**
	 * Does the same as {@link #bindEnterKey(JComponent, Action)}but uses the
	 * default input map and not the window input map.
	 * 
	 * @return true, if successful; false, otherwise
	 */
	public static boolean bindEnterKeyLocally(JComponent c, Action action)
	{
		KeyStroke ks = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
		return bindKey(c, ks, action, false);
	}

	/**
	 * Adds a mapping between the escape key and <code>action</code> to the
	 * input map of <code>c</code>.
	 * 
	 * @return true, if successful; false, otherwise
	 */
	public static boolean bindEscapeKey(JComponent c, Action action)
	{
		KeyStroke ks = KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0);
		return bindKey(c, ks, action, true);
	}

	/**
	 * Adds a mapping between <code>ks</code> and <code>action</code> to the
	 * input map of <code>c</code>.
	 * 
	 * @return true, if successful; false, otherwise
	 */
	public static boolean bindKey(JComponent c, KeyStroke ks, Action action,
			boolean whenInFocusedWindow)
	{
		InputMap inputMap = (whenInFocusedWindow) ? c
				.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW) : c
				.getInputMap();
		ActionMap actionMap = c.getActionMap();
		if (inputMap != null && actionMap != null) {
			inputMap.put(ks, action);
			actionMap.put(action, action);
			return true;
		}
		return false;
	}

	/**
	 * Returns an etched default border.
	 * TODO move this to builder?
	 */
	public static Border createDefaultBorder(String title)
	{
		return BorderFactory.createTitledBorder(BorderFactory
				.createEtchedBorder(), " " + title + " ");
	}

	/**
	 * Returns an empty border.
	 */
	public static Border createEmptyBorder(int inset)
	{
		return BorderFactory.createEmptyBorder(inset, inset, inset, inset);
	}

	/**
	 * Returns an empty border.
	 */
	public static Border createEmptyBorder()
	{
		return createEmptyBorder(0);
	}

	/**
	 * Returns an empty border.
	 */
	public static Border createEtchedBorder()
	{
		return BorderFactory.createEtchedBorder();
	}

	public static Border createLoweredBorder()
	{
		return new ThinBevelBorder(ThinBevelBorder.LOWERED);
	}

	public static Border createRaisedBorder()
	{
		return new ThinBevelBorder(ThinBevelBorder.RAISED);
	}

	/**
	 * Creates and answers a label with separator; useful to separate paragraphs
	 * in a panel. This is often a better choice than a
	 * <code>TitledBorder</code>.
	 * <p>
	 * The current implementation doesn't support component alignments.
	 * 
	 * <p>
	 * Copyright (c) 2003 JGoodies Karsten Lentzsch. All Rights Reserved.
	 * Modified by Steffen Pingel for XNap.
	 * 
	 * @param text
	 *            the title's text
	 * @param alignment
	 *            text alignment: left, center, right
	 * @return a separator with title label
	 */
	//      public JComponent createSeparator(String text, int alignment)
	//  	{
	//          JPanel header = new JPanel(new GridBagLayout());
	//          GridBagConstraints gbc = new GridBagConstraints();
	//          gbc.weightx = 0.0;
	//          gbc.weighty = 1.0;
	//          gbc.anchor = GridBagConstraints.SOUTHWEST;
	//          gbc.fill = GridBagConstraints.BOTH;
	//          gbc.gridwidth = 1;
	//          gbc.gridheight = 3;
	//          if (text != null && text.length() > 0) {
	//  			JLabel label = new TitleLabel();
	//          setTextAndMnemonic(label, textWithMnemonic);
	//          label.setVerticalAlignment(SwingConstants.CENTER);
	//          label.setBorder(BorderFactory.createEmptyBorder(1, 0, 1, gap));
	//          return label;
	//              header.add(createTitle(text, 4), gbc);
	//          }
	//          gbc.weightx = 1.0;
	//          gbc.weighty = 1.0;
	//          gbc.gridwidth = GridBagConstraints.REMAINDER;
	//          gbc.gridheight = 1;
	//          JSeparator separator = new JSeparator();
	//          header.add(Box.createGlue(), gbc);
	//          gbc.weighty = 0.0;
	//          header.add(separator, gbc);
	//          gbc.weighty = 1.0;
	//          header.add(Box.createGlue(), gbc);
	//          return header;
	//      }

	/**
	 * Returns a component that displays <code>title</code> in a bold font.
	 * 
	 */
	public static JComponent createHeader(String title)
	{
		JLabel label = new JLabel(title);
		Font font = UIManager.getFont("TitledBorder.font");
		if (font != null) {
			label.setFont(font.deriveFont(Font.BOLD));
		}
		Color foreground = UIManager.getColor("TitledBorder.titleColor");
		if (foreground != null) {
			label.setForeground(foreground);
		}
		return label;
	}

	/**
	 * Returns a titled border.
	 */
	public static Border createTitledBorder(String title, int inset)
	{
		return BorderFactory.createCompoundBorder(createDefaultBorder(title),
				createEmptyBorder(inset));
	}

    public static void expandAllNodes(JTree tree, boolean expand) 
    {
        TreeNode root = (TreeNode)tree.getModel().getRoot();
        expandAllNodes(tree, new TreePath(root), expand);
    }
    
    public static void expandAllNodes(JTree tree, TreePath path, boolean expand) {
        // do a depth-first search recursively as expand or callapse must be
    	// done bottom-up
        TreeNode node = (TreeNode)path.getLastPathComponent();
        if (node.getChildCount() > 0) {
            for (Enumeration e = node.children(); e.hasMoreElements(); ) {
                TreeNode child = (TreeNode)e.nextElement();
                TreePath childPath = path.pathByAddingChild(child);
                expandAllNodes(tree, childPath, expand);
            }
        }
    
        if (expand) {
            tree.expandPath(path);
        } else {
            tree.collapsePath(path);
        }
    }	
	
	public static void restrictWidth(JComponent jc)
	{
		jc.setMaximumSize(new Dimension(jc.getPreferredSize().width, jc
				.getMaximumSize().height));
	}

	public static void scrollToEnd(JTextComponent jt)
	{
		//          Element map = jt.getDocument().getDefaultRootElement();
		//  		Element lastLine = map.getElement(map.getElementCount() - 1);
		//  		jt.setCaretPosition(lastLine.getEndOffset() - 1);
		jt.setCaretPosition(jt.getDocument().getEndPosition().getOffset() - 1);
	}

	/**
	 * Returns true, if <code>jsb</code> is at the maximum value.
	 */
	public static boolean shouldScroll(JScrollBar jsb)
	{
		int pos = jsb.getValue() + jsb.getVisibleAmount();
		return (pos == jsb.getMaximum());
	}

	public static KeyStroke getMenuKeyStroke(int keyCode)
	{
		int mask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
		return KeyStroke.getKeyStroke(keyCode, mask);
	}

	public static void setAccelerator(JMenuItem jmi, int keyCode)
	{
		int mask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
		jmi.setAccelerator(KeyStroke.getKeyStroke(keyCode, mask));
	}

	public static void setMnemonics(JTabbedPane pane)
	{
		HashSet<Integer> letters = new HashSet<Integer>();
		for (int i = 0; i < pane.getTabCount(); i++) {
			if (pane.getMnemonicAt(i) == 0) {
				pane.setMnemonicAt(i, getMnemonicForText(pane.getTitleAt(i),
						letters));
			}
		}
	}

	// TODO assign mnemonics for container itself
	public static void setMnemonics(Container c)
	{
		setMnemonics(c, null);
	}

	public static void setMnemonics(Container c, HashSet<Integer> l)
	{
		HashSet<Integer> letters = (l != null) ? l : new HashSet<Integer>();
		for (int i = 0; i < c.getComponentCount(); i++) {
			Component component = c.getComponent(i);
			if (component instanceof AbstractButton) {
				AbstractButton ab = (AbstractButton)component;
				if (ab.getMnemonic() == 0) {
					setMnemonics(ab, letters);
				}
				else {
					letters.add(new Integer(ab.getMnemonic()));
				}
			}
			if (component instanceof JLabel) {
				JLabel label = (JLabel)component;
				if (label.getDisplayedMnemonic() != 0) {
					letters.add(new Integer(label.getDisplayedMnemonic()));
				}
				if (label.getLabelFor() != null) {
					setMnemonics(label, letters);
				}
			}
			if (component instanceof JMenu) {
				setMnemonics(((JMenu)component).getPopupMenu());
			}
			// recurse
			if (component instanceof Container) {
				setMnemonics((Container)component, letters);
			}
		}
	}

	private static boolean setMnemonics(JLabel label, HashSet<Integer> letters)
	{
		if (label.getText() == null) {
			return true;
		}
		String text = label.getText();
		// try first letters of words first
		StringTokenizer t = new StringTokenizer(text);
		while (t.hasMoreTokens()) {
			int character = (int)t.nextToken().charAt(0);
			if (!letters.contains(character)) {
				letters.add(character);
				label.setDisplayedMnemonic(character);
				return true;
			}
		}
		// pick any character, start with the second one
		// the first one has already been checked
		for (int i = 1; i < text.length(); i++) {
			int character =  (int)text.charAt(i);
			if (text.charAt(i) != ' ' && !letters.contains(character)) {
				letters.add(character);
				label.setDisplayedMnemonic(character);
				return true;
			}
		}
		return false;
	}

	private static int getMnemonicForText(String text, HashSet<Integer> letters)
	{
		// try first letters of words first
		StringTokenizer t = new StringTokenizer(text);
		while (t.hasMoreTokens()) {
			int character = (int)t.nextToken().charAt(0);
			if (!letters.contains(character)) {
				letters.add(character);
				return character;
			}
		}
		// pick any character, start with the second one
		// the first one has already been checked
		for (int i = 1; i < text.length(); i++) {
			int character = (int)text.charAt(i);
			if (text.charAt(i) != ' ' && !letters.contains(character)) {
				letters.add(character);
				return character;
			}
		}
		return 0;
	}

	private static boolean setMnemonics(AbstractButton ab, HashSet<Integer> letters)
	{
		if (ab.getText() == null) {
			return true;
		}
		String text = ab.getText().toUpperCase();
		// try first letters of words first
		StringTokenizer t = new StringTokenizer(text);
		while (t.hasMoreTokens()) {
			int character = (int)t.nextToken().charAt(0);
			if (!letters.contains(character)) {
				letters.add(character);
				ab.setMnemonic(character);
				return true;
			}
		}
		// pick any character, start with the second one
		// the first one has already been checked
		for (int i = 1; i < text.length(); i++) {
			int character = (int)text.charAt(i);
			if (text.charAt(i) != ' ' && !letters.contains(character)) {
				letters.add(character);
				ab.setMnemonic(character);
				return true;
			}
		}
		return false;
	}

	/**
	 * Loads text from file and sets it to <code>jtc</code>.
	 * 
	 * <p>
	 * If file is not found or could not be read, sets <code>altText</code>
	 * instead.
	 */
	public static void showFile(JTextComponent jtc, String filename,
			String altText)
	{
		InputStream s = Thread.currentThread().getContextClassLoader().getResourceAsStream(filename);
		if (s != null) {
			try {
				jtc.setText(FileHelper.readText(s));
				jtc.setCaretPosition(0);
				return;
			}
			catch (IOException e) {}
			finally {
				try {
					s.close();
				}
				catch (IOException e) {}
			}
		}
		// file reading failed for some reason, fallback to altText
		jtc.setText(altText);
	}

	public static void showPopupMenu(JPopupMenu jpm, Component source, int x,
			int y, int yOffset)
	{
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		screen.height -= POPUP_MENU_HEIGHT_INSET;
		Point origin = source.getLocationOnScreen();
		origin.translate(x, y);
		int height = jpm.getHeight();
		if (height == 0) {
			jpm.addComponentListener(new SizeListener(source, x, y));
		}
		int width = jpm.getWidth();
		if (origin.x + width > screen.width) {
			//x -= (origin.x + width) - screen.width;
			// we prefer kde behaviour
			x -= width;
		}
		if (origin.y + height > screen.height) {
			// we prefer kde behaviour
			//y -= (origin.y + height) - screen.height;
			y -= height;
			y += yOffset;
		}
		jpm.show(source, x, y);
	}

	public static void showPopupMenu(JPopupMenu jpm, Component source, int x,
			int y)
	{
		showPopupMenu(jpm, source, x, y, 0);
	}

	/**
	 * Wraps HTML tags around <code>text</code> so the maximum width is
	 * limited to a senseful value.
	 * 
	 * @return text, enclosed in table html tags
	 */
	public static String label(String text)
	{
		return tt(text, 500);
	}

	/**
	 * Wraps HTML tags around <code>text</code> so the maximum width is
	 * limited to a senseful value.
	 * 
	 * @return text, enclosed in table html tags
	 */
	public static String tt(String text, int width)
	{
		StringBuilder sb = new StringBuilder(33 + text.length() + 25);
		sb.append("<html>");
		sb.append("<table><tr><td width=\"" + width + "\">");
		sb.append(text);
		sb.append("</td></tr></table>");
		sb.append("</html>");
		return sb.toString();
	}

	public static KeyStroke getMenuShortcut(int keyCode)
	{
		int mask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
		return KeyStroke.getKeyStroke(keyCode, mask);
	}

	/**
	 * Wraps HTML tags around <code>text</code> so the maximum width is
	 * limited to a sensible value.
	 * 
	 * @return text, enclosed in table html tags
	 */
	public static String tt(String text)
	{
		return tt(text, 300);
	}

	/**
	 * Formats key, value as a HTML table row, the key is highlighted as bold.
	 */
	public static String tableRow(String key, String value)
	{
		StringBuilder sb = new StringBuilder();
		sb.append("<tr><td><b>");
		sb.append(key);
		sb.append("</b></td><td> ");
		sb.append((value != null) ? value : I18N.tr("Unknown"));
		sb.append("</td></tr>");
		return sb.toString();
	}

	public static void limitSize(JComponent c)
	{
		c.setMaximumSize(new Dimension(c.getPreferredSize().width, c
				.getMaximumSize().height));
	}

	public static void bindExpandCollapseKeysToTree(final JTree tree)
	{
		Action treeExpandAction = new AbstractAction() {
			public void actionPerformed(ActionEvent event)
			{
				TreePath path = tree.getSelectionPath();
				if (path != null) {
					GUIHelper.expandAllNodes(tree, path, true);
				}
			}
		};
		tree.getActionMap().put(treeExpandAction, treeExpandAction);
		tree.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_MULTIPLY, 0), treeExpandAction);
		tree.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_ASTERISK, KeyEvent.SHIFT_MASK), treeExpandAction);

		Action treeCollapseAction = new AbstractAction() {
			public void actionPerformed(ActionEvent event)
			{
				TreePath path = tree.getSelectionPath();
				if (path != null) {
					GUIHelper.expandAllNodes(tree, path, false);
				}
			}
		};
		tree.getActionMap().put(treeCollapseAction, treeCollapseAction);
		tree.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_DIVIDE, 0), treeCollapseAction);
	}
	
	/**
	 * Adds some Emacs like keybindings to a table for moving between rows.
	 */
	public static void bindEmacsKeysToTable(JTable jta)
	{
		ActionListener al = jta.getActionForKeyStroke(KeyStroke.getKeyStroke(
				KeyEvent.VK_DOWN, 0));
		jta.registerKeyboardAction(al, KeyStroke.getKeyStroke(KeyEvent.VK_N,
				InputEvent.CTRL_MASK), JComponent.WHEN_FOCUSED);
		al = jta.getActionForKeyStroke(KeyStroke
				.getKeyStroke(KeyEvent.VK_UP, 0));
		jta.registerKeyboardAction(al, KeyStroke.getKeyStroke(KeyEvent.VK_P,
				InputEvent.CTRL_MASK), JComponent.WHEN_FOCUSED);
		al = jta.getActionForKeyStroke(KeyStroke.getKeyStroke(
				KeyEvent.VK_PAGE_DOWN, 0));
		jta.registerKeyboardAction(al, KeyStroke.getKeyStroke(KeyEvent.VK_V,
				InputEvent.CTRL_MASK), JComponent.WHEN_FOCUSED);
		al = jta.getActionForKeyStroke(KeyStroke.getKeyStroke(
				KeyEvent.VK_PAGE_UP, 0));
		jta.registerKeyboardAction(al, KeyStroke.getKeyStroke(KeyEvent.VK_V,
				InputEvent.ALT_MASK), JComponent.WHEN_FOCUSED);
		al = jta.getActionForKeyStroke(KeyStroke.getKeyStroke(KeyEvent.VK_HOME,
				InputEvent.CTRL_MASK));
		jta.registerKeyboardAction(al, KeyStroke.getKeyStroke(KeyEvent.VK_LESS,
				InputEvent.ALT_MASK), JComponent.WHEN_FOCUSED);
		al = jta.getActionForKeyStroke(KeyStroke.getKeyStroke(KeyEvent.VK_END,
				InputEvent.CTRL_MASK));
		jta.registerKeyboardAction(al, KeyStroke.getKeyStroke(KeyEvent.VK_LESS,
				InputEvent.ALT_MASK + InputEvent.SHIFT_MASK),
				JComponent.WHEN_FOCUSED);
	}

	private static class SizeListener extends ComponentAdapter
	{

		private Component source;
		private int x;
		private int y;

		public SizeListener(Component source, int x, int y)
		{
			this.source = source;
			this.x = x;
			this.y = y;
		}

		public void componentResized(ComponentEvent e)
		{
			e.getComponent().removeComponentListener(this);
			GUIHelper.showPopupMenu((JPopupMenu)e.getComponent(), source, x, y);
		}
	}

}