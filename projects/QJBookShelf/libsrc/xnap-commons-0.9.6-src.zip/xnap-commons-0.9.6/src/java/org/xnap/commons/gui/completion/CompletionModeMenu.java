/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import static org.xnap.commons.gui.completion.CompletionModeFactory.I18N;
import java.awt.event.ActionEvent;
import java.util.Enumeration;
import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import org.xnap.commons.gui.completion.CompletionModeFactory.CompletionModeInfo;
import org.xnap.commons.gui.util.IconHelper;

/**
 * Provides a graphical interface to the user for
 * selecting his/her favorite completion mode.
 * <p>
 * It offers all the completion modes installed in the {@link CompletionModeFactory}
 * as options to the user.
 * 
 * It can be used as follows:
 * 
 * <pre>
 * JTextField jtf = new JTextField();
 * Completion comp = new Completion(jtf);
 * jtf.addMouseListener(new PopupListener(new CompletionModeMenu(comp)));
 * </pre> 
 * 
 * See also {@link Completion} and {@link org.xnap.commons.gui.util.PopupListener}.
 * 
 * @author Felix Berger
 */
public class CompletionModeMenu extends JMenu
{

	private Completion completion;
	private ButtonGroup completionGroup = new ButtonGroup();

	public CompletionModeMenu(Completion comp)
	{
		super(I18N.tr("Text Completion"));
		setIcon(IconHelper.getMenuIcon("completion.png"));
		completion = comp;
		
		CompletionModeInfo[] infos = CompletionModeFactory.getInstalledCompletionModes();
		for (CompletionModeInfo info : infos) {
			addMode(info);
		}
		
		addSeparator();
		addMode(new CompletionModeInfo
				(I18N.tr("Application Default"), 
				 GlobalDefaultCompletionMode.class.getName()));
		
		completion.addCompletionModeListener(new CompletionModeChangeHandler());
	}

	private void addMode(CompletionModeInfo info)
	{
		JCheckBoxMenuItem item = new JCheckBoxMenuItem(
				new CompletionModeAction(info));
		completionGroup.add(item);
		add(item);
		if (info.getClassName().equals(completion.getMode().getClass().getName())) {
			item.setSelected(true);
		}
	}

	private void setMode(CompletionModeInfo info)
	{
		try {
			CompletionMode mode 
				= CompletionModeFactory.createCompletionMode(info);
			completion.setMode(mode);
		}
		catch (IllegalArgumentException iae) {
			throw iae;
		}
		catch (Exception e) {
			// TODO now what
		}
	}

	private class CompletionModeAction extends AbstractAction
	{
		CompletionModeInfo info;
		
		public CompletionModeAction(CompletionModeInfo info)
		{
			this.info = info;
			
			putValue(Action.NAME, info.getName());
			putValue(Action.ACTION_COMMAND_KEY, info.getClassName());
		}

		public void actionPerformed(ActionEvent e)
		{
			setMode(info);
		}
	}

	private class CompletionModeChangeHandler implements CompletionModeListener {
	
		public void modeChanged(Class oldMode, Class newMode)
		{
			for (Enumeration e = completionGroup.getElements(); 
			e.hasMoreElements();) {
				AbstractButton b = (AbstractButton)e.nextElement();
				Action a = b.getAction();
				if (a != null && a.getValue(Action.ACTION_COMMAND_KEY).equals
						(newMode.getName())) {
					b.setSelected(true);
					return;
				}
			}
		}
	}
}
