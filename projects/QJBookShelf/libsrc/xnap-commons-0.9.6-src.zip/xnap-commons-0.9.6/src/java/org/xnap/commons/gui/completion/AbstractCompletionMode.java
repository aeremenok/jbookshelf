/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import javax.swing.text.JTextComponent;

/**
 * Abstract convenience class which provides some wrapping function to ease
 * the implementation of a {@link CompletionMode}.
 * 
 * @author Felix Berger
 */
public abstract class AbstractCompletionMode implements CompletionMode
{
	
	private Completion completion;
	
	/*
	 * @see org.xnap.commons.gui.completion.CompletionMode#enable(org.xnap.commons.gui.completion.Completion)
	 */
	public void enable(Completion completion)
	{
		this.completion = completion;
		enable();
	}

	/**
	 * Has to be implemented by subclasses which don't have to worry about
	 * setting the completion object and simply use the accessors provided here. 
	 */
	protected abstract void enable();
	
	/*
	 * @see org.xnap.commons.gui.completion.CompletionMode#disable()
	 */
	public abstract void disable();

	/**
	 * Convenience accessor, returns the completion model
	 */
	protected CompletionModel getModel()
	{
		return completion.getModel();
	}

	/**
	 * Convenience accessor, returns the text component.
	 */
	protected JTextComponent getTextComponent()
	{
		return completion.getTextComponent();
	}

	/**
	 * Returns the completion object that uses this completion mode.
	 */
	protected Completion getCompletion()
	{
		return completion;
	}
	
	/**
	 * Convenience accessor, returns the text which should be completed.
	 * @return the whole text up to the current caret position, if 
	 * {@link Completion#isWholeTextCompletion()} is true, otherwise the
	 * previous word up to the current care position
	 */
	protected String getText()
	{
		return completion.getText();
	}
	
	/**
	 * Convenience setter, forwards to 
	 * {@link Completion#setText(String, int, int)}.
	 */
	protected void setText(String text, int selectionStart,
						   int selectionEnd)
	{
		completion.setText(text, selectionStart, selectionEnd);
	}

	/**
	 * Convenience setter, forwards to {@link Completion#setText(String)}.
	 */
	protected void setText(String text)
	{
		completion.setText(text);
	}
}
