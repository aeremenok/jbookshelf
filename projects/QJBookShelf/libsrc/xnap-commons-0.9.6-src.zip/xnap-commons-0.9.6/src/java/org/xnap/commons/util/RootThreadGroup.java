/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.util;

/**
 * The root thread group. Used to handle all uncaught exceptions that
 * occur at any child thread of the group.
 * 
 * <p>If you want to catch all uncaught exceptions in your application, 
 * use the following code snippet:
 * 
 * <p><pre>
 *   public static void main(final String[] argv) {
 * 	 	 RootThreadGroup tg = new RootThreadGroup("RootThreadGroup",
 *                                               new ErrorHandler());
 *		 Thread mainRunner = new Thread(tg, "XNapMain") {
 *		 	 public void run() {
 *				  runMain(argv);
 *			 }
 *		 };
 *		 mainRunner.start();
 *	 }
 *	
 *   public static void runMain(final String[] argv) {
 * 	 	// run the actual main code
 *   }
 * </pre>
 */
public class RootThreadGroup extends ThreadGroup {

	private UncaughtExceptionListener listener;
	
	public RootThreadGroup(String name, UncaughtExceptionListener listener,
						   boolean installAsAWTExceptionHandler) 
	{
		super(name);
		
		this.listener = listener;
		
		if (installAsAWTExceptionHandler) {
			installAsAWTExceptionHandler();
		}
	}

	public RootThreadGroup(String name, UncaughtExceptionListener listener)
	{
		this(name, listener, true);
	}

	/**
	 * Invoked by the AWTEventQueue in case of an unhandled exception.
	 * @param e the uncaught exception
	 * @see #installAsAWTExceptionHandler()
	 */
	public void handle(Throwable e)
	{
		listener.uncaughtException(Thread.currentThread(), e);
	}

	/**
	 * Installs this class as the awt exception handler.
	 */
	public void installAsAWTExceptionHandler()
	{
		System.setProperty("sun.awt.exception.handler", 
		   				   "org.xnap.commons.util.AWTExceptionHandler");
	}

	/**
	 * @see java.lang.ThreadGroup#uncaughtException(java.lang.Thread,
	 * java.lang.Throwable)
	 */
	public void uncaughtException(Thread t, Throwable e) 
	{
		listener.uncaughtException(t, e);
	}

}
