/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.table;

import javax.swing.table.DefaultTableCellRenderer;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.util.StringHelper;

/**
 * Renders filesize for a table cell.
 *
 * @see org.xnap.commons.util.StringHelper#formatSize(long)
 */
public class FilesizeCellRenderer extends DefaultTableCellRenderer
{
	private static final I18n i18n = I18nFactory.getI18n(FilesizeCellRenderer.class);

    public FilesizeCellRenderer() 
    {
		setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
    }

    public void setValue(Object value) 
    {
		if (value instanceof Number) {
			long number = ((Number)value).longValue();
			setToolTipText(String.format(i18n.tr("%,d bytes"), number)); 
			super.setValue(StringHelper.formatSize(number));
		}
		else {
			setToolTipText(null);
			super.setValue(null);
		}
    } 

} 
