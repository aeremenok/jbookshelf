/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.action;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import org.xnap.commons.settings.BooleanSetting;

/**
 * Provides a default implementation for a toggle action that monitors 
 * a {@link org.xnap.commons.settings.BooleanSetting}.
 */
public abstract class AbstractToggleSettingAction extends AbstractToggleAction 
    implements PropertyChangeListener {
    
	BooleanSetting setting;
    
    /**
     * Constructs a toggle action that monitors a boolean preference key.
     *
     * @param setting the setting to monitor
     */
    public AbstractToggleSettingAction(BooleanSetting setting)
    {
    	if (setting == null) {
			throw new IllegalArgumentException();
		}
		
		this.setting = setting;
		
		setting.addPropertyChangeListener(this);

		// initialize
		boolean value = setting.getValue();
		setSelected(value);
		toggled(value);
    }

    public void propertyChange(PropertyChangeEvent e) 
    {
		boolean newValue = setting.getValue();
		setSelected(newValue);
    }

    /**
     * Updates the setting.
     */
    @Override
    public void toggled(boolean selected)
    {
    	setting.setValue(selected);
    }

}
