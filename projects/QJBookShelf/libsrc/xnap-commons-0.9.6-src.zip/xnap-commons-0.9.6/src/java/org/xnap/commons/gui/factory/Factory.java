package org.xnap.commons.gui.factory;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.text.JTextComponent;
import org.xnap.commons.gui.action.ToggleAction;
import org.xnap.commons.gui.completion.Completion;

/**
 * Defines the requirements for a factory class used by 
 * {@link org.xnap.commons.gui.Builder}.
 */
public interface Factory {
	
	/**
	 * Adds a completion mode menu to the text component which pops up
	 * when the platform dependent popup action is triggered.
	 * 
	 * @param textComponent
	 * @param completion the completion object whose completion modes
	 * are set by the menu
	 */
	void addCompletionModeMenu(JTextComponent textComponent, Completion completion);
	
	/**
	 * Adds a completion mode menu as a sub menu to the <code>menu</code>.
	 * 
	 * @param menu the menu into which the completion mode menu is plugged
	 * @param completion the completion object whose completion modes
	 * are set by the menu
	 */
	void addCompletionModeMenu(JMenu menu, Completion completion);
	
	/**
	 * Creates a button for an action.
	 *
	 * @param action the action
	 * @return the button
	 */
	AbstractButton createButton(Action action);
	
	/**
	 * Creates a checkbox for a toggle action.
	 * 
	 * @param action the action
	 * @return the checkbox 
	 */
	AbstractButton createCheckBox(ToggleAction action);
	
	/**
	 * Creates an icon button for an action that only shows the icon and
	 * not the text of the action.
	 * 
	 * @param action the action
	 * @return the button
	 */
	AbstractButton createIconButton(Action action);
	
	/**
	 * Creates a toolbar button for an action making sure the right
	 * sized icon is used.
	 * 
	 * @param action the action
	 * @return the button
	 */
	AbstractButton createToolBarButton(Action action);
	
	/**
	 * Creates a menu item for an action making sure the right sized icon
	 * is used.
	 * 
	 * @param action the action
	 * @return the menu item
	 */
	JComponent createMenuItem(Action action);
	
	/**
	 * Sets a property of the factory to configure it.
	 * 
	 * @param key the key
	 * @param value the value
	 */
	void setProperty(Object key, Object value);

}
