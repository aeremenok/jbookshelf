/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.Component;
import java.io.File;
import java.io.IOException;
import javax.swing.Box;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import org.xnap.commons.gui.util.GUIHelper;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.settings.BooleanSetting;
import org.xnap.commons.util.FileHelper;

/**
 * Provides a set of static methods to display common dialogs.
 */
public class Dialogs {

	private static final I18n i18n = I18nFactory.getI18n(Dialogs.class);
	
    /**
     * Copies <code>files</code> to <code>target</code>. Shows a dialog
     * in case of an error.
     *  
     * @see FileHelper#copy(File, File)
     * @param files the files to copy
     * @param target the target directory
     * @return true, if copy was successful; false, otherwise or if 
     *  <code>files</code> is empty
     *  TODO copying could be costly, show progress dialog here too, see DropFileTree..
     */
    public static boolean executeCopy(Component parent, File[] files, File target)
    {
		if (files != null) {
			boolean success = true;
			for (int i = 0; i < files.length; i++) {
				try {
					FileHelper.copy(files[i], new File
						(target, files[i].getName()));
				}
				catch (IOException e) {
					showError
						(parent, 
						 i18n.tr("Could not copy {0} to {1}: {2}.", 
						 		 files[i].getAbsolutePath(), 
								 target.getAbsolutePath(),
								 e.getLocalizedMessage()),
						 e);
					success = false;
				}
			}
			return success;
		}
	
		return false;
    }

    /**
     * Moves <code>files</code> to <code>target</code>. Shows a dialog
     * in case of an error. Renames each file in case it already exists
     * in <code>target</code>. 
     *  
     * @param files the files to copy
     * @param target the target directory
     * @return true, if move was successful; false, otherwise or if 
     *  <code>files</code> is empty
     */
    public static boolean executeMove(Component parent, File[] files, File target)
    {
		if (files != null) {
			boolean success = true;
			for (int i = 0; i < files.length; i++) {
				try {
					FileHelper.moveUnique(files[i], target.getAbsolutePath());
				}
				catch (IOException e) {
					showError
						(parent, 
						 i18n.tr("Could not move {0} to {1}: {2}.", 
						 		 files[i].getAbsolutePath(), 
								 target.getAbsolutePath(),
								 e.getLocalizedMessage()),
						 e);
					success = false;
				}
			}
			return success;
		}
	
		return false;
     }

    /**
     * Shows an input dialog and returns the entered value or <code>null</code>.
     * @param parent the parent component the input dialog is centered on
     * @param message the message giving details about the requested input
     * @param title the title of the dialog
     * @return the entered value or <code>null</code> if the dialog was cancelled
     */
    public static String requestInput(Component parent, String message, String title)
    {
		return JOptionPane.showInputDialog
			(parent, message, title, JOptionPane.QUESTION_MESSAGE);
    }

    /**
     * Shows a password input dialog and returns the entered value or <code>null</code>.
     * @param parent the parent component the input dialog is centered on
     * @param message the message giving details about the requested input
     * @param title the title of the dialog
     * @return the entered value or <code>null</code> if the dialog was cancelled
     */
    public static String requestPassword(Component parent, String message, String title)
    {
		JPasswordField passwordField = new JPasswordField();
		Object[] content = new Object[] {
			message,
			passwordField,
		};

		if (JOptionPane.showConfirmDialog(parent, content, title, 
				JOptionPane.OK_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE)
				== JOptionPane.OK_OPTION) {
			return new String(passwordField.getPassword());
		} else {
			return null;
		}
    }

	 /**
	  * Shows a confirmation dialog asking the user if he really wants to quit
	  * the application.
	  * <p>
	  * It also offers a checkbox "Always quit without prompting me." If the user
	  * checks it, the next time this function is called it will return <code>true</code>
	  * without showing the dialog.
	  * @param parent the parent component this dialog is centered on
	  * @param message a message explaining what it means to quit the 
	  * application
	  * @param setting the boolean setting that stores the state of the checkbox
	  * @return true, if user presses okay button.
	  */
	 public static boolean showCloseDialog(Component parent, String message, BooleanSetting setting) 
	 {
		 JCheckBox alwaysQuitCheckBox 
			 = new JCheckBox(i18n.tr("Always quit without prompting me"));
		 if (setting != null) {
		 	alwaysQuitCheckBox.setSelected(setting.getValue());
		 }

		 Object[] content = new Object[] {
			 message,
			 i18n.tr("Do you really want to quit?"), 
			 alwaysQuitCheckBox
		 };

		 int response = JOptionPane.showConfirmDialog
			 (parent, content, i18n.tr("Quit"), JOptionPane.OK_CANCEL_OPTION);

		 setting.setValue(alwaysQuitCheckBox.isSelected());

		 return (response == JOptionPane.OK_OPTION);
	 }	

	 /**
	  * Shows a confirmation dialog and with a message and check box that can
	  * be selected to not display the dialog in the future anymore.
	  * 
	  * <p>If the specified setting is not <code>null</code> and it's value is 
	  * <code>false</code> the dialog is not displayed and 
	  * <code>JOptionPane.YES_OPTION</code> is returned.
	  * 
	  * @param parent parent component used for centering the dialog
	  * @param message the message to show
	  * @param title the title of the message border
	  * @param optionType an int designating the options available on the 
	  * dialog: <code>JOptionPane.YES_NO_OPTION</code>, or 
	  * <code>JOptionPane.YES_NO_CANCEL_OPTION</code> 
	  * @param setting used to store the reverse state of the 
	  * <it>Do not ask me again</it> check box; if null, the state is not
	  * saved
	  * @return an int indicating the option selected by user
	  */
	 public static int showConfirmDialog(Component parent,
	 									 String message,
										 String title, 
										 int optionType,
										 BooleanSetting setting)
	 {
		 if (setting != null && !setting.getValue()) {
			 return JOptionPane.YES_OPTION;
		 }

		 JCheckBox doNotAskAgainCheckBox = new JCheckBox(i18n.tr("Do not ask again"));

		 JLabel messageLabel = new JLabel(GUIHelper.tt(message, 400));
		 //messageLabel.setBorder(GUIHelper.createDefaultBorder(title));

		 Object[] content = new Object[] {
			 messageLabel, 
			 Box.createVerticalStrut(10), 
			 doNotAskAgainCheckBox,
			 Box.createVerticalStrut(5),
		 };

		 int response = JOptionPane.showConfirmDialog
			 (parent, content, title, optionType);

		 if (setting != null) {
		 	setting.setValue(!doNotAskAgainCheckBox.isSelected());
		 }

		 return response;
    }

	 /**
	  * Displays a dialog that with a list of files asking the user to confirm 
	  * a copy operation to the specified target.
	  *
	  * <p>If the specified setting is not <code>null</code> and it's value is 
	  * <code>false</code> the dialog is not displayed and the specified
	  * files are returned. 
	  *
	  * @param parent the dialog parent
	  * @param files the files that are to be displayed in the list 
	  * @param target the destination path
	  * @param setting used to store the reverse state of the 
	  * <it>Do not ask me again</it> check box; if null, the state is not
	  * saved
	  * @return the selected files, i.e. the ones that should be copied; if the 
	  * user selected cancel an empty array is returned, never returns null
	  * 
	  * @see #showFilesActionDialog(Component, File[], String, String, BooleanSetting)
	  */
    public static File[] showCopyDialog(Component parent, File files[], File target,
    									BooleanSetting setting)
    {
		return showFilesActionDialog
			(parent, files, 
			 i18n.trn("Do you really want to copy the selected file to \"{0}\"?", 
					 "Do you really want to copy the selected files to \"{0}\"?",
					 files.length,
			 		 target.getAbsolutePath()),
			 i18n.tr("Copy Files"), setting);
    }

	 /**
	  * Displays a dialog that with a list of files asking the user to confirm 
	  * a delete operation.
	  *
	  * <p>If the specified setting is not <code>null</code> and it's value is 
	  * <code>false</code> the dialog is not displayed and the specified
	  * files are returned. 
	  *
	  * @param parent the dialog parent
	  * @param files the files that are to be displayed in the list 
	  * @param setting used to store the reverse state of the 
	  * <it>Do not ask me again</it> check box; if null, the state is not
	  * saved
	  * @return the selected files, i.e. the ones that should be copied; if the 
	  * user selected cancel an empty array is returned, never returns null
	  * 
	  * @see #showFilesActionDialog(Component, File[], String, String, BooleanSetting)
	  */
    public static File[] showDeleteDialog(Component parent, File files[], 
    								      BooleanSetting setting)
    {
		return showFilesActionDialog
			(parent, files, i18n.tr("Do you really want to delete the selected files?"),
			 i18n.tr("Delete Files"), setting);
    }
	
	 /**
	  * Displays a dialog with a message indicating the cause of an error. The 
	  * dialog's title is set to <tt>Error</tt>.
	  *  
	  * @param parent the parent component
	  * @param message the error message
	  */
	public static void showError(Component parent, String message)
	{
		showError(parent, message, i18n.tr("Error"));
	}

	 /**
	  * Displays a dialog with a message indicating the cause of an error
	  * a stack trace of the specified exception providing details. The dialog's
	  * title is set to <tt>Error</tt>.
	  *  
	  * @param parent the parent component
	  * @param message the error message
	  */
    public static void showError(Component parent, String message, Exception e)
    {
    	showError(parent, message, i18n.tr("Error"), e);
    }
		
	 /**
	  * Displays a dialog with a message indicating the cause of an error.
	  *  
	  * @param parent the parent component
	  * @param message the error message
	  * @param title the dialog title
	  */
    public static void showError(Component parent, String message, String title)
    {
		JOptionPane.showMessageDialog
			(parent, message, title, JOptionPane.ERROR_MESSAGE);
    }
    
	 /**
	  * Displays a dialog with a message indicating the cause of an error
	  * a stack trace of the specified exception providing details.
	  *  
	  * @param parent the parent component
	  * @param message the error message
	  * @param title the dialog title
	  * @param exception the exception that caused the error 
	  */
    public static void showError(Component parent, String message, String title, 
    		Exception exception)
    {
    	ErrorDialog.show(parent, message, title, exception
    			
    	);
    }

	 /**
	  * Displays a dialog with a message, a list of files and a check box that 
	  * can be selected to not display the dialog in the future anymore.
	  * 
	  * <p>If the specified setting is not <code>null</code> and it's value is 
	  * <code>false</code> the dialog is not displayed and the specified
	  * files are returned. 
	  *
	  * @param parent the dialog parent
	  * @param files the files that are to be displayed in the list
	  * @param title the dialog's title
	  * @param message the message
	  * @param setting used to store the reverse state of the 
	  * <it>Do not ask me again</it> check box; if null, the state is not
	  * saved
	  * @return the selected files; if the dialog was cancelled an empty array
	  * is returned, never returns null
	  */
    public static File[] showFilesActionDialog
		(Component parent, File files[], String message, String title, 
		 BooleanSetting setting)
    {
		if (setting != null && !setting.getValue()) {
			return files;
		}

		JList fileList = new JList(files);
		fileList.setCellRenderer(new FileListCellRenderer());
		fileList.setVisibleRowCount(4);

		// select all files
		fileList.setSelectionInterval(0, files.length - 1);

		JCheckBox doNotAskAgainCheckBox = new JCheckBox(i18n.tr("Do not ask again"));

		Object[] content = new Object[] {
			message,
			Box.createVerticalStrut(10),
			new JScrollPane(fileList), 
			Box.createVerticalStrut(10),
			doNotAskAgainCheckBox, 
			Box.createVerticalStrut(5),
		};
	
		int response = JOptionPane.showConfirmDialog
            (parent, content, title, JOptionPane.YES_NO_OPTION);
	
		 if (setting != null) {
		 	setting.setValue(!doNotAskAgainCheckBox.isSelected());
		 }
	
		if (response == JOptionPane.YES_OPTION) {
			Object rows[] = fileList.getSelectedValues();
			File selected[] = new File[rows.length];
			System.arraycopy(rows, 0, selected, 0, selected.length);
			return selected;
		}
		
		return new File[0];
    }
    
	 /**
	  * Displays a dialog with an information message.
	  *  
	  * @param parent the parent component
	  * @param message the error message
	  * @param title the dialog title
	  * 
	  * @see JOptionPane#showMessageDialog(java.awt.Component, java.lang.Object, java.lang.String, int)
	  */
    public static void showInfo(Component parent, String message, String title)
    {
		JOptionPane.showMessageDialog
			(parent, message, title, JOptionPane.INFORMATION_MESSAGE);
    }

	 /**
	  * Displays a dialog that with a list of files asking the user to confirm 
	  * a delete operation.
	  *
	  * <p>If the specified setting is not <code>null</code> and it's value is 
	  * <code>false</code> the dialog is not displayed and the specified
	  * files are returned. 
	  *
	  * @param parent the dialog parent
	  * @param files the files that are to be displayed in the list 
	  * @param target the destination path
	  * @param setting used to store the reverse state of the 
	  * <it>Do not ask me again</it> check box; if null, the state is not
	  * saved
	  * @return the selected files, i.e. the ones that should be copied; if the 
	  * user selected cancel an empty array is returned, never returns null
	  * 
	  * @see #showFilesActionDialog(Component, File[], String, String, BooleanSetting)
	  */
    public static File[] showMoveDialog(Component parent, File files[], File target, 
    									BooleanSetting setting)
    {
		return showFilesActionDialog
			(parent, files, 
			 i18n.tr("Do you really want to move the selected files to \"{0}\"?", 
			 		 target.getAbsolutePath()),
			 i18n.tr("Move Files"), setting);
    }

    /**
     * This class provides a list renderer for <code>File</code> objects. The
     * path is supressed when showing filenames.
     */
    public static class FileListCellRenderer extends DefaultListCellRenderer
    {

    	public FileListCellRenderer()
        {
        }

        public Component getListCellRendererComponent(JList list, Object value, 
    						  int index, 
    						  boolean isSelected, 
    						  boolean cellHasFocus) 
        {
        	super.getListCellRendererComponent(list, value, index, isSelected, 
        									   cellHasFocus);
    	
        	if (value instanceof File) {
        		setText(((File)value).getName());
        	}
    	
        	return this;
        }
        
    }

}

