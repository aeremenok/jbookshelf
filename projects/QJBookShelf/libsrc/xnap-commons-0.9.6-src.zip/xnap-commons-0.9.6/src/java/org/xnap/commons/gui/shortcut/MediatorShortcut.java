package org.xnap.commons.gui.shortcut;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.KeyStroke;
import org.xnap.commons.settings.KeyStrokeSetting;

public class MediatorShortcut {

	private JComponent component;
	private KeyStrokeSetting setting;
	private Action action;
	private boolean enabled = true;
	private PropertyChangeHandler handler = new PropertyChangeHandler();
	
	public MediatorShortcut(KeyStrokeSetting setting, Action action, JComponent component) 
	{
		this.component = component;
		this.action = action;
		this.setting = setting;
		component.getActionMap().put(action, action);
		updateKeyStroke(null);
		setting.addPropertyChangeListener(handler);
	}
	
	private void updateKeyStroke(KeyStroke oldStroke)
	{
		if (oldStroke != null && component.getInputMap().get(oldStroke) == action) {
			// only remove old key stroke, if it's still pointing to our action 
			component.getInputMap().remove(oldStroke);
		}
		
		if (enabled) {
			component.getInputMap().put(setting.getValue(), action);
		}
		else {
			component.getInputMap().remove(setting.getValue());
		}
	}

	public JComponent getComonent() 
	{
		return component;
	}
	
	public Action getAction()
	{
		return action;
	}
	
	public KeyStrokeSetting getSetting()
	{
		return setting;
	}

	public void setEnabled(boolean enabled) 
	{
			if (this.enabled != enabled) {
				this.enabled = enabled;
				updateKeyStroke(null);
				if (enabled) {
					setting.addPropertyChangeListener(handler);
				}
				else {
					setting.removePropertyChangeListener(handler);
				}
			}
	}
	
	public boolean isEnabled() 
	{
		return enabled;
	}

	private class PropertyChangeHandler implements PropertyChangeListener
	{

		public void propertyChange(PropertyChangeEvent evt) 
		{
			updateKeyStroke((KeyStroke)evt.getOldValue());
		}
		
	}

	
	
}
