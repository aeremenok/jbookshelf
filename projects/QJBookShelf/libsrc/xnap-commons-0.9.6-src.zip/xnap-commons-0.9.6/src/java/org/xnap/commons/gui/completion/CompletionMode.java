/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

/**
 * Classes implementing this interface handle the way completion is 
 * actually done.
 *
 * They decide when and how to offer completion to the user. Completion may be
 * triggered using a special key, it may be visible all the time, it may use a
 * {@link org.xnap.commons.gui.completion.CompletionPopup} to present all 
 * possibilities or may insert the text directly.
 * 
 * @author Felix Berger
 * TODO symmetrical interface + IllegalStateException
 */
public interface CompletionMode
{
	/**
	 * Enables the completion mode letting it add its listeners to the text
	 * component.
	 * 
	 * @param completion provides all components and information the completion 
	 * mode must know about
	 */
	void enable(Completion completion);
	/**
	 * Disables the completion mode letting it remove its listeners from the
	 * text component.
	 */
	void disable();
}
