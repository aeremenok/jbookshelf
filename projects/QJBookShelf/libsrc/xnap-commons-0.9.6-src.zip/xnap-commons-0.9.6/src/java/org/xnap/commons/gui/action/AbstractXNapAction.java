/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.action;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenuItem;
import javax.swing.JToggleButton;
import javax.swing.SwingUtilities;
import org.xnap.commons.gui.ToolBarButton;
import org.xnap.commons.gui.ToolBarToggleButton;
import org.xnap.commons.gui.util.IconHelper;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * Provides an abstract action. All actions should inherit this class,
 * since it provides a few convenience methods. 
 */
public abstract class AbstractXNapAction extends AbstractAction {

    public static final String ICON_FILENAME = "XNapIcon";

	public AbstractXNapAction() 
	{
	}

	/**
	 * Enables/disables the action in the swing thread by calling 
	 * {@link SwingUtilities#invokeLater(java.lang.Runnable)}.
	 * @param enabled parameter passed to {@link Action#setEnabled(boolean)}.
	 */
	public void setEnabledLater(final boolean enabled) 
	{
		Runnable runner = new Runnable() 
			{
				public void run()
				{
					setEnabled(enabled);
				}
			};
		SwingUtilities.invokeLater(runner);
	}
	
	/**
	 * Convenience method for translating which can be used by subclasses.
	 * <p>
	 * This works because subclasses are in their own package, so the right
	 * resource bundle can be chosen.
	 */
	protected String tr(String text)
	{
		I18n i18n = I18nFactory.getI18n(getClass());
		return i18n.tr(text);
	}

	/**
	 * See {@link #tr(String)} and {@link I18n#tr(String, Object[])}.
	 */
	protected String tr(String text, Object ... objects)
	{
		I18n i18n = I18nFactory.getI18n(getClass());
		return i18n.tr(text, objects);
	}
	
	// TODO comment
	public static Icon getIcon(AbstractButton button, String filename)
	{
		if (button instanceof JCheckBox || button instanceof JCheckBoxMenuItem) {
			// icons look ugly with check boxes
			return null;
		}
		else if (button instanceof ToolBarButton || button instanceof ToolBarToggleButton) {
			return IconHelper.getToolBarIcon(filename);
		}
		else if (button instanceof JButton || button instanceof JToggleButton) {
			return IconHelper.getButtonIcon(filename);
		}
		else if (button instanceof JMenuItem) {
			return IconHelper.getMenuIcon(filename);
		}
		return null;
	}
	
	public static void initialize(AbstractButton button, Action action)
	{
		String filename = (String)action.getValue(AbstractXNapAction.ICON_FILENAME);
		// some components like JMenuItem objects require an empty icon for
		// alignment reasons if no icon is available, therefore pass some
		// crazy string that does not point to a valid icon filename
		button.setIcon(getIcon(button, (filename != null) ? filename : "does-not-exist"));

		if (action instanceof ToggleAction) {
			button.setSelected(((ToggleAction)action).isSelected());
		}
		
		// FIXME will the garbage collecter ever get a chance to clean up 
		// button as long as action is around?
		// well, no, see source of javax.swing.AbstractActionPropertyChangeListener
		action.addPropertyChangeListener(new ActionPropertyListener(button));
	}

	/**
	 * This class is static to allow the garbage collector to finalize the 
	 * component although the action is still existant. 
	 * 
	 * Does this make sense at all? The action still holds a reference to the
	 * button through the listener...
	 * 
	 * @author Steffen Pingel
	 */
	private static class ActionPropertyListener implements PropertyChangeListener {

		private AbstractButton button;

		public ActionPropertyListener(AbstractButton button)
		{
			this.button = button;
		}

		public void propertyChange(PropertyChangeEvent e) 
		{
			if (e.getPropertyName().equals(ToggleAction.SELECTED)) {
				button.setSelected(((Boolean)e.getNewValue()).booleanValue());
			}
			else if (e.getPropertyName().equals(AbstractXNapAction.ICON_FILENAME)) {
				String filename = (String)e.getNewValue();
				button.setIcon(getIcon(button, filename));
			}
		}
	 
	}
	
}
