/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import static org.xnap.commons.gui.completion.CompletionModeFactory.I18N;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import org.xnap.commons.gui.action.AbstractXNapAction;

/**
 * Action that allows clearing the default completion model.
 * <p>
 * Can be plugged into the completion mode menu. 
 * @author Felix Berger
 */
public class ClearCompletionModelAction extends AbstractXNapAction 
{

	private DefaultCompletionModel model;
	
	public ClearCompletionModelAction(DefaultCompletionModel model)
	{
		if (model == null) {
			throw new NullPointerException("model must not be null");
		}
		this.model = model;
		
		putValue(Action.NAME, I18N.tr("Clear History"));
		putValue(AbstractXNapAction.ICON_FILENAME, "history_clear.png");
	}
	
	public void actionPerformed(ActionEvent e) 
	{
		model.clear();
	}

}
