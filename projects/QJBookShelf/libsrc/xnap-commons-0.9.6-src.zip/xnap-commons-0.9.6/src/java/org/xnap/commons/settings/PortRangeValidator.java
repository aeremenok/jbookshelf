/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import java.util.StringTokenizer;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.util.PortRange;

/**
 * A port range validator. Port ranges are used to specify one or more tcp 
 * ports. The format is: [([:number:]*|[:number:]*-[:number:]*);]*
 * TODO there must be a + somewhere, the empty string is not allowed
 */
public class PortRangeValidator implements Validator
{

	private static final I18n i18n = I18nFactory.getI18n(PortRangeValidator.class);
	
    /**
     * The default validator that allows ranges between 
     * {@link PortRange#MIN_PORT} and {@link PortRange#MAX_PORT}.
     */
    public static final PortRangeValidator DEFAULT = new PortRangeValidator();

    private int min;
    private int max;
    private boolean valid;

    public PortRangeValidator(int min, int max)
    {
    	this.min = min;
    	this.max = max;
    }

    public PortRangeValidator()
    {
    	this(PortRange.MIN_PORT, PortRange.MAX_PORT);
    }

    /**
     * Checks if <code>value</code> is a valid port range string.
     *
     * @exception IllegalArgumentException if string format is invalid
     */
    public void validate(String value)
    {
    	valid = false;

    	StringTokenizer t = new StringTokenizer(value, ";");
    	while (t.hasMoreTokens()) {
    		String ports = t.nextToken().trim();
    		
    		if (ports.length() == 0) {
    			continue;
    		}
    		
    		try {
    			if (ports.indexOf("-") != -1) {
    				StringTokenizer u = new StringTokenizer(ports, "-");
    				if (u.countTokens() == 2) {
    					int i = Integer.parseInt(u.nextToken());
    					int j = Integer.parseInt(u.nextToken());
    					check(i);
    					check(j);
    					valid |= (i <= j); 
    				}
    				else {
    					throw(new IllegalArgumentException(i18n.tr("Malformed range.")));
    				}
    			}
    			else {
    				check(Integer.parseInt(ports));
    				valid = true;
    			}
    		}
    		catch (NumberFormatException e) {
    			throw(new IllegalArgumentException(i18n.tr("Malformed number.")));
    		}
    	}
    	
    	if (!valid) {
    		// did not find at least one valid port
    		throw new IllegalArgumentException(i18n.tr("No port given."));
    	}
    }

    /**
     * Checks if <code>i</code> is in range.
     *
     * @exception IllegalArgumentException thrown if i is not in range
     */
    public void check(int i) 
    {
    	if (i < min || i > max) {
    		throw new IllegalArgumentException(i18n.tr("Port out of range {0}.", 
    												   "(" + min + " - " + max + ")"));
    	}
    }

}
