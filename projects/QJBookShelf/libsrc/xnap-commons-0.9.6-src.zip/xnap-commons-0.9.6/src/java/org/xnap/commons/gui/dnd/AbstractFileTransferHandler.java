/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.dnd;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import javax.swing.JComponent;
import javax.swing.TransferHandler;

/**
 * Abstract handler class easing drag and drop support of file objects.
 * <p>
 * Also handles Linux Desktop file drag and drops which don't seem to translate
 * to the {@link java.awt.datatransfer.DataFlavor#javaFileListFlavor}.
 * <p>
 * Subclasses should override {@link #createTransferable(JComponent)}
 * and {@link #importFiles(JComponent, List)}.
 * 
 * @author Felix Berger
 */
public abstract class AbstractFileTransferHandler extends TransferHandler 
{

	/**
	 * URI flavor used for file drag and drops on the Linux desktop.
	 */
	public static DataFlavor linuxURIFlavor;

	static {
		linuxURIFlavor = createLinuxURIFlavor();
	}
	
	private static DataFlavor createLinuxURIFlavor() 
	{
		try { 
			  return new DataFlavor("text/uri-list;class=java.lang.String"); 
		}
		catch (ClassNotFoundException cnfe) { 
			return null;
		}
	}
	
	/**
	 * Returns true if one of the supported flavors is either 
	 * {@link DataFlavor#javaFileListFlavor} or {@link #linuxURIFlavor}.
	 */
	@Override
	public boolean canImport(JComponent comp, DataFlavor[] transferFlavors) 
	{
		for (DataFlavor flavor : transferFlavors) {
			if (flavor.equals(DataFlavor.javaFileListFlavor) 
					|| flavor.equals(AbstractFileTransferHandler.linuxURIFlavor)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Returns {@link TransferHandler#COPY}.
	 */
	@Override
	public int getSourceActions(JComponent c) 
	{
		return TransferHandler.COPY;
	}

	/**
	 * Returns <code>null</code>.
	 * <p>
	 * Subclasses can return a {@link FileTransferable}.
	 */
	@Override
	protected Transferable createTransferable(JComponent c)
	{
		return null;
	}

	/**
	 * Returns <code>false</code>, thus disallowing dropping of files on
	 * the component <code>comp</code>.
	 * <p>
	 * Subclasses should import the list of <code>files</code> and return true
	 * on success.
	 */
	public boolean importFiles(JComponent comp, List<File> files)
	{
		return false;
	}
	
	/**
	 * Overriden to extract the file lists from the different types of 
	 * transferables.
	 */
	@Override
	public boolean importData(JComponent comp, Transferable t) 
	{
		List<File> files = null;
		try {
			if (t.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
				files = (List<File>)t.getTransferData(DataFlavor.javaFileListFlavor);
			}
			else if (t.isDataFlavorSupported(AbstractFileTransferHandler.linuxURIFlavor)) {
				String s = (String)t.getTransferData(AbstractFileTransferHandler.linuxURIFlavor);
				StringTokenizer st = new StringTokenizer(s, System.getProperty("line.separator")); 
				files = new ArrayList<File>(); 
				while (st.hasMoreTokens()) { 
					String file = st.nextToken(); 
					try { 
						URL url = new URL(file); 
						files.add(new File(URLDecoder.decode(url.getPath()))); 
					} 
					catch (MalformedURLException mue) { 
					} 
				}
			}
		}
		catch (UnsupportedFlavorException e) {
			return false;
		}
		catch (IOException e) {
			return false;
		}
		return (files != null && !files.isEmpty()) ? importFiles(comp, files) : false;
	}

}
