/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.io;

import java.awt.Component;

// TODO doc
/**
 * 
 * 
 * Create a top ProgressMonitor with totalSteps set to number of 
 * SubTaskProgressMonitor * SubTaskProgressMonitor amounts.
 * 
 *  <pre>
 *  ProgressMonitor topMonitor = new ProgressDialog();
 *  topMonitor.setTotalSteps(7 * 100);
 *  for (int i = 0; i < 7; i++) {
 *  	new SubTaskProgressMonitor(topMonitor, 100, totalStepsOfSubTask);
 *  }
 *  </pre>
 */
public class SubTaskProgressMonitor implements ProgressMonitor {

	private ProgressMonitor monitor;
	private int workedAmount;
	private int totalAmount;
	private long totalSteps;
	private boolean done;
	private long value;
	
	public SubTaskProgressMonitor(ProgressMonitor monitor, int amount, long totalSteps)
	{
		if (monitor == null) {
			throw new IllegalArgumentException();
		}
		if (amount < 0) {
			throw new IllegalArgumentException("amount may not be less than 0");
		}
		
		this.monitor = monitor;
		this.totalAmount = amount;
		
		setTotalSteps(totalSteps);
	}

	public long getValue()
	{
		return value;
	}
	
	public void setTotalSteps(long totalSteps)
	{
		if (totalSteps < 0) {
			throw new IllegalArgumentException("totalSteps may not be less than 0");
		}
		if (workedAmount > 0) {
			throw new IllegalStateException("totalSteps may not be changed after work() or setValue() has been called");
		}
		this.totalSteps = totalSteps;
	}

	public void setValue(long value)
	{
		if (done) {
			throw new IllegalStateException("monitor is already done");
		}
		if (value > totalSteps) {
			throw new IllegalArgumentException("value may not exceed totalSteps (" + value + " > " + totalSteps + ")");
		}
		if (this.value == value) {
			return;
		}
		if (value < this.value) {
			throw new IllegalArgumentException("value may not decrease (" + value + " < " + this.value + ")");
		}
		
		this.value = value;
		double percent = (double)value / totalSteps;
		int newAmount = (int)(percent * totalAmount);
		if (newAmount > workedAmount) {	
			monitor.work(newAmount - workedAmount);
			workedAmount += newAmount - workedAmount;
		}
	}
	
	public void work(long amount)
	{
		setValue(value + amount);
	}
	
	public void done() 
	{
		if (done) {
			return;
		}
		done = true;
		monitor.work(totalAmount - workedAmount);
	}

	public boolean isCancelled()
	{
		return monitor.isCancelled();
	}

	public void setCancelEnabled(boolean enabled)
	{
		monitor.setCancelEnabled(enabled);
	}

	public void setText(String text)
	{
		monitor.setText(text);
	}

	public Component getComponent()
	{
		return monitor.getComponent();
	}

}
