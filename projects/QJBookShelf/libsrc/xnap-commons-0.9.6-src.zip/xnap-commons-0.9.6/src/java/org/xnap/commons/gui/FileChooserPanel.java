/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.io.File;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JTextField;
import org.xnap.commons.gui.action.AbstractXNapAction;
import org.xnap.commons.gui.completion.Completion;
import org.xnap.commons.gui.completion.FileCompletionModel;
import org.xnap.commons.gui.dnd.DefaultTextFieldFileTransferHandler;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * Provides a panel with a <code>JTextField</code> and a button for file
 * selection.
 * 
 * @author Steffen Pingel
 * @author Felix Berger
 */
public class FileChooserPanel extends JPanel 
{
    private static I18n i18n = I18nFactory.getI18n(FileChooserPanel.class);
	
    private JTextField filenameTextField;
	private FileChooserAction fileChooserAction;
	private Component dialogParent = this;
	private Completion completion;
	private JFileChooser chooser;
	
	/**
	 * Constructs a file chooser panel with an initial text.
	 * 
	 * @param file the filename to display  
	 * can be <code>null</code>
	 * @param columns the number of columns for calculating the preferred 
	 * width of the text field, can be 0
	 * @see #setFile(File)
	 */
	public FileChooserPanel(File file, int columns) {
		setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));

		filenameTextField = new JTextField(columns);
		filenameTextField.setMaximumSize
			(new Dimension(Integer.MAX_VALUE,
						   filenameTextField.getPreferredSize().height));
		DefaultTextFieldFileTransferHandler.install(filenameTextField);
		add(filenameTextField);

		completion = Builder.addCompletion(filenameTextField, 
										   new FileCompletionModel());
		
		add(Box.createHorizontalStrut(4));

		fileChooserAction = new FileChooserAction();
		add(Builder.createIconButton(fileChooserAction));
		setFile(file);
    }

	/**
	 * Constructs a file chooser panel.
	 * @param columns the number of columns for calculating the preferred 
	 * width of the text field, can be 0
	 */
	public FileChooserPanel(int columns) {
		this(null, columns);
	}

    /**
     * Sub classes can overwrite this.
     */
    protected void fileSelected(File file)
    {
    }

    /**
     * Returns a file having the path name of the currently set text in the
     * text field.
     * @return the returned file does not necessarily have to exist; null, 
     * if no file was entered
     */
    public File getFile()
    {
		return (filenameTextField.getText().length() != 0)
				? new File(filenameTextField.getText())
				: null;
    }

    /**
     * Returns the file chooser that is used to select the file.
     * @return the file chooser; never returns null
     */
	public JFileChooser getFileChooser()
	{
		if (chooser == null) {
			chooser = new JFileChooser();
			// TODO has no effect since we use showSaveDialog
			chooser.setApproveButtonText(i18n.tr("OK"));
			chooser.setDialogTitle(i18n.tr("Choose File"));
		}
		return chooser;
	}
    
    /**
     * Sets the text in the text field to the absolute path of <code>file</code>.
     * 
     * @param file can be <code>null</code> the text field is cleared then.
     */
    public void setFile(File file)
    {
		filenameTextField.setText(file != null ? file.getAbsolutePath() : "");
    }

    /**
     * Sets the file chooser to use that is used by the file chooser action. 
     * @param chooser the file chooser; if null, a default file chooser will be 
     * created when the action is performed
     */
    public void setFileChooser(JFileChooser chooser)
    {
    	this.chooser = chooser;
    }
    
    /**
     * Returns the text that is currently set in the text field of the chooser
     * panel.
     * 
     * <p>Use {@link #getFile()}.
     *      
     * @deprecated
     */
    public String getFilename()
    {
		return filenameTextField.getText();
    }

    /**
     * Sets the text in the text field.
     * 
     * <p>Use {@link #setFile(File)}.
     * 
     * @param filename the text
     * @deprecated
     */
    public void setFilename(String filename)
    {
		filenameTextField.setText(filename);
    }

    /**
     * Returns the text field used internally.
     */
    public JTextField getTextField()
    {
		return filenameTextField;
    }
    
    /**
     * Returns the completion object associated with the file text field.
     * <p>
     * Thus, you can {@link Completion#setEnabled(boolean) disable} 
     * completion or 
     * {@link org.xnap.commons.settings.CompletionModeSetting save}
     *  the used completion mode in a setting. 
     */
    public Completion getCompletion()
    {
    	return completion;
    }
	
	public Action getFileChooserAction() 
	{
		return fileChooserAction;
	}

	/**
	 * Returns the parent of the file chooser dialog.
	 * 
	 * @return the parent of the file chooser dialog
	 */
	public Component getDialogParent() 
	{
		return dialogParent;
	}
	
	/**
	 * Enables/disables this component and all of its subcomponents.
	 */
	public void setEnabled(boolean enabled) 
	{
		super.setEnabled(enabled);
		getTextField().setEnabled(enabled);
		getFileChooserAction().setEnabled(enabled);
	}

	/**
	 * Sets the parent of the file chooser dialog that is used internally.
	 * <p>
	 * See {@link JFileChooser#showDialog(java.awt.Component, java.lang.String)}
	 * for details on dialog parents.
	 */
	public void setDialogParent(Component dialogParent)
	{
		this.dialogParent = dialogParent;
	}
	
	/**
	 * The default implementation shows a {@link JFileChooser}.
	 * <p>
	 * This method can be overriden in a subclass, so other file choosers
	 * can be provided
	 * @return <code>true</code> if a file was successfully selected and
	 * set using {@link #setFile(File)}, <code>false</code> otherwise
	 */
	protected boolean showChooser()
	{
		getFileChooser().setSelectedFile(getFile());
		if (getFileChooser().showSaveDialog(getDialogParent()) 
				== JFileChooser.APPROVE_OPTION) {
			File file = chooser.getSelectedFile();
			setFile(file);
			return true;
		}
		return false;
	}

    private class FileChooserAction extends AbstractXNapAction 
    {
	
        public FileChooserAction() 
		{
			putValue(ICON_FILENAME, "fileopen.png");
            putValue(SHORT_DESCRIPTION, i18n.tr("Choose a file") );
		}

        public void actionPerformed(ActionEvent event) 
		{
			if (showChooser()) {
				fileSelected(getFile());
			}
		}
    }

}
