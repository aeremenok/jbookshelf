/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import javax.swing.SwingUtilities;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

/**
 * This mode mimics KDE's short automatic completion mode. 
 * 
 * While typing possible unique completions are inserted into the text
 * component after the cursor and set selected, so the user can type over
 * them in case they are not wished for.
 * 
 * @author Felix Berger
 */
public class ShortAutomaticCompletionMode extends AbstractCompletionMode
{
	
	private DocumentListener docListener = new DocumentHandler();

	protected void complete(String prefix)
	{
		String comp = getModel().completeUniquePrefix(prefix);
		// only complete if it's really a completion
		if (comp.length() > prefix.length()) {
			setText(comp, comp.length(), prefix.length());
		}
	}

	public void disable()
	{
		getTextComponent().getDocument().removeDocumentListener(docListener);
	}

	protected void enable()
	{
		getTextComponent().getDocument().addDocumentListener(docListener);
	}

	private class DocumentHandler implements DocumentListener
	{

		public void insertUpdate(DocumentEvent e)
		{
			if (e.getLength() == 1) {
				final String text = getText();
				Runnable r = new Runnable()
				{

					public void run()
					{
						complete(text);
					}
				};
				SwingUtilities.invokeLater(r);
			}
		}

		/*
		 * @see javax.swing.event.DocumentListener#removeUpdate(javax.swing.event.DocumentEvent)
		 */
		public void removeUpdate(DocumentEvent e)
		{
		}

		/*
		 * @see javax.swing.event.DocumentListener#changedUpdate(javax.swing.event.DocumentEvent)
		 */
		public void changedUpdate(DocumentEvent e)
		{
		}
	}
}