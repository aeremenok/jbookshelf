/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.util;

/**
 * Represents the progress of a transfer.
 */
public class Progress implements Comparable
{

    private long rate;
    private long size;
    private long transferred;

    /**
     * 
     * @param size
     * @param transferred
     * 
     * @throws IllegalArgumentException if transferred is greater then size
     */
    public Progress(long size, long transferred)
    {
    	if (transferred > size) {
    		throw new IllegalArgumentException("transferred must not be greater than size");
    	}
		this.size = size;
		this.transferred = transferred;
    }

    public Progress()
    {
		this(-1, -1);
    }

    /**
     * Use a higher precission to make a difference between 0 progress and 0.5. 
     */
    public int compareTo(Object o)
    {
		return (int)(getPercent() - ((Progress)o).getPercent());
    }

    public double getPercent()
    {
		return (size <= 0 || transferred <= 0) 
			? 0 : ((double)(transferred * 100) / size);
    }
    /**
     * Returns the current rate.
     */
    public long getRate()
    {
		return rate;
    }

    public void setRate(long rate)
    {
		this.rate = rate;
    }

    public long getSize()
    {
		return size;
    }

    public long getTransferred()
    {
		return transferred;
    }

}
