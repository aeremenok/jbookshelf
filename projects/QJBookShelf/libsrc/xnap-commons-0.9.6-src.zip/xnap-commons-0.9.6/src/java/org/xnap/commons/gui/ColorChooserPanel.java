/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.util.Hashtable;
import java.util.Map;
import javax.swing.Action;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.Icon;
import javax.swing.JColorChooser;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.JPanel;
import org.xnap.commons.gui.action.AbstractXNapAction;
import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;

/**
 * Provides a panel that displays a {@link JComboBox} with predefined colors and
 * a button that can launch a {@link JColorChooser}.
 * 
 * @author Steffen Pingel
 */
public class ColorChooserPanel extends JPanel {

	private static final I18n i18n = I18nFactory.getI18n(ColorChooserPanel.class);
	
	private Color customColor = new Color(254, 254, 254);
	private JComboBox colorComboBox;
	private Map<Color, String> namesByColor = new Hashtable<Color, String>();
	private ColorChooserAction colorAction;
	private Component dialogParent;
	
	/**
	 * Creates a panel with a list of default colors and selects the specified
	 * color.
	 * 
	 * @param selectedColor the color to select
	 */
	public ColorChooserPanel(Color selectedColor)
	{
		initialize();
		
		setSelectedColor(selectedColor);
	}

	/**
	 * Creates a panel with a list of default colors.
	 */
	public ColorChooserPanel()
	{
		initialize();
	}

	private void initialize()
	{
		setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));
		colorComboBox = new JComboBox();
		colorComboBox.setRenderer(new ColorCellRenderer());
		add(colorComboBox);
		add(Box.createHorizontalStrut(4));
			
		namesByColor.put(Color.black, i18n.tr("Black"));
		namesByColor.put(Color.darkGray, i18n.tr("DarkGray"));
		namesByColor.put(Color.gray, i18n.tr("Gray"));
		namesByColor.put(Color.lightGray, i18n.tr("LightGray"));
		namesByColor.put(Color.blue, i18n.tr("Blue"));
		namesByColor.put(Color.cyan, i18n.tr("Cyan"));
		namesByColor.put(Color.magenta, i18n.tr("Magenta"));
		namesByColor.put(Color.pink, i18n.tr("Pink"));
		namesByColor.put(Color.red, i18n.tr("Red"));
		namesByColor.put(Color.orange, i18n.tr("Orange"));
		namesByColor.put(Color.green, i18n.tr("Green"));
		namesByColor.put(Color.yellow, i18n.tr("Yellow"));
		namesByColor.put(Color.white, i18n.tr("White"));
	
		for (Color color : namesByColor.keySet()) {
			colorComboBox.addItem(color);
		}
		
		colorComboBox.addItem(customColor);
		colorAction = new ColorChooserAction();
		add(Builder.createIconButton(colorAction));
	}

	/**
	 * Returns the currently selected color.
	 * 
	 * @return the selected color
	 */
	public Color getSelectedColor()
	{
		return (Color)colorComboBox.getSelectedItem();
	}

	/**
	 * Selects the specified color in the list.
	 * 
	 * @param newValue the color to select; must not be null
	 * @throws if newValue == null
	 */
	public void setSelectedColor(Color newValue)
	{
		if (newValue == null) {
			throw new IllegalArgumentException();
		}
		
		if (namesByColor.get(newValue) != null) {
			colorComboBox.setSelectedItem(newValue);
		}
		else {
			colorComboBox.removeItem(customColor);
			customColor = newValue;
			colorComboBox.addItem(customColor);
			colorComboBox.setSelectedItem(customColor);
		}
	}

	/**
	 * Returns the parent of the file chooser dialog.
	 * 
	 * @return the parent of the file chooser dialog
	 */
	public Component getDialogParent() 
	{
		return dialogParent;
	}

	/**
	 * Sets the parent of the color chooser dialog that is used internally.
	 * <p>
	 * See {@link JColorChooser#showDialog(java.awt.Component, java.lang.String, java.awt.Color)}
	 * for details on dialog parents.
	 */
	public void setDialogParent(Component dialogParent)
	{
		this.dialogParent = dialogParent;
	}

	protected class ColorChooserAction extends AbstractXNapAction {

		public ColorChooserAction()
		{
			putValue(Action.SHORT_DESCRIPTION, 
					i18n.tr("Opens color selection dialog"));
			putValue(ICON_FILENAME, "palette_color.png");
		}

		public void actionPerformed(ActionEvent event)
		{
			Color c = JColorChooser.showDialog(getDialogParent(), 
					i18n.tr("Choose color"), getSelectedColor());
			if (c != null) {
				setSelectedColor(c);
			}
		}
	}

	protected class ColorCellRenderer extends DefaultListCellRenderer {

		public ColorIcon icon = new ColorIcon(Color.white);

		public Component getListCellRendererComponent(JList list, Object val,
				int idx, boolean isSel, boolean hasFocus)
		{
			super.getListCellRendererComponent(list, val, idx, isSel, hasFocus);
			String colorName = (String)namesByColor.get(val);
			if (colorName == null) {
				colorName = i18n.tr("Custom");
			}
			setText(colorName);
			icon.setColor((Color)val);
			setIcon(icon);
			return this;
		}
	}

	protected class ColorIcon implements Icon {

		private int height = 15;
		private int width = 15;
		private Color color;

		public ColorIcon(Color color)
		{
			this.color = color;
		}

		public int getIconHeight()
		{
			return height;
		}

		public int getIconWidth()
		{
			return width;
		}

		public void setColor(Color newValue)
		{
			this.color = newValue;
		}

		public void paintIcon(Component c, Graphics g, int x, int y)
		{
			g.setColor(Color.black);
			g.drawRect(x, y, width, height);
			g.setColor(color);
			g.fillRect(x + 1, y + 1, width - 1, height - 1);
		}
	}
}
