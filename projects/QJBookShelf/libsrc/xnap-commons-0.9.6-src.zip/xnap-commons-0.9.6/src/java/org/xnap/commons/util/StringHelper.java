/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.util;

import java.io.UnsupportedEncodingException;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

/**
 * Provides a set of static methods that help with string parsing and modifying.
 */
public class StringHelper {

    public static final String[] SIZES = { "B", "KB", "MB", "GB", "TB" };
	
    public static final String ALPHABET_LOWER = "abcdefghijklmnopqrstuvwxyz";
    public static final String ALPHABET_UPPER = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    public static final String NUMBERS_INT = "0123456789";
    public static final String NUMBERS_DECIMAL = NUMBERS_INT + ".";
    public static final String MONEY_USD = "$" + NUMBERS_DECIMAL;
    public static final String ALPHA_NUM 
		= ALPHABET_LOWER + ALPHABET_UPPER + NUMBERS_INT;
    public static final String EMAIL = ALPHA_NUM + ".@_-";
    public static final String HOST = ALPHA_NUM + ".";
    public static final String REGULAR_STRING 
		= EMAIL + "[]?$%/\\(){}?????+-*,;.<>|_^?~#";
    public static final String ANYTHING = null;

    /**
     * Splits <code>text</code> at the first occurence of <code>separator</code>
     * and returns the left part, excluding the separator. 
     *
     * @param text the haystack
     * @param separator the needle
     * @return the empty string, if no occurence can be found
     */
    public static String firstToken(String text, String separator) 
    {
    	if (separator == null) {
    		throw new IllegalArgumentException("Separator must not be null");
    	}
    	if (separator.length() == 0) {
    		throw new IllegalArgumentException("Separator must not be empty");
    	}
    	
		int i = text.indexOf(separator);
		return (i == -1) ? text : text.substring(0, i);
    }

    /**
     * Returns the index of the first digit in <code>s</code>.
     *
     * @return -1, if <code>s</code> does not contain digits; the index of
     *         the first digit, otherwise
     * @see java.lang.String#indexOf(String)
     */
    public static int indexOfDigit(String s)
    {
		for (int i = 0; i < s.length(); i++) {
			if (Character.isDigit(s.charAt(i))) {
				return i;
			}
		}
	    
		return -1;
    }

    /**
     * Splits <code>text</code> at the last occurence of <code>separator</code>
     * and returns the left part, excluding the separator.
     *
     * @param text the haystack
     * @param separator the needle
     * @return the empty string, if no occurence can be found
     */
    public static String lastPrefix(String text, String separator) 
    {
    	if (separator == null) {
    		throw new IllegalArgumentException("Separator must not be null");
    	}
    	if (separator.length() == 0) {
    		throw new IllegalArgumentException("Separator must not be empty");
    	}

    	int i = text.lastIndexOf(separator);
		return (i == -1) ? text : text.substring(0, i);
    }

    /**
     * Splits <code>text</code> at the last occurence of <code>separator</code>
     * and returns the right part, excluding the separator. 
     *
     * @param text the haystack
     * @param separator the needle
     * @return the empty string, if no occurence can be found
     */
    public static String lastToken(String text, String separator) 
    {
    	if (separator == null) {
    		throw new IllegalArgumentException("Separator must not be null");
    	}
    	if (separator.length() == 0) {
    		throw new IllegalArgumentException("Separator must not be empty");
    	}
    	
		int i = text.lastIndexOf(separator);
		if (i < 0 || i == text.length() - 1) {
			return "";
		}
		else {
			return text.substring(i + separator.length(), text.length());
		}
    }

    /**
     * Returns a random lower case letter-only string with <code>length</code>
     * characters.
     */
    public static String randomString(int length) 
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sb.append((char)Math.round(Math.random() * 25 + 97));
        }

        return sb.toString();
    }

    /**
     * Replaces all occurences of <code>oldChars</code> in <code>s</code> by
     * <code>newChars</code>.
     *
     * @return the modified instance of <code>s</code>
     */
    public static String replaceAll(String s, String oldChars, String newChars)
    {
		StringBuilder sb = new StringBuilder();
		int i = 0;
		while (true) {
			int j = s.indexOf(oldChars, i);
			if (j != -1) {
				sb.append(s.substring(i, j));
				sb.append(newChars);
				i = j + oldChars.length();
			}
			else {
				sb.append(s.substring(i));
				break;
			}
		}
		return sb.toString();
    }

    /**
     * Removes all characters from <code>s</code> that are not letters. 
     * Returns a new String which can be for instance used as search text.
     *
     * @return a stripped instance of s
     */
    public static String stripExtra(String s)
    {
		StringBuilder sb = new StringBuilder();
		boolean newWord = false;
		char[] chars = s.toCharArray();
		for (int i = 0; i < chars.length; i++) {
			if (Character.isLetter(chars[i])) {
				if (newWord) {
					sb.append(" ");
					newWord = false;
				}
				sb.append(chars[i]);
			}
			else {
				newWord = true;
			}
		}

		return sb.toString();
    }

    /**
     * Uses a <code>StringTokenizer</code> to split <code>value</code>.
     * @see java.util.StringTokenizer
     * @param value the String to split
     * @param separators the separators
     * @return the tokens
     */
    public static String[] toArray(String value, String separators)
    {
		StringTokenizer st = new StringTokenizer(value, separators);
		String[] array = new String[st.countTokens()];
		for (int i = 0; i < array.length; i++) {
			array[i] = st.nextToken();
		}
		return array;
    }

    /**
     * Returns a new <code>String</code> that has the first letter of value
     * set to upper case.
     */
    public static String toFirstUpper(String value)
    {
		if (value.length() > 1) {
			return Character.toUpperCase(value.charAt(0)) + value.substring(1);
		}
		else {
			return value.toUpperCase();
		}
    }

    public static int[] toIntArray(String value, String separators)
    {
		StringTokenizer st = new StringTokenizer(value, separators);
		int[] array = new int[st.countTokens()];
		for (int i = 0; i < array.length; i++) {
			try {
				array[i] = Integer.parseInt(st.nextToken());
			}
			catch (NumberFormatException e) {
			}
		}
		return array;
    }

    public static List<String> toList(String value, String separators)
    {
		StringTokenizer st = new StringTokenizer(value, separators);
		LinkedList<String> list = new LinkedList<String>();
	
		while (st.hasMoreTokens()) {
			list.add(st.nextToken());
		}
		return list;
    }

	/**
	 * Tries to autodect encoding.
	 */
	public static String toString(byte[] data)
	{
		try {
			return new String(data, "UTF-8");
		}
		catch (UnsupportedEncodingException e) {
			e.printStackTrace(System.err);
		}

		try {
			return new String(data, "ISO-8859-1");
		}
		catch (UnsupportedEncodingException e) {
			e.printStackTrace(System.err);
		}

		return new String(data);
	}

    public static String toString(Collection c, String separator)
    {
		StringBuilder sb = new StringBuilder();
		for (Iterator i = c.iterator(); i.hasNext();) {
			sb.append(i.next().toString());
			sb.append(separator);
		}
		return sb.toString();
    }

    public static String toString(int[] array, String separator)
    {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < array.length; i++) {
			sb.append(array[i]);
			sb.append(separator);
		}
		return sb.toString();
    }

    public static String toString(String[] array, String separator)
    {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < array.length; i++) {
			sb.append(array[i]);
			sb.append(separator);
		}
		return sb.toString();
    }

    /**
     * Returns <code>value</code> (byte) formatted as a file size.
     * For example value=2048 returns "2 kb".
     * 
     * @param size filesize to be formatted
     * @return formatted number as string
     */
    public static String formatSize(long size)
    {
		int i = 0;
		for (; i < SIZES.length - 1 && size >= 1024; i++) {
			size /= 1024;
		}

		return String.format("%,d %s", size, SIZES[i]);
    }

    /**
     * Formats number of seconds in appropriate time unit
     *
     * @param i number of seconds
     * @return formatted duration as string
     */
    public static String formatLength(long i)
    {
		StringBuilder sb = new StringBuilder();
	
		long x = (i / 3600);
		if (x > 0) {
			sb.append(x);
			sb.append(":");
		}
		x = (i % 3600) / 60;
		if (x < 10) {
			sb.append("0");
		}
		sb.append(x);
		sb.append(":");
		x = (i % 60);
		if (x < 10) {
			sb.append("0");
		}
		sb.append(x);

		return sb.toString();
    }

	/**
	 * Prepends and appends <code>padding</code> whitespaces to text and 
	 * returns the result.
	 * @param text the text
	 * @param padding the number of spaces to prepend and append
	 * @return the padded text, lenght will be text.length() + 2 * padding
	 * @throws IllegalArgumentException if <code>padding</code> < 0
	 */
	public static final String pad(String text, int padding)
	{
		if (padding < 0) {
			throw new IllegalArgumentException();
		}
		if (padding == 0) {
			return text;
		}
		StringBuilder sb = new StringBuilder(text.length() + padding * 2);
		append(sb, " ", padding);
		sb.append(text);
		append(sb, " ", padding);
		return sb.toString();
	}

	/**
	 * Prepends <code>lpadding</code> and appends <code>rpadding</code> 
	 * whitespaces to text and returns the result.
	 * 
	 * @return the padded text, lenght will be text.length() + lpadding + rpadding
	 * @param text the text
	 * @param lpadding the number of spaces to prepend
	 * @param rpadding the number of spaces to append
	 * @throws IllegalArgumentException if <code>lpadding</code> < 0 or
	 * <code>rpadding</code> < 0
	 */
	public static final String pad(String text, int lpadding, int rpadding)
	{
		if (lpadding < 0) {
			throw new IllegalArgumentException();
		}
		if (rpadding < 0) {
			throw new IllegalArgumentException();
		}
		if (lpadding == 0 && rpadding == 0) {
			return text;
		}
		StringBuilder sb = new StringBuilder(text.length() + lpadding + rpadding);
		append(sb, " ", lpadding);
		sb.append(text);
		append(sb, " ", rpadding);
		return sb.toString();
	}
	
	/**
	 * Appends <code>text</text> to <code>sb</code> <code>count</code> times.
	 * @param sb the buffer the text is appended to
	 * @param text the text
	 * @param count the number of times text is appenden to buffer
	 */
	private static final void append(StringBuilder sb, String text, int count)
    {
		for (int i = 0; i < count; i++) {
			sb.append(text);
		}
    }
	
	/**
	 * Appends <code>text</text> to <code>sb</code> <code>count</code> times.
	 * @param sb the buffer the text is appended to
	 * @param text the text
	 * @param count the number of times text is appenden to buffer
	 */
	public static final void append(StringBuffer sb, String text, int count)
    {
		for (int i = 0; i < count; i++) {
			sb.append(text);
		}
    }

}
