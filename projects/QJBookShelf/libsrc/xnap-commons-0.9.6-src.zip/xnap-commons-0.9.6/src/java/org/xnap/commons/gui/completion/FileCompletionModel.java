/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import java.io.File;
import java.io.FileFilter;
import javax.swing.DefaultComboBoxModel;
import org.xnap.commons.util.FileHelper;

/**
 * This class provides completion for path prefixes on the local file system.
 */
public class FileCompletionModel extends DefaultComboBoxModel 
	implements CompletionModel
{
	private boolean completeOnlyDirectories = false;

	private boolean completeHiddenFiles = false;
	
	private FileFilter dirFilter = new DirectoryFileFilter();

	/**
	 * Constructs a new file completion model.
	 *
	 * @param completeOnlyDirectories if true only subdirectories are
	 * suggested as possible completions, otherwise files are taken into
	 * account too 
	 */
    public FileCompletionModel(boolean completeOnlyDirectories)
	{
		this.completeOnlyDirectories = completeOnlyDirectories;
	}

	/**
	 * Constructs a new file completion model.
	 *
	 * The default setting is to complete subdirectories and files.
	 */
	public FileCompletionModel()
	{
		this(false);
	}

	/**
	 * Set whether hidden files should be suggested as possible completions.
	 * <p>
	 * The default behavior is they are not suggested.
	 */
	public void setCompleteHiddenFiles(boolean complete) 
	{
		completeHiddenFiles = complete;
	}
	
	/**
	 * Set whether only directories should be suggested as possible completions.
	 * <p>
	 * The default behavior is files and directories are suggested.
	 */
	public void setCompleteDirectoriesOnly(boolean complete)
	{
		completeOnlyDirectories = complete;
	}
	
	/**
	 * Returns true if there are files in the local file system having the
	 * given prefix.
	 *
	 * First we test if the given prefix denotes a file which exists and is a
	 * directory. If that is the case all the files contained in that
	 * directory are added to the model.
	 * 
	 * Regardless of the above results the parent directory, if there is, one is
	 * searched for files matching the prefix. Thus we get all possible
	 * completions that make sense.
	 */
	public boolean complete(String prefix)
	{
		removeAllElements();

		File file = new File(prefix);
		if (file.exists() && file.isDirectory()) {
			File[] files = file.listFiles(dirFilter);
			for (int i = 0; files != null && i < files.length; i++) {
				addElement(files[i].getAbsolutePath());
			}
		}
		/* look for files in the parent directory having file.getName() as
           prefix.  */
		File parent = file.getParentFile();
		/* else */ if (parent != null) {
			File[] files = parent.listFiles(new PrefixFileFilter(file.getName()));
			for (int i = 0; files != null && i < files.length; i++) {
				addElement(files[i].getAbsolutePath());
			}
		}
		return getSize() > 0;
	}

	/**
	 * This method's behaviour is a matter of taste.
	 *
	 * It first checks if the given prefix is an existing directory. If that
	 * is the case the commmon unique prefix of all files found in the
	 * directory is returned.
	 *
	 * Only if the above fails the parent directory is searched for the common
	 * unique prefix.
	 */
	public String completeUniquePrefix(String prefix)
	{
		File file = new File(prefix);
		if (file.exists() && file.isDirectory()) {
			File[] files = file.listFiles(dirFilter);
			StringBuilder sb = new StringBuilder
				(FileHelper.appendSeparator(file.getAbsolutePath()));
			for (int i = 0; matches(files, i); i++) {
				sb.append(files[0].getName().charAt(i));
			}
			return sb.toString();
		}
		else if (file.getParentFile() != null) {
			File[] files = file.getParentFile().listFiles
				(new PrefixFileFilter(file.getName()));
			StringBuilder sb = new StringBuilder
				(FileHelper.appendSeparator
				 (file.getParentFile().getAbsolutePath()));
			for (int i = 0; matches(files, i); i++) {
				sb.append(files[0].getName().charAt(i));
			}
			return sb.toString();
		}
		return prefix;
	}

	/**
	 * Returns true if all files in the given array have the same character at
	 * position <code>index</code>.
	 *
	 * @param files the array of files, can be null or empty
	 * @param index the position in the filenames that is tested for equality
	 * @return false if the array is null or empty, true if all filenames of
	 * the files in the array have the same character at position
	 * <code>index</code> 
	 */
	private boolean matches(File[] files, int index)
	{
		if (files == null || files.length == 0) {
			return false;
		}
		if (files.length == 1) {
			return index < files[0].getName().length();
		}
		for (int i = 0; i < files.length - 1; i++) {
			if (files[i].getName().length() == index 
				|| files[i+1].getName().length() == index) {
				return false;
			}
			else if (files[i].getName().charAt(index) 
					 != files[i+1].getName().charAt(index)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * This class checks in its {@link DirectoryFileFilter#accept(File)}
	 * method if the given file is a directory in case the constructor {@link
	 * FileCompletionModel#FileCompletionModel(boolean)
	 * FileCompletionModel(true)} was used.
	 */
	private class DirectoryFileFilter implements FileFilter
	{
		public boolean accept(File pathname)
		{
			return (!completeOnlyDirectories || pathname.isDirectory())
			 && (completeHiddenFiles || !pathname.isHidden());
		}
	}

	private class PrefixFileFilter extends DirectoryFileFilter
	{
		private String prefix;

		public PrefixFileFilter(String prefix)
		{
			this.prefix = prefix;
		}

		public boolean accept(File pathname)
		{
			return super.accept(pathname)
				&& pathname.getName().startsWith(prefix);
		} 
	}
}
