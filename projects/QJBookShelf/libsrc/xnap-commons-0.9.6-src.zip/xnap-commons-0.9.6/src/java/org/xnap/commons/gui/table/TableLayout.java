/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.table;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.InputEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.TableColumnModelEvent;
import javax.swing.event.TableColumnModelListener;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.tree.TreePath;
import org.xnap.commons.gui.table.SortableModel.Order;
import org.xnap.commons.gui.util.GUIHelper;

/**
 * TODO update documentation
 * TODO squig don't make TableSorter a requirement, maybe have a general
 * table layout and a more specific SortableTableLayout subclass?
 * TableHeaderHandler class handles the mouse events invoked by clicking on the
 * header portion of the JTable.
 * TODO setter for maintain sort order
 * TODO call stopCellEditing() whenever neccessary
 */
public class TableLayout {

	private List<TableColumn> columns;
	private EventHandler eventHandler;
	private Enumeration expandedLeafs;
	private JTableHeader header;
	private JPopupMenu headerPopupMenu;
	private List<TableLayoutListener> listeners = new ArrayList<TableLayoutListener>();
	private SortButtonRenderer renderer;
	private TreePath[] selectedPaths;
	private TableSorter sorter;
	/**
	 * Set to true, when the user has pressed a button but not yet dragged it.
	 */
	private boolean sorting = false;
	private JTable table;
	private JTree tree;
	
	public TableLayout(JTable table) {
		this(table, (TableSorter)table.getModel());
	}

	/**
	 * 
	 */
	public TableLayout(JTable table, TableSorter sorter)
	{
		this.table = table;
		this.header = table.getTableHeader();
		this.sorter = sorter;
		this.eventHandler = new EventHandler();
		
		TableColumnModel columnModel = table.getColumnModel();
		columns = new ArrayList<TableColumn>(columnModel.getColumnCount());
		for (int i = 0; i < columnModel.getColumnCount(); i++) {
			addColumn(columnModel.getColumn(i));
		}
		columnModel.addColumnModelListener(eventHandler);
		headerPopupMenu = new TableHeaderMenu(null, this).getPopupMenu();
		renderer = new SortButtonRenderer(header.getDefaultRenderer());
		header.setDefaultRenderer(renderer);
		header.setReorderingAllowed(true);
		header.setResizingAllowed(true);
		header.addMouseListener(eventHandler);
		header.addMouseMotionListener(eventHandler);
	}

	private void addColumn(TableColumn column) {
		column.addPropertyChangeListener(eventHandler);
		columns.add(column);
	}
	
	public void addTableLayoutListener(TableLayoutListener l) {
		listeners.add(l);
	}

	// TODO raise visiblity to protected
	private void fireColumnNameChanged(int index, String newName)
	{
		TableLayoutListener[] array = listeners.toArray(new TableLayoutListener[0]);
		for (TableLayoutListener listener : array) {
			listener.columnNameChanged(index, newName);
		}
	}

	private void fireColumnOrderChanged()
	{
		TableLayoutListener[] array = listeners.toArray(new TableLayoutListener[0]);
		for (TableLayoutListener listener : array) {
			listener.columnOrderChanged();
		}
	}

	private void fireColumnVisibilityChanged(int index, boolean visible)
	{
		TableLayoutListener[] array = listeners.toArray(new TableLayoutListener[0]);
		for (TableLayoutListener listener : array) {
			listener.columnVisibilityChanged(index, visible);
		}
	}

	private void fireColumnWidthsChanged()
	{
		TableLayoutListener[] array = listeners.toArray(new TableLayoutListener[0]);
		for (TableLayoutListener listener : array) {
			listener.columnLayoutChanged();
		}
	}

	private void fireSortedColumnChanged(int col)
	{
		TableLayoutListener[] array = listeners.toArray(new TableLayoutListener[0]);
		for (TableLayoutListener listener : array) {
			listener.sortedColumnChanged();
		}
	}

	public TableColumn getColumnAt(int index)
	{
		return columns.get(index);
	}

	public int getColumnCount()
	{
		return columns.size();
	}
	
	public int getColumnIndex(String identifier)
	{
		for (int i = 0; i < columns.size(); i++) {
			if (getColumnAt(i).getIdentifier().equals(identifier)) {
				return i;
			}
		}
		return -1;
	}

	public Iterator<TableColumn> getColumns()
	{
		return columns.iterator();
	}

	public boolean getMaintainSortOrder()
	{
		return sorter.getMaintainSortOrder();
	}

	public int getSortedColumn()
	{
		return sorter.getSortedColumn();
	}
	
	public JTable getTable()
	{
		return table;
	}

	public JPopupMenu getHeaderPopupMenu()
	{
		return headerPopupMenu;
	}
	
	public int getVisibleColumnsCount()
	{
		return table.getColumnModel().getColumnCount();
	}

	public boolean isColumnVisible(int index)
	{
		TableColumn column = getColumnAt(index);
		TableColumnModel columnModel = table.getColumnModel();
		for (int i = 0; i < columnModel.getColumnCount(); i++) {
			if (columnModel.getColumn(i) == column) {
				return true;
			}
		}		
		return false;
	}

	public Order getSortOrder()
	{
		return sorter.getSortOrder();
	}

	public void removeTableLayoutListener(TableLayoutListener l) {
		listeners.remove(l);
	}

	public void restoreSelections()
	{
		if (tree != null) {
			if (expandedLeafs != null) {
				while (expandedLeafs.hasMoreElements()) {
					TreePath path = (TreePath)expandedLeafs.nextElement();
					tree.expandPath(path);
				}
			}
			if (selectedPaths != null) {
				tree.addSelectionPaths(selectedPaths);
			}
		}
	}
	
	public void setAllColumnsVisible(boolean visible)
	{
		for (int i = 0; i < getColumnCount(); i++) {
			setColumnVisible(i, visible);
		}
	}

	/**
	 * Sets the auto resize mode of the table depending on a modifier key.
	 */
	private void setAutoResizeMode(MouseEvent e)
	{
		if ((e.getModifiers() & InputEvent.SHIFT_MASK) != 0) {
			table.setAutoResizeMode(JTable.AUTO_RESIZE_NEXT_COLUMN);
		}
		else if ((e.getModifiers() & InputEvent.CTRL_MASK) != 0) {
			table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
		}
		else {
			table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
		}
	}
	
	public void setColumnNames(String[] columnNames)
	{
		if (columns.size() != columnNames.length) {
			throw new IllegalArgumentException("Number of columns and length of columnNames must match");
		}
		
		for (int i = 0; i < columnNames.length; i++) {
			columns.get(i).setHeaderValue(columnNames[i]);
		}
	}

	public void setColumnName(int index, String name)
	{
		TableColumn column = columns.get(index);
		column.setHeaderValue(name);
	}

	public void setColumnProperties(int index, String key)
	{
		TableColumn column = columns.get(index);
		column.setIdentifier(key);
	}

	public void setColumnProperties(int index, String key, int width)
	{
		TableColumn column = columns.get(index);
		column.setIdentifier(key);
		column.setPreferredWidth(width);
		column.setWidth(width);
	}
	
	public void setColumnVisible(int index, boolean visible)
	{
		boolean currentlyVisible = isColumnVisible(index);
		if (currentlyVisible == visible) {
			return;
		}
		
		if (visible) {
			// TODO add the column at a sensible position
			table.getColumnModel().addColumn(getColumnAt(index));
		} else {
			table.getColumnModel().removeColumn(getColumnAt(index));
		}
		fireColumnVisibilityChanged(index, visible);
	}
	
	public void setColumnsVisible(String[] columns)
	{
		setAllColumnsVisible(false);
		for (int i = 0; i < columns.length; i++) {
			int index = getColumnIndex(columns[i]);
			if (index != -1) {
				setColumnVisible(index, true);
			}
		}
	}
	
	public void setMaintainSortOrder(boolean maintainSortOrder)
	{
		sorter.setMaintainSortOrder(maintainSortOrder);
	}
	
	public void setTree(JTree jt)
	{
		this.tree = jt;
	}
	
	/**
	 * Displays the popup menu.
	 */
	public void showPopupMenu(MouseEvent e)
	{
		if (headerPopupMenu != null) {
			header.setDraggedColumn(null);
			header.setResizingColumn(null);
			GUIHelper.showPopupMenu(headerPopupMenu, e.getComponent(),
					e.getX(), e.getY());
		}
	}

	public void sortByColumn(int modelIndex, SortableModel.Order sortOrder, boolean revert) {
		sortByColumn(table.convertColumnIndexToView(modelIndex), modelIndex, sortOrder, revert);
	}

	private void sortByColumn(int column, int modelIndex, SortableModel.Order sortOrder, boolean revert) {
		stopCellEditing();
		storeSelections();
		sortOrder = sorter.sortByColumn(modelIndex, sortOrder, revert);
		renderer.setSortedColumn(column, sortOrder);
		restoreSelections();
	}

	/**
	 * 
	 */
	private void sortByColumnInternal(int column)
	{
		int modelIndex = table.convertColumnIndexToModel(column);
		SortableModel.Order sortOrder;
		if (sorter.getSortedColumn() == modelIndex) {
			// keep old sort order
			sortOrder = sorter.getSortOrder();
		}
		else if (sorter.getColumnClass(modelIndex) == String.class) {
			// sort strings ascending
			sortOrder = SortableModel.Order.ASCENDING;
		}
		else {
			// sort descending by default
			sortOrder = SortableModel.Order.DESCENDING;
		}
		// revert if the same column was resorted
		boolean revert = (sorter.getSortedColumn() == modelIndex);
		sortByColumn(column, modelIndex, sortOrder, revert);
	}

	public void storeSelections()
	{
		if (tree != null) {
			selectedPaths = tree.getSelectionPaths();
			expandedLeafs = tree.getExpandedDescendants(new TreePath(tree
					.getModel().getRoot()));
		}
	}

	public void stopCellEditing()
	{
		if (table.getCellEditor() != null) {
			table.getCellEditor().stopCellEditing();
		}
	}

	/**
	 * Provides a small arrow shaped icon.
	 */
	private static class BevelArrowIcon implements Icon {
		
		public static final int DOWN  = 1;
		public static final int UP    = 0;
		
		private int direction;
		private Color edge1;
		private Color edge2;
		
		public BevelArrowIcon(int direction, boolean isPressedView) 
		{
			this.direction = direction;
			
			if (isPressedView) {
				edge1 = UIManager.getColor("controlDkShadow");
				edge2 = UIManager.getColor("controlLtHighlight");
			} 
			else {
				edge1 = UIManager.getColor("controlShadow");
				edge2 = UIManager.getColor("controlHighlight");
			}
		}
		
		public int getIconHeight() 
		{
			return 7;
		}
		
		public int getIconWidth() 
		{
			return 8;
		}
		
		public void paintIcon(Component c, Graphics g, int x, int y) 
		{
			switch (direction) {
			case DOWN:
				g.setColor(edge2);
				g.drawLine(x + 5, y + 7, x + 8, y);
				g.setColor(edge1);
				g.drawLine(x, y, x + 8, y);
				g.drawLine(x, y, x + 4, y + 7);
				break;
			case UP:
				g.setColor(edge1);
				g.drawLine(x, y + 6, x + 4, y);
				g.setColor(edge2);
				g.drawLine(x, y + 7, x + 8, y + 7);
				g.drawLine(x + 5, y, x + 8, y + 7);
				break;
			}
		}	
		
	}

	protected class EventHandler implements
		MouseListener, MouseMotionListener, TableColumnModelListener, 
		PropertyChangeListener {


		public void columnAdded(TableColumnModelEvent event)
		{
		}

		public void columnMarginChanged(ChangeEvent event)
		{
		}

		public void columnMoved(TableColumnModelEvent event)
		{
			int i = table.convertColumnIndexToView(sorter.getSortedColumn());
			if (i != -1) {
				renderer.setSortedColumn(i, sorter.getSortOrder());
			}
			fireColumnOrderChanged();
		}

		public void columnRemoved(TableColumnModelEvent event)
		{
		}

		public void columnSelectionChanged(ListSelectionEvent event)
		{
		}

		public void mouseClicked(MouseEvent e)
		{
		}

		public void mouseDragged(MouseEvent e)
		{
			if (sorting) {
				// abort sorting
				sorting = false;
				renderer.selectColumn(-1);
				header.repaint();
			}
			setAutoResizeMode(e);
		}

		public void mouseEntered(MouseEvent e)
		{
		}

		public void mouseExited(MouseEvent e)
		{
		}

		public void mouseMoved(MouseEvent e)
		{
		}

		public void mousePressed(MouseEvent e)
		{
			if (e.isPopupTrigger()) {
				showPopupMenu(e);
			}
			else {
				int col = header.columnAtPoint(e.getPoint());
				renderer.selectColumn(col);
				header.repaint();
				sorting = true;
			}
			setAutoResizeMode(e);
		}

		public void mouseReleased(MouseEvent e)
		{
			if (e.isPopupTrigger()) {
				showPopupMenu(e);
			}
			else if (sorting) {
				int col = header.columnAtPoint(e.getPoint());
				if (table.isEditing()) {
					table.getCellEditor().stopCellEditing();
				}
				sortByColumnInternal(col);
				fireSortedColumnChanged(col);
				sorting = false;
				renderer.selectColumn(-1);
				header.repaint();
			}
			else {
				fireColumnWidthsChanged();
			}
		}

		public void propertyChange(PropertyChangeEvent evt)
		{
			if ("headerValue".equals(evt.getPropertyName())) {
				TableColumn column = (TableColumn)evt.getSource();
				fireColumnNameChanged(getColumnIndex(column.getIdentifier().toString()), evt.getNewValue().toString());
			}
		}

	}

	/**
	 * Don't use this class directly. Use 
	 * <code>TableHeaderListener.install()</code> instead.
	 *
	 * <p>If an instance of this class is set as the header renderer for a table, 
	 *
	 * @see xnap.gui.table.TableHeaderListener
	 */
	private static class SortButtonRenderer implements TableCellRenderer
	{
		
		public static final Icon downIcon = new BevelArrowIcon(BevelArrowIcon.DOWN, false);
		public static final Icon upIcon = new BevelArrowIcon(BevelArrowIcon.UP, false);
		
		private Hashtable<Integer, Icon> icons = new Hashtable<Integer, Icon>();
		private JLabel label;
		private TableCellRenderer renderer;
		private int selectedColumn = -1;
		
		/**
		 * Constructs a SortButtonRenderer. The <code>renderer</code> is used
		 * to renderer the header. This needs to be an instance of 
		 * {@link javax.swing.JLabel JLabel} for the sort arrow to be displayed.
		 *
		 * <p>This implementation uses the setIcon() method of JLabel to display 
		 * the arrow icon. Make sure you do not use the icon of the renderer.
		 *
		 * @param renderer the default renderer
		 */
		public SortButtonRenderer(TableCellRenderer renderer)
		{
			this.renderer = renderer;
			if (renderer instanceof JLabel) {
				label = (JLabel)renderer;
				label.setHorizontalTextPosition(SwingUtilities.LEFT);
			}
			else {
				// avoid null pointer exception if cr is not instanceof JLabel
				label = new JLabel();
			}
		}
		
		/**
		 * Returns the icon of col.  
		 */
		public Icon getIcon(int col) 
		{
			return (Icon)icons.get(new Integer(col));
		}
		
		public Component getTableCellRendererComponent(JTable table, Object value,
				boolean isSelected, boolean hasFocus,
				int row, int column) 
		{
			// set the 
			label.setIcon(getIcon(column));
			
			Component c = renderer.getTableCellRendererComponent
			(table, value, isSelected, hasFocus, row, column);
			
			if (column == selectedColumn) {
				label.setBackground(UIManager.getColor("controlShadow"));
			}
			
			return c;
		}
		
		public void selectColumn(int col)
		{
			selectedColumn = col;
		}
		
		/**
		 * Prints the arrow icon to the column at index <code>col</code>.
		 */
		public void setSortedColumn(int col, Order sortOrder) 
		{
			icons.clear();
			if (sortOrder == SortableModel.Order.ASCENDING) {
				icons.put(new Integer(col), downIcon);
			}
			else if (sortOrder == SortableModel.Order.DESCENDING) {
				icons.put(new Integer(col), upIcon);
			}
		}
	}

}
