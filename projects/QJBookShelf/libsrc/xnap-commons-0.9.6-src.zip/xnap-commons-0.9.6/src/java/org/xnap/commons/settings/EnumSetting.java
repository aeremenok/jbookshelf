/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;


/**
 * Provides a setting for String objects.
 */
public class EnumSetting<T extends Enum<T>> extends AbstractSetting<T> {

    private Class<T> clazz;

	public EnumSetting(SettingResource backend, String key, T defaultValue)
    {
    	super(backend, key, defaultValue, null);
		
		if (getDefaultValue() == null) {
			throw new IllegalArgumentException("defaultValue may not be null");
		}
		clazz = defaultValue.getDeclaringClass();
    }
	
	public EnumSetting(SettingResource backend, String key, Class<T> clazz)
	{
		super(backend, key, null, null);
		
		this.clazz = clazz;
	}

	public Class<T> getEnumClass() {
		return clazz;
	}
	
	@Override
	protected T fromString(String value)
	{
		try {
			return T.valueOf(clazz, value);
		} catch (IllegalArgumentException e) {
			return null;
		}
	}

	@Override
	protected String toString(T value)
	{
		return value.name();
	}
}
