/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.settings;

import org.xnap.commons.i18n.I18n;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.util.StringHelper;

/**
 * A string validator. Makes sure all characters of a string are valid and that
 * it has a minimum length.
 */
public class StringValidator implements Validator {

	private static final I18n i18n = I18nFactory.getI18n(StringValidator.class);
	
    /**
     * Convenience validator for email addresses.
     */
    public static final StringValidator EMAIL
		= new StringValidator(StringHelper.EMAIL, 1);

    /**
     * Convenience validator for ordinary strings without whitespaces.
     */
    public static final StringValidator REGULAR_STRING
		= new StringValidator(StringHelper.REGULAR_STRING, 1);

    private String validChars;
    private int minLength;

    /**
     * Constructs a string validator that accepts any String composed of
     * <code>validChars</code> with a minimum length of 
     * <code>minlength</code> characters.
     * 
     * @param validChars the allowed characters
     * @param minLength the minimum length
     */
    public StringValidator(String validChars, int minLength)
    {
		this.validChars = validChars;
		this.minLength = minLength;
    }

    /**
     * Constructs a string validator that accepts any non-null String 
     * composed of <code>validChars</code>.
     * 
     * @param validChars the allowed characters
     */
    public StringValidator(String validChars)
    {
		this(validChars, 0);
    }

    /**
     * Constructs a string validator that accepts any non-null String. 
     */
    public StringValidator()
    {
		this(null);
    }

    public void validate(String value)
    {
		if (value == null) {
			throw new IllegalArgumentException(i18n.tr("Value must not be null"));
		}
		else if (value.length() < minLength) {
			throw new IllegalArgumentException(i18n.tr("Value is too short"));
		}
		else if (validChars != null) {
			for (int i = 0; i < value.length(); i++) {
				if (validChars.indexOf(value.charAt(i)) == -1) {
					throw(new IllegalArgumentException(i18n.tr("Invalid character")));
				}
			}
		}
    }

}
