/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.dnd;

import java.awt.datatransfer.Transferable;
import java.io.File;
import java.util.Collections;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.TransferHandler;


/**
 * Provides a default file transfer handler for {@link JTextField}s.
 * <p>
 * When creating a transferable the text of the textfield is interpreted as the
 * absolute path of the file.
 * <p>
 * When a file is dropped on the text field, the file's absolute path replaces
 * the current text of the text field.
 * <p>
 * Use the static {@link #install(JTextField)} method to install it for a text
 * field.
 * @author Felix Berger
 */
public class DefaultTextFieldFileTransferHandler extends AbstractFileTransferHandler
{
	
	private static TransferHandler handler = new DefaultTextFieldFileTransferHandler();
	
	protected DefaultTextFieldFileTransferHandler()
	{
	}

	/**
	 * Installs the default file transfer handler for this <code>textField</code>
	 * <p>
	 * Does not activate dragging, call 
	 * {@link javax.swing.text.JTextComponent#setDragEnabled(boolean)}
	 * to enable it.
	 * <p>
	 * The transfer handler can be be removed by calling 
	 * {@link JComponent#setTransferHandler(javax.swing.TransferHandler)
	 * textField.setTransferHandler(null)}.
	 * @param textField
	 */
	public static void install(JTextField textField)
	{
		textField.setTransferHandler(handler);
	}
	
	/**
	 * Returns null, if the text field is empty or disabled.
	 */
	@Override
	protected Transferable createTransferable(JComponent c) 
	{
		JTextField textField = (JTextField)c;
		if (textField.isEnabled() && textField.getText().length() > 0) {
			return new FileTransferable(Collections.singletonList(new File(textField.getText())));
		}
		return null;
	}

	/**
	 * Overriden to set the text of the textfield to the absolute path of the 
	 * first file of the list.
	 */
	@Override
	public boolean importFiles(JComponent comp, List<File> files) 
	{
		File file = files.get(0);
		JTextField textField = (JTextField)comp;
		textField.setText(file.getAbsolutePath());
		return true;
	}
	
}