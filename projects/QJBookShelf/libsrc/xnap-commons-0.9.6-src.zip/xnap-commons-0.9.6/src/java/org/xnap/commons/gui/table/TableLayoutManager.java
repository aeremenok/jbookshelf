/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.table;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JMenuItem;
import javax.swing.JTable;
import org.xnap.commons.gui.action.AbstractXNapAction;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.settings.SettingStore;

public class TableLayoutManager {

	private List<ColumnProperties> columnProperties = new ArrayList<ColumnProperties>();
	private int currentIndex = 0;
	private List<String> defaultColumns = new ArrayList<String>();
	private ResetTableLayoutAction resetTableLayoutAction;
	private TableLayout tableLayout;
	
	public TableLayoutManager(JTable table)
	{
		this.tableLayout = new TableLayout(table);
		
		this.resetTableLayoutAction = new ResetTableLayoutAction();
		this.tableLayout.getHeaderPopupMenu().add(new JMenuItem(resetTableLayoutAction));
	}
	
	public void addColumnProperties(String key, String name, int width, boolean defaultColumn)
	{
		ColumnProperties props = new ColumnProperties();
		props.index = currentIndex;
		props.key = key;
		props.name = name;
		props.width = width;
		if (defaultColumn) {
			defaultColumns.add(key);
		}
		columnProperties.add(props);

		currentIndex++;
	}
	
	private String[] getDefaultColumns()
	{
		return defaultColumns.toArray(new String[0]);
	}
	
	public ResetTableLayoutAction getResetTableLayoutAction()
	{
		return resetTableLayoutAction;
	}

	public TableLayout getTableLayout()
	{
		return tableLayout;
	}
	
	public void initializeTableLayout() 
	{
		for (ColumnProperties props : columnProperties) {
			getTableLayout().setColumnProperties(props.index, props.key, props.width);
			getTableLayout().setColumnName(props.index, props.name);
		}
	}
	
	public void resetTableLayout() 
	{
		for (ColumnProperties props : columnProperties) {
			getTableLayout().setColumnProperties(props.index, props.key, props.width);
		}
		
		getTableLayout().setColumnsVisible(getDefaultColumns());	
		getTableLayout().getTable().getTableHeader().revalidate();
	}

	public void restoreLayout(SettingStore store, String key) 
	{
		store.restoreTable(key, getDefaultColumns(), getTableLayout());
	}	

	public void saveLayout(SettingStore store, String key) 
	{
		store.saveTable(key, getTableLayout());
	}

	private static class ColumnProperties {
		boolean defaultColumn;
		int index;
		String key;
		public String name;
		int width;
	}

	private class ResetTableLayoutAction extends AbstractXNapAction {
		
		public ResetTableLayoutAction() 
		{
			putValue(NAME, I18nFactory.getI18n(TableLayoutManager.class).
					tr("Reset Columns"));
		}

		public void actionPerformed(ActionEvent event) 
		{
			resetTableLayout();
		}
		
	}
	
}
