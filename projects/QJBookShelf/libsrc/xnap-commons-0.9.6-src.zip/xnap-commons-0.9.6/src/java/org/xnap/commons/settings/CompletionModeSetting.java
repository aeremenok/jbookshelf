/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

package org.xnap.commons.settings;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xnap.commons.gui.completion.Completion;
import org.xnap.commons.gui.completion.CompletionMode;
import org.xnap.commons.gui.completion.CompletionModeFactory;
import org.xnap.commons.gui.completion.CompletionModeListener;


/**
 * This class manages the serialization of the active completion mode for a 
 * {@link Completion} object.
 * 
 * A CompletionModeSetting can be used as follows:
 * 
 * <pre>
 * JTextField jtf = new JTextField();
 * Completion comp = new Completion(jtf);
 * CompletionModeSetting cms = 
 * new CompletionModeSetting("prefsKey", 
 * 	ManualCompletionMode.class.getName(), comp);
 * </pre>
 * 
 * 
 * 
 * @author Felix Berger
 */
public class CompletionModeSetting extends StringSetting 
	implements CompletionModeListener
{

	private static Log logger = LogFactory.getLog(CompletionModeSetting.class);
	
	private Completion comp;
	
	/**
	 * Creates a CompletionModeSetting for a completion object.
	 * @param key the settings key for the properties file 
	 * @param defaultMode the mode which is initially set for the completion
	 * object
	 * @param comp 
	 */
	public CompletionModeSetting(SettingResource backend, String key, 
			Class defaultMode, Completion comp)
		
	{
		super(backend, key, defaultMode.getName());
		this.comp = comp;
		setMode();
		comp.addCompletionModeListener(this);
	}

	/**
	 * Reverts the completion mode setting to the default mode and sets it
	 * for the completion object.
	 */
	@Override
	public void revert()
	{
		super.revert();
		setMode();
	}
	
	private void setMode()
	{
		try {
			CompletionMode mode 
				= CompletionModeFactory.createCompletionMode(getValue());
			comp.setMode(mode);
		} catch (IllegalArgumentException iae) {
			logger.debug(iae);
		}
		catch (Exception e) {
			logger.debug(e);
		}
	}
	
	/*
	 * Sets the new mode.
	 */
	public void modeChanged(Class oldMode,  Class newMode)
	{
		logger.info("mode changed from " + oldMode.getName() + " to " 
				+ newMode.getName());
		setValue(newMode.getName());		
	}
}
