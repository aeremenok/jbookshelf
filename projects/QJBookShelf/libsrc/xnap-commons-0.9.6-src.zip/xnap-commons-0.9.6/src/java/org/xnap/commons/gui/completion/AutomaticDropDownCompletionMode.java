/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import java.awt.Point;
import java.awt.Rectangle;
import javax.swing.text.BadLocationException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xnap.commons.gui.util.GUIHelper;

/**
 * This mode mimics KDE's automatic drop down mode. The longest common 
 * unique completion is inserted after the cursor while all ambiguous
 * completions are presented to the user below the text field in a completion
 * popup window.
 * 
 * @author Felix Berger
 */
public class AutomaticDropDownCompletionMode extends AutomaticCompletionMode
{
	private CompletionPopup popup = new CompletionPopup();
    
	private static Log logger = LogFactory.getLog(AutomaticCompletionMode.class);
	
	protected void enable()
	{
		super.enable();
		popup.enablePopup(getCompletion());
	}

	public void disable()
	{
		super.disable();
		popup.disablePopup();
	}

	protected void complete(String prefix)
	{
		super.complete(prefix);
		if (getModel().getSize() > 0) {
			showPopup();
		}
	}

	protected void showPopup()
	{
		if (!getTextComponent().isShowing()) {
			return;
		}
		
		if (getCompletion().isWholeTextCompletion()) {
			GUIHelper.showPopupMenu(popup, getTextComponent(), 0, 
									getTextComponent().getHeight());
		}
		else {
			try {
				int pos = getTextComponent().getCaretPosition() + 1;
				Rectangle r = getTextComponent().modelToView(pos);
				Point p = r.getLocation();
				GUIHelper.showPopupMenu(popup, getTextComponent(),
									p.x, p.y + r.height);
			}
			catch (BadLocationException ble) {
				logger.debug("bad location", ble);
			}			
		}
	}
	
}


