/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Steffen Pingel
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.io;

import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.Callable;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.xnap.commons.gui.ProgressDialog;

/**
 * Provides static helper methods for executing {@link org.xnap.commons.io.Job}
 * objects.
 * 
 * @author Steffen Pingel
 */
public class JobExecutor {
	
	public static <T> Callable<T> callable(final Job<T> job, final ProgressMonitor monitor)
	{
		return new Callable<T>() 
		{
			public T call() throws Exception
			{
				return job.run(monitor);
			}			
		};
	}

	public static <T> T run(String title, Job<T> job) throws Exception 
	{
		ProgressDialog dialog = new ProgressDialog();
		dialog.setTitle(title);
		return run(dialog, job);
	}

	public static <T> T run(JDialog owner, String title, Job<T> job) throws Exception 
	{
		ProgressDialog dialog = new ProgressDialog(owner);
		dialog.setLocationRelativeTo(owner); 
		dialog.setTitle(title);
		return run(dialog, job);
	}
	
	public static <T> T run(JFrame owner, String title, Job<T> job) throws Exception 
	{
		ProgressDialog dialog = new ProgressDialog(owner);
		dialog.setLocationRelativeTo(owner); 
		dialog.setTitle(title);
		return run(dialog, job);
	}

	@SuppressWarnings("unchecked")
	private static <T> T run(final ProgressDialog dialog, final Job<T> job) throws Exception {
		final T[] retSuccess = (T[])new Object[1];
		final Throwable[] ret = new Exception[1];
		
		Runnable runner = new Runnable() {
			public void run()
			{
				try {
					retSuccess[0] = job.run(dialog);
				}
				catch (Throwable e) {
					ret[0] = e;
				}
				SwingUtilities.invokeLater(new Runnable() {
					public void run() {
						dialog.done();
					}
				});
			}
		};

		Thread t = new Thread(runner, "Job");
		t.start();
		
		// show blocking dialog
		dialog.setModal(true);
		dialog.showDialog();
			
		// at this point t is guranteed to be finished
		if (ret[0] != null) {
			if (ret[0] instanceof Exception) {
				throw (Exception)ret[0];
			}
			else {
				throw new InvocationTargetException(ret[0]);
			}
		}
		return (T)retSuccess[0];
	}

}
