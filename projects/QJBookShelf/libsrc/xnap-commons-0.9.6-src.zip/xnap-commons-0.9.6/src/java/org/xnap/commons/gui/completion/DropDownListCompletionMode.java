/*
 *  XNap Commons
 *
 *  Copyright (C) 2005  Felix Berger
 *
 *  This library is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public
 *  License as published by the Free Software Foundation; either
 *  version 2.1 of the License, or (at your option) any later version.
 *
 *  This library is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *  Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public
 *  License along with this library; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
package org.xnap.commons.gui.completion;

import java.awt.Point;
import java.awt.Rectangle;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.BadLocationException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xnap.commons.gui.util.GUIHelper;


/**
 * Uses a {@link org.xnap.commons.gui.completion.CompletionPopup} to present
 * its completions to the user.
 * 
 * @author Felix Berger
 */
public class DropDownListCompletionMode extends AbstractCompletionMode
{
    protected CompletionPopup popup = new CompletionPopup();
	
	protected DocumentListener listener = new DocumentHandler();
	
	private static Log logger = LogFactory.getLog(DropDownListCompletionMode.class);

    protected void enable()
    {
    	popup.enablePopup(getCompletion());
        getTextComponent().getDocument().addDocumentListener(listener);
    }

	public void disable()
	{
		popup.disablePopup();
		getTextComponent().getDocument().removeDocumentListener(listener);
	}
	
	protected void showPopup()
	{
		if (!getTextComponent().isShowing()) {
			return;
		}

		if (getCompletion().isWholeTextCompletion()) {
			GUIHelper.showPopupMenu(popup, getTextComponent(), 0, 
									getTextComponent().getHeight());
		}
		else {
			try {
				int pos = getTextComponent().getCaretPosition() + 1;
				Rectangle r = getTextComponent().modelToView(pos);
				Point p = r.getLocation();
				GUIHelper.showPopupMenu(popup, getTextComponent(),
									p.x, p.y + r.height);
			}
			catch (BadLocationException ble) {
				logger.debug("bad location", ble);
			}
		}
	}

    private class DocumentHandler implements DocumentListener
    {
        public void insertUpdate(DocumentEvent e)
        {
            if (e.getLength() == 1 && getModel().complete(getText())) {
               showPopup();
            }
            else {
            	popup.setVisible(false);
            }
        }

        public void removeUpdate(DocumentEvent e)
        {
            if (e.getLength() == 1 &&  getModel().complete(getText())) {
                showPopup();
            }
            else {
            	popup.setVisible(false);
            }
        }

		/*
		 * @see javax.swing.event.DocumentListener#changedUpdate(javax.swing.event.DocumentEvent)
		 */
		public void changedUpdate(DocumentEvent e)
		{
		}
    }
}
