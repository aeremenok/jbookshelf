import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import org.xnap.commons.gui.FileChooserPanel;

/**
 * 
 * @author Steffen Pingel
 */
public class FileChooserPanelExample extends JFrame {

	private JPanel panel;

	/**
	 * 
	 */
	public FileChooserPanelExample()
	{
		panel = new JPanel(new GridBagLayout());
		getContentPane().add(panel);
		
		FileChooserPanel chooser = new FileChooserPanel(20);
		addComponent("File Chooser:", chooser);

		pack();
	}
	
	private void addLabel(String text)
	{
		JLabel label = new JLabel(text);
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(7, 5, 0, 5);
		panel.add(label, constraints);
		
	}

	private void addComponent(String text, JComponent component) 
	{
		JLabel label = new JLabel(text);
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridwidth = 1;
		constraints.anchor = GridBagConstraints.NORTHWEST;;
		constraints.insets = new Insets(7, 5, 0, 5);
		panel.add(label, constraints);

		constraints = new GridBagConstraints();
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(5, 5, 5, 5);
		panel.add(component, constraints);
	}

	public static void main(String[] args)
	{
		FileChooserPanelExample app = new FileChooserPanelExample();
		app.setDefaultCloseOperation(EXIT_ON_CLOSE);
		app.setTitle("XNap-Commons - " + FileChooserPanelExample.class);
		app.setVisible(true);
	}
}
