import org.xnap.commons.gui.SplashWindow;
import org.xnap.commons.gui.util.IconHelper;

/**
 * 
 * @author Steffen Pingel
 */
public class SplashWindowExample {

	public static void main(final String[] args)
	{
		SplashWindow.showSplashWindow("Splash Window", IconHelper.getImage(64, "tux.png"), 10 * 1000);
		
		try {
			showProgress();
		}
		catch (InterruptedException e) {
		}
		
		SplashWindow.closeSplashWindow();
	}

	private static void showProgress() throws InterruptedException
	{
		Thread.sleep(1000);
		SplashWindow.incProgress(10, "Initializing");
		Thread.sleep(2000);
		SplashWindow.incProgress(10, "Initializing even more");
		Thread.sleep(3000);
		SplashWindow.incProgress(70, "Almost done");
		Thread.sleep(1000);
		SplashWindow.incProgress(10, "That's it, going down");
		Thread.sleep(400);
	}
}
