import org.xnap.commons.settings.PropertyResource;

public class SettingsExample extends PropertyResource {
	
	public SettingsExample()
	{
		super(1, "xnap-commons.example");
	}
	
	public static void main(String[] args)
	{
		SettingsExample settings = new SettingsExample();
	}
	
}