import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import org.xnap.commons.gui.Builder;
import org.xnap.commons.gui.TextFieldMenu;
import org.xnap.commons.gui.completion.AutomaticDropDownCompletionMode;
import org.xnap.commons.gui.completion.Completion;
import org.xnap.commons.gui.completion.CompletionModeMenu;
import org.xnap.commons.gui.completion.CompletionModel;
import org.xnap.commons.gui.completion.DefaultCompletionModel;
import org.xnap.commons.gui.completion.DropDownListCompletionMode;
import org.xnap.commons.gui.completion.FileCompletionModel;
import org.xnap.commons.gui.util.GUIHelper;
import org.xnap.commons.gui.util.PopupListener;
import org.xnap.commons.settings.CompletionModeSetting;
import org.xnap.commons.settings.PropertyResource;

/**
 * This example class creates a text field with completion support. The 
 * completion entries are provided statically.
 * 
 * It also shows how completion settings can be saved and restored by the 
 * settings framework.
 * 
 * Start it and type x to see what happens.
 * 
 * @author Felix Berger
 * @author Steffen Pingel
 */
public class CompletionExample extends JFrame
{
	/**
	 * Filename of the settings file.
	 */
	private static final String FILE_NAME = "completion-settings";
	
	/**
	 * The settings resource object.
	 */
	private static PropertyResource rs;

	private JPanel panel;
	
	public CompletionExample()
	{
		/*
		 * Restore Settings.
		 */
		rs = new PropertyResource();
		try {
			rs.load(new File(FILE_NAME));
		}
		catch (IOException ie) {
			System.out.println("Error loading settings file " + ie.getMessage());
		}

		/*
		 * Register a closing handler, that writes the settings to the file
		 * when it's invoked.
		 */
		addWindowListener(new ClosingHandler());
		
		panel = new JPanel(new GridBagLayout());
		panel.setBorder(GUIHelper.createEmptyBorder(10));
		setContentPane(panel);
		
		addFileCompletion();
		addCustomCompletion();
		addCompletionWithEditMenu();
		addFileCompletion();
//		addPreviousWordCompletion();
	}

	private void addLabel(String text)
	{
		JLabel label = new JLabel(text);
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(7, 5, 0, 5);
		panel.add(label, constraints);
		
	}

	private void addTextField(String text, JComponent textField) 
	{
		JLabel label = new JLabel(text);
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridwidth = 1;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(7, 5, 0, 5);
		panel.add(label, constraints);

		constraints = new GridBagConstraints();
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(5, 5, 5, 5);
		panel.add(textField, constraints);
	}
	
	private void addFileCompletion() 
	{
		/*
		 * Add a file completion text field using the facade.
		 */
		JTextField jtf = new JTextField(20);
		addLabel("Type a filename.");
		addTextField("File-System completion", jtf);
		Completion comp = Builder.addCompletion(jtf, new FileCompletionModel());
		
		/*
		 * Add settings.
		 */
		CompletionModeSetting cms = new CompletionModeSetting(rs,
				"fileCompletion", AutomaticDropDownCompletionMode.class,
				comp);
	}

	private void addCompletionWithEditMenu() 
	{
		JTextField textField = new JTextField(20);
		addLabel("Use the right mouse button to show the context menu.");
		addTextField("File-System completion", textField);

		Completion completion = new Completion(textField, new FileCompletionModel());
		
		TextFieldMenu menu = new TextFieldMenu();
		menu.addSeparator();
		menu.add(new CompletionModeMenu(completion));
		textField.addMouseListener(new PopupListener(menu));
	}

	
	private void addCustomCompletion() 
	{

		/*
		 * Create the text field and add it to the frame's content pane.
		 */
		JTextField jtf = new JTextField(20);
		addLabel("Type 'x'");
		addTextField("Custom Completion", jtf);
		
		/*
		 * Create a default completion model with an array of possible
		 * completions.
		 */
		CompletionModel cm = new DefaultCompletionModel(new String[] {
				"xnap", "xnap commons", "xana", "xilef",
		});
		
		/*
		 * Create a completion object that manages the textfield, the completion
		 * model and the completion modes.
		 */
		Completion comp = new Completion(jtf, cm);
		
		/*	
		 * Create a completion mode menu, to give the user a possibility to 
		 * change the completion mode.
		 */
		CompletionModeMenu menu = new CompletionModeMenu(comp);
		jtf.addMouseListener(new PopupListener(menu));
		
		/*
		 * Create a completion mode setting with a settings key "completion"
		 * a default completion mode DropDownListCompletion and the completion
		 * object as parameters.
		 */
		new CompletionModeSetting(rs, "completion",
				DropDownListCompletionMode.class, comp);

	}
	
	private void addPreviousWordCompletion()
	{
		addLabel("Type words starting with x");
		JTextArea jta = new JTextArea();
		Completion comp = new Completion(jta, false);
		comp.setModel(new DefaultCompletionModel(new Object[] {
				"xnap", "xnapcommons", "xana", "xilef", "XNap", "xylophon",
				"xerxes"
		}));
		comp.setMode(new DropDownListCompletionMode());
		JLabel label = new JLabel("previous word completion");
		GridBagConstraints constraints = new GridBagConstraints();
		constraints.gridwidth = 1;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(7, 5, 0, 5);
		panel.add(label, constraints);

		constraints = new GridBagConstraints();
		constraints.gridwidth = GridBagConstraints.REMAINDER;
		constraints.anchor = GridBagConstraints.NORTHWEST;
		constraints.insets = new Insets(5, 5, 5, 5);
		constraints.fill = GridBagConstraints.BOTH;
		constraints.weightx = 1;
		constraints.weighty = 1;
		panel.add(new JScrollPane(jta), constraints);
	}
	
	public static void main(String[] args)
	{
		CompletionExample app = new CompletionExample();
		app.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		app.setTitle("XNap-Commons - " + CompletionExample.class);
		app.pack();
		app.setVisible(true);
	}
	
	private class ClosingHandler extends WindowAdapter
	{
		
		public void windowClosed(WindowEvent e)
		{
			try {
				rs.store(new File(FILE_NAME));
			}
			catch (IOException ie) {
				System.out.println("Error saving settings file " + ie.getMessage());
			}
		}
		
	}
}
