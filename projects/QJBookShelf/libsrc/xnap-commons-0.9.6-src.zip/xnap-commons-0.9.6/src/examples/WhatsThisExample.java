import java.awt.BorderLayout;
import java.awt.event.KeyEvent;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.KeyStroke;
import org.xnap.commons.gui.util.WhatsThis;
import org.xnap.commons.gui.util.WhatsThisAction;

public class WhatsThisExample {

	public static void main(String[] args)
	{
		JFrame jf = new JFrame();
		JPanel panel = new JPanel(new BorderLayout());
		jf.getContentPane().add(panel);
		JButton button = new JButton(new WhatsThisAction()); 
		panel.add(button, BorderLayout.NORTH);
		JList list = new JList(new String[] { "List with help" });
		panel.add(list, BorderLayout.CENTER);
		
		WhatsThis.setText(list, "Some short text with italics <i>ok?</i><br><br>Let's make this text a little longer to see how line breaks work.");
		
		((JComponent) jf.getContentPane()).registerKeyboardAction
		(new WhatsThisAction(), KeyStroke.getKeyStroke(KeyEvent.VK_F1,
											  KeyEvent.SHIFT_MASK),
		 JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
		
		JButton button2 = new JButton("No help for this button");
		//button2.addActionListener(new CSH.DisplayHelpAfterTracking(new DefaultHelpBroker(null)));
		jf.add(button2, BorderLayout.SOUTH);
		
		JComboBox combo = new JComboBox();
		WhatsThis.setText(combo, "This has a nice text too.");
		jf.add(combo, BorderLayout.EAST);
		
		JSpinner spinner = new JSpinner();
		WhatsThis.setText(spinner, "This is a spinner");
		jf.add(spinner, BorderLayout.WEST);
		
		jf.pack();
		jf.setVisible(true);
	}
}
