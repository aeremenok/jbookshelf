import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import org.xnap.commons.gui.CloseableTabbedPane;
import org.xnap.commons.gui.util.IconHelper;

/**
 * 
 * @author Felix Berger
 */
public class CloseableTabbedPaneExample extends JFrame
{

	/**
	 * 
	 */
	public CloseableTabbedPaneExample()
	{
		CloseableTabbedPane pane = new CloseableTabbedPane();
		pane.setTabPlacement(JTabbedPane.LEFT);
//		pane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
		getContentPane().add(pane);
		pane.addTab("label 1", new JLabel("label 1"));
		pane.addTab("label 2", new JLabel("label 2"));
		pane.addTab("chooser", new JFileChooser());
		//pane.addTab("director chooser", new DirectoryChooser());

		pane.addTab("Top / Scroll", 
				createCloseableTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT));
		pane.addTab("Bottom / Wrap", 
				createCloseableTabbedPane(JTabbedPane.BOTTOM, JTabbedPane.WRAP_TAB_LAYOUT));
		pane.addTab("Left / Scroll", 
				createCloseableTabbedPane(JTabbedPane.LEFT, JTabbedPane.SCROLL_TAB_LAYOUT));
		pane.addTab("Right / Wrap", 
				createCloseableTabbedPane(JTabbedPane.RIGHT, JTabbedPane.WRAP_TAB_LAYOUT));

		pane.addTab("Top / Scroll / Icon", 
				createCloseableIconTabbedPane(JTabbedPane.TOP, JTabbedPane.SCROLL_TAB_LAYOUT));
		
		pack();
	}

	protected CloseableTabbedPane createCloseableIconTabbedPane(int placement, int policy)
	{
		CloseableTabbedPane pane = new CloseableTabbedPane();
		pane.setTabPlacement(placement);
		pane.setTabLayoutPolicy(policy);
		pane.addTab("Tab 1", new JPanel(), IconHelper.getTableIcon("idea.png"));
		pane.addTab("Tab 2", new JPanel(), IconHelper.getTableIcon("editcopy.png"));
		pane.addTab("Tab 3", new JPanel(), IconHelper.getTableIcon("folder.png"));
		pane.addTab("Tab 4", new JPanel(), IconHelper.getTableIcon("idea.png"));
		pane.addTab("Tab 5", new JPanel(), IconHelper.getTableIcon("editcopy.png"));
		pane.addTab("Tab 6", new JPanel(), IconHelper.getTableIcon("folder.png"));
		return pane;
	}
	
	protected CloseableTabbedPane createCloseableTabbedPane(int placement, int policy)
	{
		CloseableTabbedPane pane = new CloseableTabbedPane();
		pane.setTabPlacement(placement);
		pane.setTabLayoutPolicy(policy);
		pane.addTab("Tab 1", new JPanel());
		pane.addTab("Tab 2", new JPanel());
		pane.addTab("Tab 3", new JPanel());
		pane.addTab("Tab 4", new JPanel());
		pane.addTab("Tab 5", new JPanel());
		pane.addTab("Tab 6", new JPanel());
		return pane;
	}
	
	public static void main(String[] args)
	{
		CloseableTabbedPaneExample app = new CloseableTabbedPaneExample();
		app.setDefaultCloseOperation(EXIT_ON_CLOSE);
		app.setTitle("XNap-Commons - " + CloseableTabbedPaneExample.class);
		app.setVisible(true);
	}
}
