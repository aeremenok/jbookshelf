import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import org.xnap.commons.gui.IconSplitPane;
import org.xnap.commons.gui.util.IconHelper;

/**
 * 
 * @author Steffen Pingel
 */
public class IconSplitPaneExample extends JFrame
{

	public IconSplitPaneExample()
	{
		IconSplitPane pane = new IconSplitPane();
		pane.addTab("Penguin", IconHelper.getListIcon("tux.png"), new JLabel("Panel 1", SwingConstants.CENTER));
		pane.addTab("One more", IconHelper.getListIcon("tux.png"), new JLabel("Panel 2", SwingConstants.CENTER));
		pane.addTab("No Icon", null, new JLabel("Panel 3", SwingConstants.CENTER));
		
		setContentPane(pane);
	}
	
	public static void main(String[] args)
	{
		IconSplitPaneExample app = new IconSplitPaneExample();
		app.setTitle("XNap-Commons - " + IconSplitPaneExample.class);
		app.setDefaultCloseOperation(EXIT_ON_CLOSE);
		app.setSize(400, 300);
		app.setVisible(true);
	}
	
}
