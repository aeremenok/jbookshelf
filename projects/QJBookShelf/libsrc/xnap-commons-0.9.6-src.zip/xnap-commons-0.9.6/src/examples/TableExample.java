import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import org.xnap.commons.gui.Builder;
import org.xnap.commons.gui.ColoredTable;
import org.xnap.commons.gui.action.AbstractXNapAction;
import org.xnap.commons.gui.table.TableLayout;
import org.xnap.commons.gui.table.TableSorter;
import org.xnap.commons.settings.PropertyResource;
import org.xnap.commons.settings.TableSettingDirector;

/**
 * 
 * @author Steffen Pingel
 */
public class TableExample extends JFrame
{

	PropertyResource settingsStore = new PropertyResource();
	TableSettingDirector director = new TableSettingDirector(settingsStore, "table");
	TableLayout layout;
	
	/**
	 * 
	 */
	public TableExample()
	{
		JTabbedPane pane = new JTabbedPane();
		
		MyTableModel model = new MyTableModel();
		TableSorter sorter = new TableSorter(model);
		JTable table = new ColoredTable(sorter);
		layout = new TableLayout(table);
		pane.addTab("Sortable Table", new JScrollPane(table));
		
		JPanel buttonPanel = new JPanel(new FlowLayout());
		buttonPanel.add(Builder.createButton(new SaveAction()));
		buttonPanel.add(Builder.createButton(new RestoreAction()));
		
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(pane, BorderLayout.CENTER);
		getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		pack();
	}
	
	public static void main(String[] args)
	{
		TableExample app = new TableExample();
		app.setTitle("XNap-Commons - " + TableExample.class);
		app.setDefaultCloseOperation(EXIT_ON_CLOSE);
		app.pack();
		app.setVisible(true);
	}
	
	private static class MyTableModel extends AbstractTableModel {

		private static Date createDate(int year, int month, int day) {
			Calendar cal = Calendar.getInstance();
			cal.set(year, month, day);
			return cal.getTime();
		}
		
		private static final Object[][] data = {
			{ "StatCvs-XML", "0.9.6", createDate(2004, 10, 23), new Integer(8500) },
			{ "XNap", "3.0-rc1", createDate(2003, 10, 5), new Integer(60000) },
			{ "XNap-Commons", "1.0", createDate(2005, 2, 5),new Integer(3500) },
		};
		
		private static final String[] columnNames = {
			"Project", "Version", "Release Date", "Lines of Code"
		};
		
		private static final Class[] columnClasses= {
			String.class, String.class, Date.class, Integer.class
		};
		
		public MyTableModel() 
		{
			// let the super class know we already have some data
			fireTableDataChanged();
		}
		
		public Object getValueAt(int aRow, int aColumn)
		{
			return data[aRow][aColumn];
		}

		public int getRowCount()
		{
			return data.length;
		}

		public int getColumnCount()
		{
			return columnNames.length;
		}
		
	    public String getColumnName(int column) {
	        return columnNames[column];
	    }

	    public Class<?> getColumnClass(int column) {
	        return columnClasses[column];
	    }

	}
	
	private class SaveAction extends AbstractXNapAction {
		public SaveAction() {
			putValue(NAME, "Save");
		}
		public void actionPerformed(ActionEvent e) {
			director.save(layout);
		}
	}

	private class RestoreAction extends AbstractXNapAction {
		public RestoreAction() {
			putValue(NAME, "Restore");
		}
		public void actionPerformed(ActionEvent e) {
			director.restore(layout);
		}
	}

}
