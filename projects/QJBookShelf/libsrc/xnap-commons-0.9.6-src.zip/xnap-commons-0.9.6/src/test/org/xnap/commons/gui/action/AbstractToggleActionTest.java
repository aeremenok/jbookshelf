package org.xnap.commons.gui.action;

import javax.swing.AbstractButton;
import junit.framework.TestCase;
import org.xnap.commons.gui.Builder;


public class AbstractToggleActionTest extends TestCase {

	boolean state;
	boolean invoked;
	
	public void testToggleButton()
	{
		MyToggleAction action = new MyToggleAction();
		AbstractButton button = Builder.createButton(action);
		
		// just make sure we are correctly initialized
		assertFalse(action.isSelected());
		assertFalse(button.isSelected());
		
		invoked = false;
		button.doClick();
		assertEquals(true, action.isSelected());
		assertEquals(true, invoked);
		
		invoked = false;
		button.doClick();
		assertEquals(false, action.isSelected());
		assertEquals(true, invoked);		
	}

	public void testToggleAction()
	{
		MyToggleAction action = new MyToggleAction();
		AbstractButton button = Builder.createButton(action);
		
		// just make sure we are correctly initialized
		assertEquals(false, action.isSelected());
		assertEquals(false, button.isSelected());
		
		invoked = false;
		action.setSelected(true);
		assertEquals(true, button.isSelected());
		assertEquals(true, invoked);
		
		invoked = false;
		action.setSelected(false);
		assertEquals(false, button.isSelected());
		assertEquals(true, invoked);		
	}

	public void testSetSelected()
	{
		MyToggleAction action = new MyToggleAction();
		assertFalse(action.isSelected());
		
		invoked = false;
		action.setSelected(true);
		assertTrue(action.isSelected());
		assertTrue(invoked);

		invoked = false;
		action.setSelected(true);
		assertTrue(action.isSelected());
		assertFalse(invoked);

		invoked = false;
		action.setSelected(false);
		assertFalse(action.isSelected());
		assertTrue(invoked);

		invoked = false;
		action.setSelected(false);
		assertFalse(action.isSelected());
		assertFalse(invoked);

		invoked = false;
		action.setSelected(true);
		assertTrue(action.isSelected());
		assertTrue(invoked);
	}
	
	public class MyToggleAction extends AbstractToggleAction {

		public MyToggleAction(boolean selected)
		{
			super(selected);
		}
		
		public MyToggleAction()
		{
		}
		
		@Override
		public void toggled(boolean selected)
		{
			state = selected;
			invoked = true;
		}
		
	}
	
}
