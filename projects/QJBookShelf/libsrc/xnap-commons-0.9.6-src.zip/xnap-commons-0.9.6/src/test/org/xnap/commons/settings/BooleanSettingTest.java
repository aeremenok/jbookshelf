package org.xnap.commons.settings;

/**
 * @author Steffen Pingel
 */
public class BooleanSettingTest extends AbstractSettingTest<Boolean> {

	public BooleanSettingTest()
	{
		super(Boolean.FALSE, Boolean.TRUE, Boolean.FALSE);
	}

	@Override
	protected Setting<Boolean> createSetting(SettingResource backend, String key, Boolean defaultValue)
	{
		return new BooleanSetting(backend, key, defaultValue);
	}

}
