package org.xnap.commons.gui.table;

import java.util.Calendar;
import java.util.Date;
import javax.swing.table.AbstractTableModel;
import junit.framework.TestCase;


public class TableSorterTest extends TestCase {

	private MyTableModel tableModel;
	private TableSorter tableSorter;

	protected void setUp() throws Exception
	{
		super.setUp();
		
		tableModel = new MyTableModel();
		tableSorter = new TableSorter(tableModel);
	}

	protected void tearDown() throws Exception
	{
		super.tearDown();
		
		tableSorter = null;
		tableModel = null;
	}

	public void testGetTableModel()
	{
		assertEquals(tableModel, tableSorter.getTableModel());
	}

	public void testGetRowCount()
	{
		assertEquals(3, tableSorter.getRowCount());
	}

	public void testGetSortedColumn()
	{
		tableSorter.sortByColumn(1, SortableModel.Order.ASCENDING, false);
		assertEquals(1, tableSorter.getSortedColumn());
		tableSorter.sortByColumn(1, SortableModel.Order.ASCENDING, true);
		assertEquals(1, tableSorter.getSortedColumn());
		tableSorter.sortByColumn(0, SortableModel.Order.ASCENDING, false);
		assertEquals(0, tableSorter.getSortedColumn());
		tableSorter.sortByColumn(2, SortableModel.Order.ASCENDING, false);
		assertEquals(2, tableSorter.getSortedColumn());
		
		try {
			tableSorter.sortByColumn(-1, SortableModel.Order.ASCENDING, false);
			assertFalse("Expected IllegalArgumentException", true);
		} catch (IllegalArgumentException e) {}
		try {
			tableSorter.sortByColumn(tableModel.getColumnCount(), SortableModel.Order.ASCENDING, false);
			assertFalse("Expected IllegalArgumentException", true);
		} catch (IllegalArgumentException e) {}
	}

	public void testGetSortOrder()
	{
		tableSorter.sortByColumn(1, SortableModel.Order.ASCENDING, false);
		assertEquals(SortableModel.Order.ASCENDING, tableSorter.getSortOrder());
		tableSorter.sortByColumn(1, SortableModel.Order.ASCENDING, true);
		assertEquals(SortableModel.Order.ASCENDING.next(), tableSorter.getSortOrder());
		tableSorter.sortByColumn(1, SortableModel.Order.ASCENDING.next(), true);
		assertEquals(SortableModel.Order.ASCENDING.next().next(), tableSorter.getSortOrder());
		tableSorter.sortByColumn(1, SortableModel.Order.ASCENDING.next().next(), true);
		assertEquals(SortableModel.Order.ASCENDING.next().next().next(), tableSorter.getSortOrder());
	}

	public void testMapToIndex()
	{
		tableSorter.sortByColumn(1, SortableModel.Order.UNSORTED, false);
		assertEquals(0, tableSorter.mapToIndex(0));
		assertEquals(1, tableSorter.mapToIndex(1));
		assertEquals(2, tableSorter.mapToIndex(2));
	}

	private static class MyTableModel extends AbstractTableModel {

		private static Date createDate(int year, int month, int day) {
			Calendar cal = Calendar.getInstance();
			cal.set(year, month, day);
			return cal.getTime();
		}
		
		private static final Object[][] data = {
			{ "StatCvs-XML", "0.9.6", createDate(2004, 10, 23), new Integer(8500) },
			{ "XNap", "3.0-rc1", createDate(2003, 10, 5), new Integer(60000) },
			{ "XNap-Commons", "1.0", createDate(2005, 2, 5),new Integer(3500) },
		};
		
		private static final String[] columnNames = {
			"Project", "Version", "Release Date", "Lines of Code"
		};
		
		private static final Class[] columnClasses= {
			String.class, String.class, Date.class, Integer.class
		};
		
		public MyTableModel() 
		{
			// let the super class know we already have some data
			fireTableDataChanged();
		}
		
		public Object getValueAt(int aRow, int aColumn)
		{
			return data[aRow][aColumn];
		}

		public int getRowCount()
		{
			return data.length;
		}

		public int getColumnCount()
		{
			return columnNames.length;
		}
		
	    public String getColumnName(int column) {
	        return columnNames[column];
	    }

	    public Class<?> getColumnClass(int column) {
	        return columnClasses[column];
	    }

	}
	
}
