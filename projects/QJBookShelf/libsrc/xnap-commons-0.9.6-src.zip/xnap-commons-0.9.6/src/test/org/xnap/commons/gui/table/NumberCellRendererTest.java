package org.xnap.commons.gui.table;

import junit.framework.TestCase;

public class NumberCellRendererTest extends TestCase {

	public void testSetValue()
	{
		
		NumberCellRenderer r = new NumberCellRenderer(-100000000);
		r.setValue(null);
		assertEquals("", r.getText());
		
		Number[] values = { 1.1, -30945.495495, 0, 10, 240394545, 1024, 8945405, -1};
		
		for (Number n : values) {
			r.setValue(n);
			assertEquals(String.format(r.getFormatString(), n.doubleValue()), r.getText());
		}
	}
	
}
