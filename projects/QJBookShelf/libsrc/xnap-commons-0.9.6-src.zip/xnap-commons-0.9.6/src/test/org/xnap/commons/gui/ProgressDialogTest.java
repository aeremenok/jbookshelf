package org.xnap.commons.gui;

import org.xnap.commons.io.GenericProgressMonitorTest;

public class ProgressDialogTest extends GenericProgressMonitorTest<ProgressDialog> {

	@Override
	protected ProgressDialog createProgressMonitor()
	{
		return new ProgressDialog();
	}

	@Override
	protected long getValue(ProgressDialog monitor)
	{
		return monitor.getValue();
	}
	
	public void testGetComponent()
	{
		ProgressDialog dialog = new ProgressDialog();
		assertEquals(dialog, dialog.getComponent());
	}
	
}
