package org.xnap.commons.settings;

public class EnumSettingTest extends AbstractSettingTest<EnumSettingTest.TestKind> {

	enum TestKind {
		GOOD,
		BAD,
		EXHAUSTIVE,
	}
	
	public EnumSettingTest()
	{
		super(TestKind.GOOD, TestKind.BAD, TestKind.EXHAUSTIVE); 
	}
	
	@Override
	protected Setting<TestKind> createSetting(SettingResource backend, String key,
			TestKind defaultValue) {
		return new EnumSetting<TestKind>(backend, key, defaultValue);
	}
	
	/**
	 * Overriden since EnumSetting does not allow default value to be null.
	 */
	@Override
	public void testDefaultNull()
	{
		try {
			super.testDefaultNull();
			fail("IllegalArgumentException expected");
		}
		catch (IllegalArgumentException iae) {
		}
	}

}
