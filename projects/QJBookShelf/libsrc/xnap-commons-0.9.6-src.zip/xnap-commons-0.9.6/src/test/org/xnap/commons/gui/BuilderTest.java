package org.xnap.commons.gui;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComponent;
import javax.swing.JMenu;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;
import junit.framework.TestCase;
import org.xnap.commons.gui.action.AbstractToggleAction;
import org.xnap.commons.gui.action.ToggleAction;
import org.xnap.commons.gui.completion.Completion;
import org.xnap.commons.gui.completion.CompletionModel;
import org.xnap.commons.gui.factory.DefaultFactory;
import org.xnap.commons.gui.factory.Factory;

public class BuilderTest extends TestCase {

	public void testAddCompletion()
	{
		JTextField jtf = new JTextField();
		Completion comp = Builder.addCompletion(jtf);
		assertNotNull(comp);
		assertEquals(jtf, comp.getTextComponent());
		
		TestComletionModel model = new TestComletionModel();
		comp = Builder.addCompletion(jtf, model);
		assertNotNull(comp);
		assertEquals(jtf, comp.getTextComponent());
		assertEquals(model, comp.getModel());
		
		JMenu menu = new JMenu();
		assertEquals(0, menu.getItemCount());
		comp = Builder.addCompletion(jtf, menu);
		assertNotNull(comp);
		assertEquals(jtf, comp.getTextComponent());
		assertTrue(menu.getItemCount() > 0);
		
		menu = new JMenu();
		assertEquals(0, menu.getItemCount());
		comp = Builder.addCompletion(jtf, menu, model);
		assertNotNull(comp);
		assertEquals(jtf, comp.getTextComponent());
		assertEquals(model, comp.getModel());
		assertTrue(menu.getItemCount() > 0);
	}
	
	public void testCreateButton()
	{
		TestAction action = new TestAction();
		AbstractButton button = Builder.createButton(action);
		assertNotNull(button);
		assertEquals(action, button.getAction());
	}
	
	public void testCreateCheckBox()
	{
		TestToggleAction action = new TestToggleAction();
		AbstractButton button = Builder.createCheckBox(action);
		assertNotNull(button);
		assertEquals(action, button.getAction());
	}
	
	public void testCreateIconButton()
	{
		TestAction action = new TestAction();
		AbstractButton button = Builder.createIconButton(action);
		assertNotNull(button);
		assertEquals(action, button.getAction());
	}
	
	public void testCreateToolBarButton()
	{
		TestAction action = new TestAction();
		AbstractButton button = Builder.createToolBarButton(action);
		assertNotNull(button);
		assertEquals(action, button.getAction());
	}
	
	public void testSetProperty()
	{
		DefaultFactory factory = (DefaultFactory)Builder.getFactory();
		assertNull(factory.getProperty("madeup"));
		Builder.setProperty("madeup", "value");
		assertEquals("value", factory.getProperty("madeup"));
	}
	
	public void testSetFactory()
	{
		assertEquals(DefaultFactory.class, Builder.getFactory().getClass());
		
		TestFactory factory = new TestFactory(); 
		Builder.setFactory(factory);
		assertEquals(factory, Builder.getFactory());
		
		Builder.setFactory(null);
		assertEquals(DefaultFactory.class, Builder.getFactory().getClass());
	}
	
	private static class TestFactory implements Factory
	{

		public void addCompletionModeMenu(JTextComponent textComponent, Completion completion) {
		}

		public void addCompletionModeMenu(JMenu menu, Completion completion) {
		}

		public AbstractButton createButton(Action action) {
			return null;
		}

		public AbstractButton createCheckBox(ToggleAction action) {
			return null;
		}

		public AbstractButton createIconButton(Action action) {
			return null;
		}

		public AbstractButton createToolBarButton(Action action) {
			return null;
		}

		public JComponent createMenuItem(Action action) {
			return null;
		}

		public void setProperty(Object key, Object value) {
		}
		
	}
	
	private class TestComletionModel extends DefaultComboBoxModel implements CompletionModel
	{

		public boolean complete(String prefix) {
			return false;
		}

		public String completeUniquePrefix(String prefix) {
			return "";
		}
		
	}
	
	private class TestAction extends AbstractAction
	{

		public void actionPerformed(ActionEvent e) {

		}
		
	}
	
	private class TestToggleAction extends AbstractToggleAction
	{

		@Override
		public void toggled(boolean selected) {
					
		}
		
	}
	
}
