package org.xnap.commons.settings;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import junit.framework.TestCase;

/**
 * @author Steffen Pingel
 */
public class PropertyResourceTest extends TestCase {
	
	boolean listenerInvoked;

	public void testDefaultRemove()
	{
		PropertyResource resource = new PropertyResource();
		resource.put("test", "foo");
		assertEquals(resource.get("test", null), "foo");
		
		StringSetting setting = new StringSetting(resource, "test", "default");
		
		assertEquals(setting.getValue(), "foo");
		setting.setValue("default");
		assertEquals(resource.get("test", null), null);
	}
	
	public void testPut()
	{
		PropertyResource resource = new PropertyResource();
		
		assertEquals(resource.get("test", null), null);
		assertEquals(resource.get("test", "value"), "value");
		
		resource.put("test", "value");
		assertEquals(resource.get("test", null), "value");
		assertEquals(resource.get("test", "foo"), "value");
		
		resource.put("test", "newvalue");
		assertEquals(resource.get("test", null), "newvalue");
		assertEquals(resource.get("test", "foo"), "newvalue");
	}

	public void testLoadStore() throws Exception
	{
		PropertyResource resource1 = new PropertyResource();
		resource1.put("test", "value");
		resource1.put("xnap-commons", "rocks");
		
		File file1 = File.createTempFile("properties", "file");
		resource1.store(file1);
		
		PropertyResource resource2 = new PropertyResource();
		resource2.load(file1);
		assertEquals(resource1, resource2);
		
		// empty resources
		resource1 = new PropertyResource();
		File file2 = File.createTempFile("empty", "properties");
		resource1.store(file2);
		resource2 = new PropertyResource();
		resource2.load(file2);
		assertEquals(resource1, resource2);
		
		file1.delete();
		file2.delete();
	}
	
	public void testEquals()
	{
		PropertyResource r1 = new PropertyResource();
		assertEquals(r1, r1);
		PropertyResource r2 = new PropertyResource(0, "namespace");
		assertNotSame(r1, r2);
		r1 = new PropertyResource(0, "namespace");
		assertEquals(r1, r2);
		r1 = new PropertyResource(1, "namespace");
		assertNotSame(r1, r2);
		r1 = new PropertyResource(0, "different");
		assertNotSame(r1, r2);
		r1 = new PropertyResource(0, "namespace");
		r1.put("not", "empty");
		assertNotSame(r1, r2);
		r2.put("not", "empty");
		assertEquals(r1, r2);
	}
	
	public void testPropertyChangeListenerStringSetting()
	{
		PropertyResource resource = new PropertyResource();
		
		StringSetting setting = new StringSetting(resource, "test", "default");
		
		PropertyChangeListener listener = addListener(resource, "test", "default", "value");
		setting.setValue("value");
		assertTrue(listenerInvoked);
		resource.removePropertyChangeListener(listener);
		
		listener = addListener(resource, "test", "value", "newvalue");
		setting.setValue("newvalue");
		assertTrue(listenerInvoked);
		resource.removePropertyChangeListener(listener);
	}

	public PropertyChangeListener addListener(PropertyResource resource, final String key, final String oldValue, final String newValue)
	{
		PropertyChangeListener listener = new PropertyChangeListener()
		{
			public void propertyChange(PropertyChangeEvent event)
			{
				assertEquals(event.getPropertyName(), key);
				assertEquals(event.getOldValue(), oldValue);
				assertEquals(event.getNewValue(), newValue);
				listenerInvoked = true;
			}
	
		};
		resource.addPropertyChangeListener(listener);
		listenerInvoked = false;
		return listener;
	}
	
}
