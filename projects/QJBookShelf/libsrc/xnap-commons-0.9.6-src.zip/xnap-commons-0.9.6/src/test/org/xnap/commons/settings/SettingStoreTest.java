package org.xnap.commons.settings;

import java.awt.Dimension;
import java.awt.Point;
import javax.swing.JSplitPane;
import javax.swing.JWindow;
import junit.framework.TestCase;


public class SettingStoreTest extends TestCase {

	private SettingResource backstore;
	private SettingStore store;

	@Override
	protected void setUp() throws Exception
	{
		super.setUp();
		
		this.backstore = new PropertyResource();
		this.store = new SettingStore(backstore);
	}
	
	@Override
	protected void tearDown() throws Exception
	{
		super.tearDown();
		
		this.store = null;
	}
	
	public void testGetBackStore()
	{
		assertEquals(this.backstore, store.getBackStore());
	}
	
	public void testSplitPane()
	{
		JSplitPane pane = new JSplitPane();
		
		pane.setDividerLocation(100);
		store.restoreSplitPane("foo", 50, pane);
		assertEquals(50, pane.getDividerLocation());
		
		pane.setDividerLocation(100);
		store.saveSplitPane("foo", pane);
		assertEquals(100, pane.getDividerLocation());
		
		store.restoreSplitPane("foo", 50, pane);
		assertEquals(100, pane.getDividerLocation());
	}

	public void testWindow()
	{
		JWindow window = new JWindow();
		
		window.setLocation(50, 100);
		window.setSize(150, 200);
		store.restoreWindow("foo", 5, 10, 15, 20, window);
		assertEquals(new Point(5, 10), window.getLocation());
		assertEquals(new Dimension(15, 20), window.getSize());
		
		window.setLocation(55, 105);
		window.setSize(155, 205);
		store.saveWindow("foo", window);
		
		store.restoreWindow("foo", 5, 10, 15, 20, window);
		assertEquals(new Point(55, 105), window.getLocation());
		assertEquals(new Dimension(155, 205), window.getSize());
	}

}
