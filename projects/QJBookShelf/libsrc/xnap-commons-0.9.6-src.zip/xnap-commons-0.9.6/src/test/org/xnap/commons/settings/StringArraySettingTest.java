package org.xnap.commons.settings;

/**
 * @author Steffen Pingel
 */
public class StringArraySettingTest extends AbstractArraySettingTest<String[]> {

	final static String[] values1 = new String[] {
		"foo", "bar", "baz"
	};
	final static String[] values2 = new String[] {
		"one", "two"
	};

	final static String[] values3 = new String[] {
		"a"
	};

	public StringArraySettingTest()
	{
		super(values1, values2, values3);
	}

	@Override
	protected Setting<String[]> createSetting(SettingResource backend, String key, String[] defaultValue)
	{
		return new StringArraySetting(backend, key, defaultValue);
	}

}
