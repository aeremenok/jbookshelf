package org.xnap.commons.gui.completion;

import javax.swing.Action;
import javax.swing.JMenuItem;
import javax.swing.JTextField;
import junit.framework.TestCase;
import org.xnap.commons.gui.completion.CompletionModeFactory.CompletionModeInfo;

public class CompletionModeMenuTest extends TestCase {

	private Completion comp;
	private CompletionModeInfo[] infos;
	private CompletionModeMenu menu;
	
	@Override
	protected void setUp() throws Exception 
	{
		comp = new Completion(new JTextField());
		infos = CompletionModeFactory.getInstalledCompletionModes();
		menu = new CompletionModeMenu(comp);	
	}

	public void testAllInstalledModesAreThere()
	{
	
		assertTrue(menu.getItemCount() >= infos.length);
		for (CompletionModeInfo info : infos) {
			assertTrue(info.getClassName() + " not there",
					menuContainsActionCommand(menu, info.getClassName()));
		}
	}

	private boolean menuContainsActionCommand(CompletionModeMenu menu, String className) 
	{
		for (int i = 0; i < menu.getItemCount(); i++) {
			JMenuItem item = menu.getItem(i);
			Action a = item.getAction();
			if (a != null) {
				String key = (String)a.getValue(Action.ACTION_COMMAND_KEY);
				if (key != null && key.equals(className)) {
					return true;
				}
			}
		}
		return false;
	}
	
	public void testIsNotifiedOfModeChanges()
	{
		comp.setMode(new AutomaticCompletionMode());
		int index = getSelectedIndex(menu);
		assertNotSame(-1, index);
		comp.setMode(new EmacsCompletionMode());
		assertNotSame(index, getSelectedIndex(menu));
	}

	private int getSelectedIndex(CompletionModeMenu menu) {
		for (int i = 0; i < menu.getItemCount(); i++) {
			JMenuItem item = menu.getItem(i);
			if (item != null && item.isSelected()) {
				return i;
			}
		}
		return -1;
	}
	
	public void testClickWorks()
	{
		Class oldMode = comp.getMode().getClass();
		int oldIndex = getSelectedIndex(menu);
		for (int i = 0; i < menu.getItemCount(); i++) {
			JMenuItem item = menu.getItem(i);
			if (item != null && !item.isSelected()) {
				item.doClick();
				assertNotSame(oldMode, comp.getMode().getClass());
				assertNotSame(oldIndex, i);
				oldMode = comp.getMode().getClass();
				oldIndex = i;
			}
		}
	}
}
