package org.xnap.commons.gui;

import java.io.File;
import junit.framework.TestCase;

public class DirectoryChooserTest extends TestCase {
	
	public void testRootSelection()
	{
		File[] roots = File.listRoots();
		if (roots == null || roots.length == 0) {
			return;
		}
		
		DirectoryChooser dialog = new DirectoryChooser();
		dialog.setSelectedDirectory(roots[0]);
		assertEquals(roots[0], dialog.getSelectedDirectory());
		if (roots.length > 1) {
			dialog.setSelectedDirectory(roots[1]);
			assertEquals(roots[1], dialog.getSelectedDirectory());
		}
	}
	
	public void testSetSelectedDir()
	{
		File file = new File(System.getProperty("java.io.tmpdir"));
		DirectoryChooser dialog = new DirectoryChooser();
		dialog.setSelectedDirectory(file);
		assertEquals(file, dialog.getSelectedDirectory());
	}

}
