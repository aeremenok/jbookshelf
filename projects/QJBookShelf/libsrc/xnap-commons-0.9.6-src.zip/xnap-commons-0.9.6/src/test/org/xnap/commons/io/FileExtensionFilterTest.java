package org.xnap.commons.io;

import java.io.File;
import junit.framework.TestCase;


public class FileExtensionFilterTest extends TestCase {

	public void testAcceptDirectory()
	{
		FileExtensionFilter filter = new FileExtensionFilter("description", "bar");
		assertEquals(true, filter.accept(new File(System.getProperty("java.io.tmpdir"))));
	}
	
	public void testAcceptFileArray()
	{
		FileExtensionFilter filter = new FileExtensionFilter("description", new String[] { "bar", "baz" });
		assertEquals(false, filter.accept(new File("foo")));
		assertEquals(false, filter.accept(new File("description")));
		assertEquals(false, filter.accept(new File("foobar ")));
		assertEquals(false, filter.accept(new File("foobarfoo")));
		assertEquals(false, filter.accept(new File("foobaz ")));
		assertEquals(false, filter.accept(new File("foobazfoo")));
		assertEquals(true, filter.accept(new File("bar")));
		assertEquals(true, filter.accept(new File("foo.bar")));
		assertEquals(true, filter.accept(new File("foobar")));
		assertEquals(true, filter.accept(new File("baz")));
		assertEquals(true, filter.accept(new File("foo.baz")));
		assertEquals(true, filter.accept(new File("foobaz")));
	}

	public void testAcceptFile()
	{
		FileExtensionFilter filter = new FileExtensionFilter("description", "bar");
		assertEquals(false, filter.accept(new File("foo")));
		assertEquals(false, filter.accept(new File("description")));
		assertEquals(false, filter.accept(new File("foobar ")));
		assertEquals(false, filter.accept(new File("foobarfoo")));
		assertEquals(true, filter.accept(new File("bar")));
		assertEquals(true, filter.accept(new File("foo.bar")));
		assertEquals(true, filter.accept(new File("foobar")));
	}

	public void testGetDescription()
	{
		FileExtensionFilter filter = new FileExtensionFilter("description", "bar");
		assertEquals(filter.getDescription(), "description");
		
		filter = new FileExtensionFilter("", "bar");
		assertEquals(filter.getDescription(), "");
	}
	
}

