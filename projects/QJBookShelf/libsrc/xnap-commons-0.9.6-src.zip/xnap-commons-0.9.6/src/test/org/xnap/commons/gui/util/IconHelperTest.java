package org.xnap.commons.gui.util;

import javax.swing.ImageIcon;
import junit.framework.TestCase;

public class IconHelperTest extends TestCase {
	
	public void testGetImage()
	{
		ImageIcon image = IconHelper.getImage("16/editcut.png");
		assertNotNull(image);
		assertTrue(image.toString().contains("editcut.png"));
		assertEquals(IconHelper.getImage(16, "editcut.png").toString(), image.toString());
	}

	public void testGetIcon()
	{
		assertNotNull(IconHelper.getIcon("editcut.png", 16));
		assertNotNull(IconHelper.getIcon("foobar", 16, true));
		assertNull(IconHelper.getIcon("foobar", 16, false));
	}

	// TODO test alternative search pathes
	// TODO test alternative file extensions
	
}
