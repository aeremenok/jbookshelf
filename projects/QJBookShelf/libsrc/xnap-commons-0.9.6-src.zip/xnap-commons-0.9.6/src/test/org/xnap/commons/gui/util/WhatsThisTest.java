package org.xnap.commons.gui.util;

import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import junit.framework.TestCase;

public class WhatsThisTest extends TestCase {

	
	public void testSetText()
	{
		JTextField jtf = new JTextField();
		WhatsThis.setText(jtf, "hello");
		assertEquals("hello", WhatsThis.getText(jtf, false));
		WhatsThis.removeText(jtf);
		assertNull(WhatsThis.getText(jtf, false));
		assertNull(WhatsThis.getText(jtf, true));
	}
	
	public void testGetText()
	{
		JPanel panel = new JPanel();
		WhatsThis.setText(panel, "panel");
		JButton jtf = new JButton();
		panel.add(jtf);
		assertNull(WhatsThis.getText(jtf, false));
		assertEquals("panel", WhatsThis.getText(jtf, true));
		WhatsThis.removeText(panel);
		assertNull(WhatsThis.getText(jtf, true));
		
		Action a = new WhatsThisTestAction();
		JButton button = new JButton(a);
		panel.add(button);
		a.putValue(Action.LONG_DESCRIPTION, "actiontext");
		WhatsThis.setText(button, "whatsthistext");
		assertEquals("actiontext", WhatsThis.getText(button, false));
		assertEquals("actiontext", WhatsThis.getText(button, true));
		a.putValue(Action.LONG_DESCRIPTION, null);
		assertEquals("whatsthistext", WhatsThis.getText(button, false));
		assertEquals("whatsthistext", WhatsThis.getText(button, true));
		WhatsThis.removeText(button);
		assertNull(WhatsThis.getText(button, false));
		WhatsThis.setText(panel, "panel");
		assertEquals("panel", WhatsThis.getText(button, true));
	}
	
	private class WhatsThisTestAction extends AbstractAction
	{

		public WhatsThisTestAction()
		{
		}
		
		public void actionPerformed(ActionEvent e) {
		
		}
		
	}
	
}
