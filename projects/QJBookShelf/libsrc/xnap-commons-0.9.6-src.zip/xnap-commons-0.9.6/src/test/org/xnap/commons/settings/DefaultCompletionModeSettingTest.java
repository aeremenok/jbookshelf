package org.xnap.commons.settings;

import junit.framework.TestCase;
import org.xnap.commons.gui.completion.AutomaticDropDownCompletionMode;
import org.xnap.commons.gui.completion.GlobalDefaultCompletionMode;
import org.xnap.commons.gui.completion.NoCompletionMode;


/**
 * @author Steffen Pingel
 */
public class DefaultCompletionModeSettingTest extends TestCase {

	private PropertyResource backend;

	public DefaultCompletionModeSettingTest()
	{
	}

	@Override
	public void setUp() throws Exception
	{
		super.setUp();
		
		backend = new PropertyResource();
	}

	@Override
	public void tearDown() throws Exception
	{
		super.tearDown();
		
		backend = null;
	}

	public void testGlobalDefaultCompletionMode()
	{
		DefaultCompletionModeSetting setting 
			= new DefaultCompletionModeSetting(backend, "aaa", NoCompletionMode.class.getName());
		assertEquals(NoCompletionMode.class.getName(), GlobalDefaultCompletionMode.getCompletionMode());
		setting.setValue(AutomaticDropDownCompletionMode.class.getName());
		assertEquals(AutomaticDropDownCompletionMode.class.getName(), GlobalDefaultCompletionMode.getCompletionMode());
	}

}
