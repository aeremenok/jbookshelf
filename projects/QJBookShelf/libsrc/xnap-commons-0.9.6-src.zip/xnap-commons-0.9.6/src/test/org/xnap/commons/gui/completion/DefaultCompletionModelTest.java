package org.xnap.commons.gui.completion;

import java.util.Arrays;
import junit.framework.TestCase;

/**
 * @author Steffen Pingel
 */
public class DefaultCompletionModelTest extends TestCase {

	private DefaultCompletionModel model;

	public DefaultCompletionModelTest(String name)
	{
		super(name);
	}

	public void setUp()
	{
		model = new DefaultCompletionModel();
		model.insert("aaaa");
		model.insert(new String[] { "aaaa", "aaab", "abaa", "aaac"});
		model.insert("aaac");
	}

	public void tearDown()
	{
		model = null;
	}

	public void testCompletion()
	{
		model.complete("aa");
		assertEquals(3, model.getSize());

		model.complete("ab");
		assertEquals(1, model.getSize());
	}

	public void testEmptyCompletion()
	{
		model.complete("b");
		assertEquals(0, model.getSize());
	}

	public void testSingleCompletion()
	{
		model.complete("aaaa");
		assertEquals(1, model.getSize());

		model.complete("aaac");
		assertEquals(1, model.getSize());
	}

	public void testEmptyStringCompletion()
	{
		assertFalse(model.complete(""));
		assertEquals(0, model.getSize());
	}

	public void testUniquePrefix()
	{
		assertEquals("aaa", model.completeUniquePrefix("aa"));
	}

	public void testSingleUniquePrefix()
	{
		assertEquals("aaaa", model.completeUniquePrefix("aaaa"));
		assertEquals("aaac", model.completeUniquePrefix("aaac"));
	}

	public void testEmptyUniquePrefix()
	{
		assertEquals("b", model.completeUniquePrefix("b"));
	}

	public void testRemove()
	{
		model.insert("aaaaaab");
		assertEquals("aaaaaab", model.completeUniquePrefix("aaaaaa"));
		model.remove("aaaaaab");
		assertEquals("aaaaa", model.completeUniquePrefix("aaaaa"));
		model.clear();
		// remove object from empty model
		model.remove("aaab");
	}
	
	public void testClear()
	{
		assertTrue("model should not be empty", model.toArray().length > 0);
		model.clear();
		assertEquals("model should be empty now", 0, model.toArray().length);
	}
	
	public void testInsert()
	{
		model.clear();
		assertTrue(model.toArray().length == 0);
		String[] array = new String[] { "unsorted", "xnap", "help", "doesnotmatter" };
		model.insert(array);
		assertEquals(Arrays.asList(array), Arrays.asList(model.toArray()));
		model.clear();
		assertTrue(model.toArray().length == 0);
		String[] sorted = new String[] { "abcded", "bflat1", "fberger", "squig", "stp" };
		model.insert(sorted, true);
		assertEquals(Arrays.asList(sorted), Arrays.asList(model.toArray()));
	}
}
