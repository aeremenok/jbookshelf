package org.xnap.commons.util;

import javax.swing.JList;
import javax.swing.ListModel;
import javax.swing.SwingUtilities;
import junit.framework.TestCase;

public class AWTExceptionHandlerTest extends TestCase {

	private AWTExceptionHandler handler;
	private Object lock;
	private TestUncaughtExceptionHandler uncaughtHandler;
	private volatile boolean sleep;
	
	@Override
	public void setUp()
	{
		handler = new AWTExceptionHandler();
		AWTExceptionHandler.install();
		lock = new Object();
		uncaughtHandler = new TestUncaughtExceptionHandler();
		UncaughtExceptionManager.setDefaultHandler(uncaughtHandler);
	}
	
	public void testHandle() throws Exception
	{
		Exception e = new NullPointerException("test");
		handler.handle(e);
		assertEquals(Thread.currentThread(), uncaughtHandler.t);
		assertEquals(e, uncaughtHandler.e);
		uncaughtHandler.e = null;
		uncaughtHandler.t  = null;
		sleep = true;
		
		Runnable r = new Runnable() {
			public void run()
			{
				// triggers IllegalArgumentException
				JList list = new JList((ListModel)null);
			}
		};
		SwingUtilities.invokeLater(r);
		synchronized(lock) {
			if (sleep) {
				lock.wait();
			}
		}
		assertEquals(IllegalArgumentException.class, uncaughtHandler.e.getClass());
	}
	
	private class TestUncaughtExceptionHandler implements UncaughtExceptionListener
	{

		Thread t;
		Throwable e;
		
		public void uncaughtException(Thread t, Throwable e) {
			this.t = t;
			this.e = e;
			synchronized(lock) {
				sleep = false;
				lock.notify();
			}
		}
		
	}
	
}
