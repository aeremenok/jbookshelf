package org.xnap.commons.gui.dnd;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.TransferHandler;
import junit.framework.TestCase;


public class AbstractFileTransferHandlerTest extends TestCase 
{
	
	TestFileTransferHandler fileHandler;
	JTextField textField;

	@Override
	protected void setUp() throws Exception 
	{
		fileHandler = new TestFileTransferHandler();
		textField = new JTextField();
	}
	
	public void testCanImportFilesandURIS()
	{
		assertTrue(fileHandler.canImport(textField, new DataFlavor[] { DataFlavor.javaFileListFlavor }));
		assertTrue(fileHandler.canImport(textField, new DataFlavor[] { AbstractFileTransferHandler.linuxURIFlavor }));
	}
	
	public void testCannotImportStrings()
	{
		assertFalse(fileHandler.canImport(textField, new DataFlavor[] { DataFlavor.stringFlavor }));
	}
	
	public void testOnlyAllowCopyingOfFiles()
	{
		assertEquals(TransferHandler.COPY, fileHandler.getSourceActions(textField));
	}
	
	public void testImportData()
	{
		List<File> empty = Collections.emptyList();
		fileHandler.files = null;
		assertFalse(fileHandler.importData(textField, new FileTransferable(empty)));
		assertNull(fileHandler.files);
		
		List<File> files = Arrays.asList(new File[] {
			new File("/absolute/path/to file"),
			new File("/file having/non-ascii chars#??"),
		});
		assertTrue(fileHandler.importData(textField, new FileTransferable(files)));
		assertEquals(files, fileHandler.files);
	}
	
	private static class TestFileTransferHandler extends AbstractFileTransferHandler
	{
		List<File> files;

		@Override
		protected Transferable createTransferable(JComponent c) 
		{
			return null;
		}

		@Override
		public boolean importFiles(JComponent comp, List<File> files) 
		{
			this.files = files;
			return true;
		}
	}
	
	
}
