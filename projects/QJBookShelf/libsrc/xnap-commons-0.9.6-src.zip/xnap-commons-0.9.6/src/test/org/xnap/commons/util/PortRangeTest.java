package org.xnap.commons.util;

import java.util.Iterator;
import junit.framework.TestCase;


public class PortRangeTest extends TestCase {

	public void testAddIntInt()
	{
		PortRange range = new PortRange();
		assertEquals(false, range.contains(1000));
		range.add(1000, 1000);
		assertEquals(true, range.contains(1000));		
		assertEquals(false, range.contains(10));
		assertEquals(false, range.contains(11));
		assertEquals(false, range.contains(12));
		range.add(10, 12);
		assertEquals(true, range.contains(10));
		assertEquals(true, range.contains(11));
		assertEquals(true, range.contains(12));
		assertEquals(true, range.contains(1000));
	}

	public void testAddInt()
	{
		PortRange range = new PortRange();
		assertEquals(false, range.contains(2000));
		range.add(1);
		assertEquals(true, range.contains(1));
		assertEquals(false, range.contains(10));
		range.add(10);
		assertEquals(true, range.contains(10));
		assertEquals(true, range.contains(1));
		try {
			range.add(PortRange.MAX_PORT + 1);
			assertTrue("Expected excpetion", false);
		} catch (IllegalArgumentException e) {}
		try {
			range.add(0);
			assertTrue("Expected excpetion", false);
		} catch (IllegalArgumentException e) {}
	}

	public void testAddString()
	{
		PortRange range = new PortRange();
		assertEquals(false, range.contains(2000));
		range.add("2000");
		assertEquals(false, range.contains(10));
		assertEquals(false, range.contains(11));
		assertEquals(false, range.contains(12));
		range.add("10-12");
		assertEquals(true, range.contains(10));
		assertEquals(true, range.contains(11));
		assertEquals(true, range.contains(12));
	}

	public void testIterator()
	{
		PortRange range = new PortRange();
		range.add(25);
		range.add(18, 20);
		Iterator it = range.iterator();
		assertEquals(25, it.next());
		assertEquals(18, it.next());
		assertEquals(19, it.next());
		assertEquals(20, it.next());
	}

	public void testSize()
	{
		PortRange range = new PortRange();
		assertEquals(0, range.size());
		range.add(1024);
		assertEquals(1, range.size());
		range.add(18, 20);
		assertEquals(4, range.size());
		range.add(25);
		assertEquals(5, range.size());
	}

	public void testToString()
	{
		PortRange range = new PortRange();
		assertEquals("", range.toString());
		range.add(1024);
		assertEquals("1024", range.toString());
		range.add(18, 20);
		assertEquals("18-20;1024", range.toString());
		range.add(25);
		assertEquals("18-20;25;1024", range.toString());
		range.add(16, 17);
		assertEquals("16-20;25;1024", range.toString());
	}
}
