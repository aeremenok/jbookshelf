package org.xnap.commons.gui.table;

import junit.framework.TestCase;
import org.xnap.commons.util.StringHelper;

public class FileSizeCellRendererTest extends TestCase {

	public void testSetValue()
	{
		FilesizeCellRenderer r = new FilesizeCellRenderer();
		r.setValue(null);
		assertEquals("", r.getText());
		assertEquals(null, r.getToolTipText());
		
		long[] values = { 0, 10, 240394545, 1024, 8945405, -1};
		
		for (long l : values) {
			r.setValue(l);
			assertEquals(StringHelper.formatSize(l), r.getText());
			assertTrue(r.getToolTipText().indexOf(String.format("%,d", l)) != -1);
		}
	}
	
}
