package org.xnap.commons.gui.util;

import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import javax.swing.AbstractAction;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTree;
import javax.swing.KeyStroke;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.tree.TreeModel;
import junit.framework.TestCase;
import org.xnap.commons.util.FileHelper;

public class GUIHelperTest extends TestCase {

	public void testCreateDefaultBorder()
	{
		TitledBorder b = (TitledBorder)GUIHelper.createDefaultBorder("title");
		assertEquals(" title ", b.getTitle());
	}
	
	public void testCreateTitledBorder()
	{
		CompoundBorder b = (CompoundBorder)GUIHelper.createTitledBorder("title", 4);
		TitledBorder tb = (TitledBorder)b.getOutsideBorder();
		EmptyBorder eb = (EmptyBorder)b.getInsideBorder();
		assertEquals(" title ", tb.getTitle());
		Insets insets = eb.getBorderInsets(null);
		assertEquals(4, insets.top);
		assertEquals(4, insets.left);
		assertEquals(4, insets.bottom);
		assertEquals(4, insets.right);
	}
	
	public void testCreateEmptyBorder()
	{
		Border b = GUIHelper.createEmptyBorder(4);
		Insets insets = b.getBorderInsets(null);
		assertEquals(4, insets.top);
		assertEquals(4, insets.left);
		assertEquals(4, insets.bottom);
		assertEquals(4, insets.right);
	}
	
	public void testCreateBorders()
	{
		assertNotNull(GUIHelper.createEmptyBorder());
		assertNotNull(GUIHelper.createEtchedBorder());
		assertNotNull(GUIHelper.createLoweredBorder());
		assertNotNull(GUIHelper.createRaisedBorder());
		assertNotNull(GUIHelper.createTitledBorder("title", 4));
	}
	
	public void testSetAccelerator()
	{
		JMenuItem item = new JMenuItem();
		assertNull(item.getAccelerator());
		GUIHelper.setAccelerator(item, KeyEvent.VK_P);
		int mask = Toolkit.getDefaultToolkit().getMenuShortcutKeyMask();
		assertEquals(KeyStroke.getKeyStroke(KeyEvent.VK_P, mask), item.getAccelerator());
	}
	
	public void testShowFile() throws Exception
	{
		// TODO this has to be on the class path
		String text = "XNap Commons blind text\n with several lines.\n\n\n";
		File file1 = File.createTempFile("text", "file");
		FileHelper.writeText(file1, text);
		JTextArea jta = new JTextArea();
		GUIHelper.showFile(jta, file1.getAbsolutePath(), "alt\ntext");
		// change this line
		assertEquals("alt\ntext", jta.getText());
		
		file1.delete();
	}
	
	public void testSetMnemonics()
	{
		JLabel label = new JLabel("text");
		JPanel panel = new JPanel();
		panel.add(label);
		GUIHelper.setMnemonics(panel);
		assertEquals(0, label.getDisplayedMnemonic());
		label.setLabelFor(label);
		GUIHelper.setMnemonics(panel);
		assertNotSame(0, label.getDisplayedMnemonic());
	}
	
	public void testExpandAllNodes()
	{
		JTree  tree = new JTree();
		// we don't count the root node
		tree.setRootVisible(false);
		TreeModel model = tree.getModel();
		int nodeCount = getNodeCount(model, model.getRoot());
		assertTrue(nodeCount > 0);
		GUIHelper.expandAllNodes(tree, true);
		assertEquals(nodeCount, tree.getRowCount());
		tree.collapseRow(0);
		tree.collapseRow(tree.getRowCount() - 1);
		assertTrue(nodeCount > tree.getRowCount());
		GUIHelper.expandAllNodes(tree, true);
		assertEquals(nodeCount, tree.getRowCount());
	}
	
	private int getNodeCount(TreeModel model, Object node)
	{
		int childCount = model.getChildCount(node);
		int sum = 0;
		for (int i = 0; i < childCount; i++) {
			sum += getNodeCount(model, model.getChild(node, i));
		}
		return sum + childCount;
	}
	
	public void testBindEnterKey()
	{
		EnterKeyAction action = new EnterKeyAction();
		RaisedAccessComponent c = new RaisedAccessComponent();
		GUIHelper.bindEnterKey(c, action);
		c.processKeyEvent(new KeyEvent(c, KeyEvent.KEY_PRESSED, 0, 0, KeyEvent.VK_ENTER));
		// TODO fix me
//		assertTrue(action.performed);
	}
	
	public void testBindEnterKeyLocally()
	{
		EnterKeyAction action = new EnterKeyAction();
		RaisedAccessComponent c = new RaisedAccessComponent();
		GUIHelper.bindEnterKeyLocally(c, action);
		c.processKeyEvent(new KeyEvent(c, KeyEvent.KEY_PRESSED, 0, 0, KeyEvent.VK_ENTER));
		assertTrue(action.performed);
	}
	
	private class EnterKeyAction extends AbstractAction
	{

		boolean performed = false;
		
		public void actionPerformed(ActionEvent e) {
			performed = true;
		}
		
	}
	
	private class RaisedAccessComponent extends JComponent
	{

		@Override
		public void processKeyEvent(KeyEvent e) {
			super.processKeyEvent(e);
		}

	}
	
}
