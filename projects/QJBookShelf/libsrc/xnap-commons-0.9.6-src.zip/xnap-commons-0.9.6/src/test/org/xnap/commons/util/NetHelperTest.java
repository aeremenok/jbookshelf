package org.xnap.commons.util;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import junit.framework.TestCase;


public class NetHelperTest extends TestCase {

	public void testToIPLong()
	{
		assertEquals("255.128.1.10", NetHelper.toIPAddressLittleEndian(0x0A0180FF));
		assertEquals("0.0.0.0", NetHelper.toIPAddressLittleEndian(0));
		assertEquals("1.0.0.127", NetHelper.toIPAddressLittleEndian(0x7F000001));
	}

	public void testToIPHiFirst()
	{
		assertEquals("10.1.128.255", NetHelper.toIPAddressBigEndian(0x0A0180FF));
		assertEquals("0.0.0.0", NetHelper.toIPAddressBigEndian(0));
		assertEquals("127.0.0.1", NetHelper.toIPAddressBigEndian(0x7F000001));
	}
	/*
	// TODO fix me
	public void testEnableHttpProxy() throws Exception
	{
		NetHelper.enableHttpProxy("localhost", 9889);
		HttpProxy proxy = new HttpProxy(9889);
		Thread t = new Thread(proxy);
		t.start();
		URL url = new URL("http://xnap-commons.sf.net/");
		URLConnection con = url.openConnection();
		synchronized(proxy.lock) {
			if (proxy.sleep) {
				proxy.lock.wait(30 * 1000);
//				assertTrue(proxy.gotAConnection);
			}
		}
		
	}
	*/
	private class HttpProxy implements Runnable
	{

		ServerSocket socket;
		volatile boolean gotAConnection = false;
		volatile boolean sleep = true;
		Object lock = new Object();
		
		public HttpProxy(int port) throws IOException
		{
			socket = new ServerSocket(port);
			socket.setSoTimeout(5 * 1000);
		}
		
		public void run() {
			try {
				Socket s = socket.accept();
				synchronized (lock) {
					gotAConnection = true;
					sleep = false;
					lock.notify();
				}
			} catch (IOException e) {
				synchronized (lock) {
					gotAConnection = false;
					sleep = false;
					lock.notify();
				}
			}
		}
		
	}
}
