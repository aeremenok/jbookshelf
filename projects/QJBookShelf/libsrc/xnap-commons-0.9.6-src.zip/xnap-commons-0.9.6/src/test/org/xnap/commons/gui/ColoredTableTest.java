package org.xnap.commons.gui;

import java.awt.Color;
import java.awt.Component;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import junit.framework.TestCase;

public class ColoredTableTest extends TestCase {
	
	private ColoredTable table;
	
	@Override
	protected void setUp() throws Exception 
	{
		table = new ColoredTable();
	}

	public void testGetBackgroundColor()
	{
		assertNotSame(table.getBackgroundColor(0), table.getBackgroundColor(3));
	}
	
	public void testUpdateUI() throws Exception
	{
		Color even  = table.getBackgroundColor(2);
		Color odd = table.getBackgroundColor(1);
		assertNotSame(even, odd);
		LookAndFeelInfo[] infos = UIManager.getInstalledLookAndFeels();
		LookAndFeel current = UIManager.getLookAndFeel();
		// find look & feel different from current one and set it
		LookAndFeelInfo newLook = null;
		for (LookAndFeelInfo info : infos) {
			if (!info.getClassName().equals(current.getClass().getName())) {
				newLook = info;
				break;
			}
		}
		
		if (newLook == null) {
			return;
		}
		UIManager.setLookAndFeel(newLook.getClassName());
		// update table
		table.updateUI();
		assertNotSame(even, table.getBackgroundColor(2));
		assertNotSame(odd, table.getBackgroundColor(1));
		assertNotSame(table.getBackgroundColor(2), table.getBackgroundColor(1));
	}
	
	public void testPrepareRenderer()
	{
		table.setModel(new DefaultTableModel(4, 4));
		Component even = table.prepareRenderer(new DefaultTableCellRenderer(), 2, 0);
		Component odd = table.prepareRenderer(new DefaultTableCellRenderer(), 3, 0);
		assertEquals(table.getBackgroundColor(2), even.getBackground());
		assertEquals(table.getBackgroundColor(3), odd.getBackground());
	}
	
}
