package org.xnap.commons.gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.util.Arrays;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JPanel;
import junit.framework.TestCase;

public class DefaultDialogTest extends TestCase {

	public void testSetMainComponent()
	{
		DefaultDialog dialog = new DefaultDialog();
		JPanel panel = new JPanel();
		dialog.setMainComponent(panel);
		JPanel mainPanel = dialog.getMainPanel();
		assertTrue(Arrays.asList(mainPanel.getComponents()).contains(panel));
	}
	
	public void testButtonIsThere()
	{
		// okay 
		DefaultDialog dialog = new DefaultDialog(DefaultDialog.BUTTON_OKAY);
		assertEquals(dialog.getOkayAction(), getAction(dialog));
		
		// apply
		dialog = new DefaultDialog(DefaultDialog.BUTTON_APPLY);
		assertEquals(dialog.getApplyAction(), getAction(dialog));
		
		// cancel
		dialog = new DefaultDialog(DefaultDialog.BUTTON_CANCEL);
		assertEquals(dialog.getCancelAction(), getAction(dialog));
		
		// close
		dialog = new DefaultDialog(DefaultDialog.BUTTON_CLOSE);
		assertEquals(dialog.getCloseAction(), getAction(dialog));
	}
	
	private Action getAction(DefaultDialog dialog)
	{
		Component[] components = dialog.getButtonPanel().getComponents();
		for (Component c : components) {
			if (c instanceof AbstractButton) {
				return ((AbstractButton)c).getAction();
			}
		}
		return null;
	}
	
	public void testButtonCodeConstructor()
	{
		// zero buttons
		DefaultDialog dialog = new DefaultDialog(0);
		assertEquals(0, getButtonCount(dialog));
		
		List<Integer> buttons = Arrays.asList(new Integer[] { 1, 2, 4, 8 });
		for (int i = 0; i < 4; i++) {
			for (int j = i; j < 4; j++) {
				int buttonCode = getButtonCode(buttons.subList(i, j));
				dialog = new DefaultDialog(buttonCode);
				assertEquals(j - i, getButtonCount(dialog));
			}
		}
	}
	
	public void testActions()
	{
		TestDialog dialog = new TestDialog();
		perform(dialog, dialog.getCancelAction());
		assertFalse(dialog.isOkay());
		assertTrue(dialog.closed);
		perform(dialog, dialog.getContextHelpAction());
		assertTrue(dialog.contextHelp);
		perform(dialog, dialog.getHelpAction());
		assertTrue(dialog.help);
		dialog.closed = false;
		perform(dialog, dialog.getCloseAction());
		assertTrue(dialog.closed);
		dialog.closed = false;
		perform(dialog, dialog.getOkayAction());
		assertTrue(dialog.isOkay());
		assertTrue(dialog.closed);
		dialog.applied = false;
		perform(dialog, dialog.getApplyAction());
		assertTrue(dialog.applied);
	}
	
	private void perform(DefaultDialog dialog, Action a)
	{
		a.actionPerformed(new ActionEvent(dialog, 0, ""));
	}
	
	private int getButtonCode(List<Integer> codes) 
	{
		int code = 0;
		for (int i : codes) {
			code |= i;
		}
		return code;
	}
	
	private int getButtonCount(DefaultDialog dialog)
	{
		Component[] components = dialog.getButtonPanel().getComponents();
		int buttonCount = 0;
		for (Component c : components) {
			if (c instanceof AbstractButton) {
				++buttonCount;
			}
		}
		return buttonCount;
	}
	
	private class TestDialog extends DefaultDialog
	{

		boolean applied;
		boolean closed;
		boolean contextHelp;
		boolean help;
		
		@Override
		public boolean apply() {
			applied = true;
			return super.apply();
		}

		@Override
		public void close() {
			closed = true;
			super.close();
		}

		@Override
		public void contextHelp() {
			contextHelp = true;
			super.contextHelp();
		}

		@Override
		public void help() {
			help = true;
			super.help();
		}
	}
}
