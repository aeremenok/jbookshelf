package org.xnap.commons.settings;

import javax.swing.JTextField;
import junit.framework.TestCase;
import org.xnap.commons.gui.completion.AutomaticCompletionMode;
import org.xnap.commons.gui.completion.Completion;
import org.xnap.commons.gui.completion.ShortAutomaticCompletionMode;

public class CompletionModeSettingsTest extends TestCase {

	private Completion comp;
	SettingResource backend;
	
	@Override
	public void setUp()
	{
		comp = new Completion(new JTextField());
		backend = new PropertyResource();
	}
	
	public void testSetting()
	{
		CompletionModeSetting setting = new CompletionModeSetting
			(backend, "completionSetting", AutomaticCompletionMode.class, comp);
		assertEquals(AutomaticCompletionMode.class, comp.getMode().getClass());
		
		comp.setMode(new ShortAutomaticCompletionMode());
		assertEquals(ShortAutomaticCompletionMode.class.getName(),
				setting.getValue());
		
		setting.revert();
		assertEquals(AutomaticCompletionMode.class, comp.getMode().getClass());
	}
	
}
