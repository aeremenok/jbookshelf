package org.xnap.commons.gui;

import javax.swing.JTextField;
import junit.framework.TestCase;

public class EraseTextFieldActionTest extends TestCase {

	public void testActionPerformed()
	{
		JTextField textField = new JTextField();
		EraseTextFieldAction action = new EraseTextFieldAction(textField);
		textField.setText("foo");
		assertEquals("foo", textField.getText());
		action.actionPerformed(null);
		assertEquals("", textField.getText());
	}
	
	public void testSetGet()
	{
		JTextField textField = new JTextField();
		EraseTextFieldAction action = new EraseTextFieldAction();

		textField.setText("foo");
		action.actionPerformed(null);
		assertEquals("foo", textField.getText());
		assertEquals(null, action.getTextField());
		
		action.setTextField(textField);
		action.actionPerformed(null);
		assertEquals("", textField.getText());
		
		assertEquals(textField, action.getTextField());
	}
}
