package org.xnap.commons.io;

import java.awt.Component;

public class TestProgressMonitor implements ProgressMonitor 
{

	private long totalSteps = 0;
	private long value = 0;
	private String text;
	private boolean cancelEnabled;
	private boolean cancelled;
	private Component component;
	
	public boolean isCancelled() 
	{
		return cancelEnabled && cancelled;
	}

	public void setCancelEnabled(boolean enabled) 
	{
		cancelEnabled = enabled;
	}
	
	public boolean isCancelEnabled()
	{
		return cancelEnabled;
	}

	public void setTotalSteps(long max) 
	{
		totalSteps = max;
	}
	
	public long getTotalSteps()
	{
		return totalSteps;
	}

	public void setValue(long value) 
	{
		this.value = value;
	}
	
	public long getValue()
	{
		return value;
	}

	public void setText(String text) 
	{
		this.text = text;
	}
	
	public String getText()
	{
		return text;
	}

	public void work(long amount) 
	{
		value += amount;
	}

	public Component getComponent()
	{
		return component;
	}
	
	public void setComponent(Component component)
	{
		this.component = component;
	}

}
