package org.xnap.commons.io;

import java.awt.Component;
import javax.swing.JPanel;

public class SubTaskProgressMonitorTest extends GenericProgressMonitorTest<SubTaskProgressMonitor> {

	@Override
	protected SubTaskProgressMonitor createProgressMonitor()
	{
		MyProgessMonitor myMonitor = new MyProgessMonitor();
		return new SubTaskProgressMonitor(myMonitor, 0, 0);
	}
	
	@Override
	protected long getValue(SubTaskProgressMonitor monitor)
	{
		return monitor.getValue();
	}
	
	public void testNullConstructor()
	{
		try {
			new SubTaskProgressMonitor(null, 0, 0);
			assertTrue("Expected exception", false);
		} catch (IllegalArgumentException e) {}
	}

	public void testNegativeConstructor1()
	{
		MyProgessMonitor monitor = new MyProgessMonitor();
		try {
			new SubTaskProgressMonitor(monitor, -1, 0);
			assertTrue("Expected exception", false);
		} catch (IllegalArgumentException e) {}
	}

	public void testNegativeConstructor2()
	{
		MyProgessMonitor monitor = new MyProgessMonitor();
		try {
			new SubTaskProgressMonitor(monitor, 0, -1);
			assertTrue("Expected exception", false);
		} catch (IllegalArgumentException e) {}
	}

	public void testDone()
	{
		MyProgessMonitor monitor = new MyProgessMonitor();
		monitor.setTotalSteps(100);
		monitor.setValue(0);
		
		SubTaskProgressMonitor subMonitor 
			= new SubTaskProgressMonitor(monitor, 10, 100);
		subMonitor.work(10);
		assertEquals(1, monitor.value);
		
		subMonitor.done();
		assertEquals(10, monitor.value);
		
		subMonitor.done();
		assertEquals(10, monitor.value);
		
		try {
			subMonitor.work(10);
			assertTrue("Expected exception", false);
		} catch (IllegalStateException e) {}
	}
	
	public void testWork()
	{
		MyProgessMonitor monitor = new MyProgessMonitor();
		monitor.setTotalSteps(100);
		monitor.setValue(0);
		
		SubTaskProgressMonitor subMonitor 
			= new SubTaskProgressMonitor(monitor, 10, 100);
		subMonitor.work(10);
		assertEquals(1, monitor.value);

		subMonitor.work(1);
		assertEquals(1, monitor.value);

		subMonitor.work(9);
		assertEquals(2, monitor.value);

		subMonitor.work(0);
		assertEquals(2, monitor.value);
	}

	public void testSetValue()
	{
		MyProgessMonitor monitor = new MyProgessMonitor();
		monitor.setTotalSteps(100);
		monitor.setValue(0);
		
		SubTaskProgressMonitor subMonitor 
			= new SubTaskProgressMonitor(monitor, 10, 100);
		subMonitor.setValue(10);
		assertEquals(1, monitor.value);

		subMonitor.setValue(11);
		assertEquals(1, monitor.value);

		subMonitor.setValue(20);
		assertEquals(2, monitor.value);
		
		subMonitor.setValue(20);
		assertEquals(2, monitor.value);
	}

	public void testSetTotalSteps()
	{
		MyProgessMonitor monitor = new MyProgessMonitor();	
		SubTaskProgressMonitor subMonitor 
			= new SubTaskProgressMonitor(monitor, 10, 100);
		subMonitor.work(10);
		
		try {
			subMonitor.setTotalSteps(50);
			assertTrue("Expected exception", false);
		} catch (IllegalStateException e) {}

		try {
			subMonitor.setTotalSteps(200);
			assertTrue("Expected exception", false);
		} catch (IllegalStateException e) {}
	}

	public void testCancel()
	{
		MyProgessMonitor monitor = new MyProgessMonitor();
		monitor.cancelEnabled = true;
		monitor.cancelled = false;
		
		SubTaskProgressMonitor subMonitor 
			= new SubTaskProgressMonitor(monitor, 10, 100);
		assertEquals(false, subMonitor.isCancelled());
		monitor.cancelled = true;
		assertEquals(true, subMonitor.isCancelled());
	}

	public void testCancelEnabled()
	{
		MyProgessMonitor monitor = new MyProgessMonitor();
		monitor.cancelEnabled = true;
		
		SubTaskProgressMonitor subMonitor 
			= new SubTaskProgressMonitor(monitor, 10, 100);
		subMonitor.setCancelEnabled(false);
		assertEquals(false, monitor.cancelEnabled);
	}
	
	public void testSetText()
	{
		MyProgessMonitor monitor = new MyProgessMonitor();
		SubTaskProgressMonitor subMonitor 
			= new SubTaskProgressMonitor(monitor, 10, 100);
		subMonitor.setText("foo");
		assertEquals("foo", monitor.text);
		subMonitor.setText("bar");
		assertEquals("bar", monitor.text);
		subMonitor.setText(null);
		assertEquals(null, monitor.text);
	}
	
	public void testGetComponent()
	{
		Component c = new JPanel();
		MyProgessMonitor monitor = new MyProgessMonitor();
		monitor.setComponent(c);
		SubTaskProgressMonitor subMonitor 
			= new SubTaskProgressMonitor(monitor, 10, 100);
		assertEquals(c, subMonitor.getComponent());
	}

	public class MyProgessMonitor implements ProgressMonitor {

		private long totalSteps;
		private long value;
		private String text;
		private boolean cancelled;
		private boolean cancelEnabled;
		private Component component;

		public boolean isCancelled()
		{
			return this.cancelled;
		}

		public void setCancelEnabled(boolean enabled)
		{
			this.cancelEnabled = enabled;
		}

		public void setTotalSteps(long max)
		{
			this.totalSteps = max;
		}

		public void setValue(long value)
		{
			this.value = value;
		}

		public void setText(String text)
		{
			this.text = text;
		}

		public void work(long amount)
		{
			this.value += amount;
		}
		
		public Component getComponent()
		{
			return component;
		}
		
		public void setComponent(Component component)
		{
			this.component = component;
		}

	}

}
