package org.xnap.commons.gui.dnd;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JTextField;
import junit.framework.TestCase;

public class FileTransferableTest extends TestCase 
{

	public void testSupportedFlavors()
	{
		FileTransferable transferable = new FileTransferable(new ArrayList<File>());
		assertTrue(Arrays.asList(transferable.getTransferDataFlavors()).contains(DataFlavor.javaFileListFlavor));
		assertTrue(Arrays.asList(transferable.getTransferDataFlavors()).contains(AbstractFileTransferHandler.linuxURIFlavor));
		assertEquals(2, transferable.getTransferDataFlavors().length);
	}
	
	public void testIsDataFlavorSupported()
	{
		FileTransferable transferable = new FileTransferable(new ArrayList<File>());
		assertTrue(transferable.isDataFlavorSupported(DataFlavor.javaFileListFlavor));
		assertTrue(transferable.isDataFlavorSupported(AbstractFileTransferHandler.linuxURIFlavor));
	}
	
	public void testGetTransferData() throws Exception
	{
		List<File> files = Arrays.asList(new File[] {
				new File("/test"),
				new File("/path/to/testfile"),
		});
		FileTransferable transferable = new FileTransferable(files);
		assertEquals(files, transferable.getTransferData(DataFlavor.javaFileListFlavor));
		
		TestFileTransferHandler handler = new TestFileTransferHandler();
		// TODO only works with files with absolute paths
		assertEquals(files, handler.getFileList(new JTextField(), transferable));
		// TODO empty list causes null to be returned and not empty list
		
		try {
			Object o = transferable.getTransferData(DataFlavor.imageFlavor);
			fail("Exception expected");
		}
		catch (UnsupportedFlavorException ufe) {
		}
	}
	
	private static class TestFileTransferHandler extends AbstractFileTransferHandler
	{
		List<File> files;

		@Override
		protected Transferable createTransferable(JComponent c) 
		{
			return null;
		}

		@Override
		public boolean importFiles(JComponent comp, List<File> files) 
		{
			this.files = files;
			return true;
		}
		
		public List<File> getFileList(JComponent comp, Transferable t)
		{
			files = null;
			importData(comp, new ProxyTransferable(t));
			return files;
		}
		
		private static class ProxyTransferable implements Transferable
		{
			
			Transferable proxy;
			
			ProxyTransferable(Transferable t)
			{
				proxy = t;
			}

			public DataFlavor[] getTransferDataFlavors() 
			{
				return new DataFlavor[] { AbstractFileTransferHandler.linuxURIFlavor };
			}

			public boolean isDataFlavorSupported(DataFlavor flavor) 
			{
				return AbstractFileTransferHandler.linuxURIFlavor.equals(flavor);
			}

			public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException 
			{
				return proxy.getTransferData(flavor);
			}
			
		}
		
	}
	
}
