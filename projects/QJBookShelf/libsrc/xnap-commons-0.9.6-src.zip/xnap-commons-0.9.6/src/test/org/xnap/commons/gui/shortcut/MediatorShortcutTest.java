package org.xnap.commons.gui.shortcut;

import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.lang.ref.WeakReference;
import javax.swing.AbstractAction;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import junit.framework.TestCase;
import org.xnap.commons.settings.KeyStrokeSetting;
import org.xnap.commons.settings.PropertyResource;

public class MediatorShortcutTest extends TestCase 
{

	private PropertyResource backend;
	private KeyStrokeSetting setting;
	private MediatorShortcut shortcut;
	private TestAction action;
	private RaisedAccessPanel panel;
	
	@Override
	protected void setUp() throws Exception 
	{
		backend = new PropertyResource();
		KeyStroke keyStroke  = KeyStroke.getKeyStroke(KeyEvent.VK_K, KeyEvent.CTRL_MASK);
		setting = new KeyStrokeSetting(backend, "shortcut", keyStroke);
		action = new TestAction();
		panel = new RaisedAccessPanel();
		shortcut = new MediatorShortcut(setting, action, panel);
	}

	public void testKeyStrokeIsSet()
	{
		KeyStroke ks = setting.getValue();
		JComponent c = shortcut.getComonent();
		InputMap map = c.getInputMap();
		assertNotNull(map.get(ks));
	}
	
	public void testKeyStrokeIsUpdated()
	{
		KeyStroke oldKs = setting.getValue();
		JComponent c = shortcut.getComonent();
		InputMap map = c.getInputMap();
		assertNotNull(map.get(oldKs));
		KeyStroke newKs = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, KeyEvent.CTRL_MASK);
		assertNotSame(newKs, oldKs);
		assertNull(map.get(newKs));
		setting.setValue(newKs);
		assertNotNull((map.get(newKs)));
		assertNull(map.get(oldKs));
	}
	
	public void testSetEnabled()
	{
		InputMap map = shortcut.getComonent().getInputMap();
		shortcut.setEnabled(true);
		assertTrue(shortcut.isEnabled());
		assertNotNull(map.get(setting.getValue()));
		shortcut.setEnabled(false);
		assertFalse(shortcut.isEnabled());
		assertNull(map.get(setting.getValue()));
		shortcut.setEnabled(true);
		assertNotNull(map.get(setting.getValue()));
	}
	
	public void testActionPerformed()
	{
		testAction(true);
	}
	
	public void testDisabledActionPerformed()
	{
		testAction(false);
	}
	
	private void testAction(boolean enabled)
	{
		shortcut.setEnabled(enabled);
		KeyStroke ks = setting.getValue();
		KeyEvent ke = new KeyEvent(shortcut.getComonent(), KeyEvent.KEY_PRESSED, 0, ks.getModifiers(), ks.getKeyCode());
		assertEquals(ks, KeyStroke.getKeyStrokeForEvent(ke));
		action.performed = false;
		panel.processKeyEvent(ke);
		assertEquals(enabled, action.performed);
	}
	
	public void testGetComponent()
	{
		assertEquals(panel, shortcut.getComonent());
	}
	
	public void testGetAction()
	{
		assertEquals(action, shortcut.getAction());
	}
	
	public void testGetSetting()
	{
		assertEquals(setting, shortcut.getSetting());
	}
	
	public void testGarbageCollection()
	{
		WeakReference<MediatorShortcut> weakRef = 
			new WeakReference<MediatorShortcut>(new MediatorShortcut(setting, action, panel));
		System.gc();
		assertNotNull(weakRef.get());
		weakRef.get().setEnabled(false);
		System.gc();
		assertNull(weakRef.get());
	}
	
	private class TestAction extends AbstractAction
	{

		boolean performed;
		ActionEvent e;
		
		public void actionPerformed(ActionEvent e) 
		{
			performed = true;
			this.e = e;
		}
	}
	
	private static class RaisedAccessPanel extends JPanel
	{

		@Override
		public void processKeyEvent(KeyEvent e) 
		{
			super.processKeyEvent(e);
		}
		
	}
	
}
