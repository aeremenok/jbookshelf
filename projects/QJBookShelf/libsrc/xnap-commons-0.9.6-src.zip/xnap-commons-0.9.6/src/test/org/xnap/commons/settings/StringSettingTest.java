package org.xnap.commons.settings;


/**
 * @author Steffen Pingel
 */
public class StringSettingTest extends AbstractSettingTest<String> {

	public StringSettingTest()
	{
		super("bar", "foo", "baz");
	}

	@Override
	protected Setting<String> createSetting(SettingResource backend, String key, String defaultValue)
	{
		return new StringSetting(backend, key, defaultValue);
	}

	public void testValidCharsConstructor()
	{
		StringSetting setting = new StringSetting(backend, "test", null, "abc");
		setting.setValue("aabbcc");
		assertEquals(setting.getValue(), "aabbcc");
		assertIllegalArgumentException(setting, "abcd");
	}

	public void testMinLengthConstructor()
	{
		StringSetting setting = new StringSetting(backend, "test", null, "abc", 3);
		setting.setValue("aabbcc");
		assertEquals(setting.getValue(), "aabbcc");
		assertIllegalArgumentException(setting, "abcd");
		assertIllegalArgumentException(setting, "ab");
	}

}
