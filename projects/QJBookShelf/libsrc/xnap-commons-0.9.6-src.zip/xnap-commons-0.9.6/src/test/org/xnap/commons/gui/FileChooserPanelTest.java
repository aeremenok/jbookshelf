package org.xnap.commons.gui;

import java.awt.Canvas;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.io.File;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.TransferHandler;
import junit.framework.TestCase;
import org.xnap.commons.gui.dnd.DefaultTextFieldFileTransferHandler;
import org.xnap.commons.gui.dnd.FileTransferable;

public class FileChooserPanelTest extends TestCase {

	private FileChooserPanel panel;
	
	@Override
	public void setUp()
	{
		panel = new FileChooserPanel(20);
	}
	
	public void testGetSetFile()
	{
		File testFile = new File("/test/testfile");
		panel.setFile(testFile);
		assertEquals(testFile, panel.getFile());
		
		panel.setFile(null);
		assertNull(panel.getFile());
	}
	
	public void testGetCompletion()
	{
		assertNotNull(panel.getCompletion());
	}
	
	public void testGetSetDialogParent()
	{
		Canvas c = new Canvas();
		panel.setDialogParent(c);
		assertEquals(c, panel.getDialogParent());
	}
	
	public void testSetEnabled()
	{
		panel.setEnabled(false);
		assertFalse(panel.isEnabled());
		assertFalse(panel.getTextField().isEnabled());
		assertFalse(panel.getFileChooserAction().isEnabled());
		panel.setEnabled(true);
		assertTrue(panel.isEnabled());
		assertTrue(panel.getTextField().isEnabled());
		assertTrue(panel.getFileChooserAction().isEnabled());
	}
	
	@SuppressWarnings("unchecked")
	public void testCreateTransferable() throws Exception
	{
		File testFile = new File("/test/todrag");
		panel.setFile(testFile);
		DefaultTextFieldFileTransferHandler.install(panel.getTextField());
		Transferable t = createTransferable(panel.getTextField());
		assertTrue(t.isDataFlavorSupported(DataFlavor.javaFileListFlavor));
		List<File> files = (List<File>) t.getTransferData(DataFlavor.javaFileListFlavor);
		assertEquals(testFile, files.get(0));
	}
	
	private Transferable createTransferable(JTextField textField) throws Exception
	{
		TransferHandler handler = textField.getTransferHandler();
		Method m = TransferHandler.class.getDeclaredMethod("createTransferable",
				new Class[] { JComponent.class });
		m.setAccessible(true);
		return (Transferable)m.invoke(handler, new Object[] { textField } );
	}
	
	public void testImportData()
	{
		File testFile = new File("/test/todrag");
		panel.setFile(null);
		DefaultTextFieldFileTransferHandler.install(panel.getTextField());
		TransferHandler handler = panel.getTextField().getTransferHandler();
		assertTrue(handler.importData(panel.getTextField(), 
				new FileTransferable(Collections.singletonList(testFile))));
		assertEquals(testFile, panel.getFile());
	}
	
	public void testSubClassing()
	{
		TestFileChooserPanel testPanel = new TestFileChooserPanel();
		testPanel.chooserReturnValue = false;
		testPanel.called = false;
		perform(testPanel);
		assertFalse(testPanel.called);
		testPanel.chooserReturnValue = true;
		perform(testPanel);
		assertTrue(testPanel.called);
	}
	
	private void perform(TestFileChooserPanel panel)
	{
		panel.getFileChooserAction().actionPerformed(new ActionEvent(panel, 0, ""));
	}
	
	private static class TestFileChooserPanel extends FileChooserPanel
	{
		
		boolean called;
		boolean chooserReturnValue = false;

		public TestFileChooserPanel() 
		{
			super(40);
		}
		
		@Override
		protected boolean showChooser()
		{
			return chooserReturnValue;
		}

		@Override
		protected void fileSelected(File file) 
		{
			called = true;
		}
		
	}
	
}
