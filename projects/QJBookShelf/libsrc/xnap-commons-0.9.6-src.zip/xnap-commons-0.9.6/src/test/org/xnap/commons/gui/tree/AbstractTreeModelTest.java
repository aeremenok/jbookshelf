package org.xnap.commons.gui.tree;

import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import junit.framework.TestCase;

public class AbstractTreeModelTest extends TestCase {

	private TestTreeModel model;
	private TreeModelHandler handler;
	
	@Override
	public void setUp()
	{
		model = new TestTreeModel("root");
		handler = new TreeModelHandler();
		model.addTreeModelListener(handler);
	}
	
	@Override
	protected void tearDown() throws Exception {
		model.removeTreeModelListener(handler);
	}

	public void testReload()
	{
		model.reload();
		TreeModelEvent e = getLastEvent();
		assertEquals(model.getRoot(), e.getPath()[0]);
	}
	
	private TreeModelEvent getLastEvent()
	{
		TreeModelEvent e = handler.e;
		handler.e = null;
		return e;
	}
	
	public void testAddSubRoot()
	{
		
	}
	
	private class TreeModelHandler implements TreeModelListener
	{
		TreeModelEvent e;

		public void treeNodesChanged(TreeModelEvent e) {
			this.e = e;
		}

		public void treeNodesInserted(TreeModelEvent e) {
			this.e = e;
		}

		public void treeNodesRemoved(TreeModelEvent e) {
			this.e = e;
		}

		public void treeStructureChanged(TreeModelEvent e) {
			this.e = e;
		}
		
	}
	
	private class TestTreeModel extends AbstractTreeModel
	{

		public TestTreeModel(String root) {
			super(root);
		}

		@Override
		public Object getChild(Object parent, int index) {
			return null;
		}

		@Override
		public int getChildCount(Object node) {
			return 0;
		}

		@Override
		public int getIndexOfChild(Object parent, Object child) {
			return 0;
		}

		@Override
		public boolean isLeaf(Object node) {
			return false;
		}
		
	}
	
}
