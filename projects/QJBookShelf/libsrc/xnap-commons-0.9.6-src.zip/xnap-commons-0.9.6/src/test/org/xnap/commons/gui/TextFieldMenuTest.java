package org.xnap.commons.gui;

import java.awt.Component;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.event.ActionEvent;
import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JMenu;
import javax.swing.JTextField;
import junit.framework.TestCase;
import org.xnap.commons.gui.TextFieldMenu.ClearAction;
import org.xnap.commons.gui.TextFieldMenu.CopyAction;
import org.xnap.commons.gui.TextFieldMenu.CutAction;
import org.xnap.commons.gui.TextFieldMenu.PasteAction;
import org.xnap.commons.gui.TextFieldMenu.SelectAllAction;

public class TextFieldMenuTest extends TestCase {

	private JTextField jtf;
	TextFieldMenu menu;

	
	@Override
	protected void setUp() throws Exception {
		jtf = new JTextField();
		menu = new TextFieldMenu();
	}

	public void testContainsAllActions()
	{
		assertTrue(menuContainsActionByClass(menu, CutAction.class));
		assertTrue(menuContainsActionByClass(menu, CopyAction.class));
		assertTrue(menuContainsActionByClass(menu, PasteAction.class));
		assertTrue(menuContainsActionByClass(menu, SelectAllAction.class));
		assertTrue(menuContainsActionByClass(menu, ClearAction.class));
	}
	
	private boolean menuContainsActionByClass(JMenu menu, Class c)
	{
		Component[] components = menu.getMenuComponents();
		for (Component comp : components) {
			if (comp instanceof AbstractButton) {
				Action a = ((AbstractButton)comp).getAction();
				if (a != null && a.getClass().equals(c)) {
					return true;
				}
			}
		}
		return false;
	}
	
	public void testCutAction() throws Exception
	{
		jtf.setText("text to cut");
		jtf.selectAll();
		perform(TextFieldMenu.cutAction);
		assertEquals("", jtf.getText());
		assertEquals("text to cut", getClipboardText()); 
	}
	
	public void testCopyAction() throws Exception
	{
		jtf.setText("text to copy");
		jtf.selectAll();
		perform(TextFieldMenu.copyAction);
		assertEquals("text to copy", jtf.getText());
		assertEquals("text to copy", getClipboardText());
	}
	
	public void testPasteAction() throws Exception
	{
		jtf.setText("");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents
			(new StringSelection("text to paste"), null);
		assertEquals("text to paste", getClipboardText());
		perform(TextFieldMenu.pasteAction);
		assertEquals("text to paste", jtf.getText());
	}
	
	public void testClearAction() throws Exception
	{
		jtf.setText("text to clear");
		perform(TextFieldMenu.clearAction);
		assertEquals("", jtf.getText());
	}
	
	private String getClipboardText() throws Exception
	{
		String cut = (String)Toolkit.getDefaultToolkit().getSystemClipboard().getContents
		(null).getTransferData(DataFlavor.stringFlavor);
		return cut;
	}
	
	public void testSelectAllAction()
	{
		jtf.setText("text to select");
		assertNull(jtf.getSelectedText());
		perform(TextFieldMenu.selectAllAction);
		assertEquals("text to select", jtf.getSelectedText());
	}
	
	private void perform(Action a)
	{
		a.actionPerformed(new ActionEvent(jtf, 0, ""));
	}
}
