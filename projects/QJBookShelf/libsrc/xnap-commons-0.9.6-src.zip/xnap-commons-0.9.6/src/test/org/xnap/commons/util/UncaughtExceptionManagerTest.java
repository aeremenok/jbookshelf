package org.xnap.commons.util;

import junit.framework.TestCase;


public class UncaughtExceptionManagerTest extends TestCase {

	private boolean caughtException;
	private UncaughtExceptionManager manager;

	@Override
	protected void setUp() throws Exception
	{
		super.setUp();
		
		manager = new UncaughtExceptionManager();
	}
	
	@Override
	protected void tearDown() throws Exception
	{
		super.tearDown();
		
		manager = null;
	}
	
	public void testExceptionListener() throws InterruptedException {      
		final RuntimeException exception = new RuntimeException();
		
        final RootThreadGroup tg = new RootThreadGroup("AppThreadGroup", manager);
        tg.installAsAWTExceptionHandler();

        final Thread runner = new Thread(tg, "MainThread") {
                public void run() {
                        throw exception; 
                }
        };
        
        manager.addExceptionListener(new UncaughtExceptionListener() {
			public void uncaughtException(Thread t, Throwable e)
			{
				assertEquals(t, runner);
				assertEquals(e, exception);
				caughtException = true;
			}        	
        });

        runner.start();
        runner.join();
        
        assertTrue(caughtException);
	}
}
