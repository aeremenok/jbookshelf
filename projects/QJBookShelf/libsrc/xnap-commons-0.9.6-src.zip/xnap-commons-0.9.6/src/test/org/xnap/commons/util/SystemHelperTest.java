package org.xnap.commons.util;

import junit.framework.TestCase;

public class SystemHelperTest extends TestCase {

	public void testHasMacOSXModalDialogBugIsTrue()
	{
		System.setProperty("os.name", "mac os x");
		System.setProperty("os.version", "10.1.0");
		// the SystemHelper class may have already been initialized 
		//assertTrue(SystemHelper.IS_MACOSX);
		//assertTrue(SystemHelper.hasMacOSXModalDialogBug());
	}
	
	public void testHasMacOSXModalDialogBugIsFalse() throws Exception
	{
		System.setProperty("os.name", "windows");
		System.setProperty("os.version", "10.2.0");
		// does not work since class is not loaded again
//		assertFalse(SystemHelper.IS_MACOSX);
//		assertFalse(SystemHelper.hasMacOSXModalDialogBug());
	}
	
}
