package org.xnap.commons.settings;

import java.awt.Color;
import java.io.Serializable;

/**
 * @author Steffen Pingel
 */
public class SerializableSettingTest extends AbstractSettingTest<Serializable> {

	public SerializableSettingTest()
	{
		super(new SerializableClass(1), Color.white, "foobar");
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Setting<Serializable> createSetting(SettingResource backend, String key, Serializable defaultValue)
	{
		return new SerializableSetting(backend, key, defaultValue);
	}

	private static class SerializableClass implements Serializable {
		
		private long id; 
		
		public SerializableClass(long id)
		{
			this.id = id;
		}

		public boolean equals(Object o)
		{
			if (o instanceof SerializableClass) {
				return ((SerializableClass)o).id == id;
			}
			return false;
		}

	}
	
}
