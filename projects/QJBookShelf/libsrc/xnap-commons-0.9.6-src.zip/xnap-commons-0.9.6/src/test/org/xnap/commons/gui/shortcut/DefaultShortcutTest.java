package org.xnap.commons.gui.shortcut;

import java.awt.event.KeyEvent;
import javax.swing.KeyStroke;
import junit.framework.TestCase;

public class DefaultShortcutTest extends TestCase {

	public void testSetKeyStroke()
	{
		KeyStroke ks = KeyStroke.getKeyStroke(KeyEvent.VK_F, KeyEvent.CTRL_MASK);
		DefaultShortcut shortcut = new DefaultShortcut(ks, "description");
		assertEquals(ks, shortcut.getKeyStroke());
		ks = KeyStroke.getKeyStroke(KeyEvent.VK_P, 0);
		shortcut.setKeyStroke(ks);
		assertEquals(ks, shortcut.getKeyStroke());
	}
	
}
