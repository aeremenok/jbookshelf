package org.xnap.commons.gui.tree;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import junit.framework.TestCase;

public class FileTreeModelTest extends TestCase {

	FileTreeModel model;
	TreeModelHandler listener;
	Object[] subroots = new Object[] { "subroot", new File("test"),
			"hello wordl", new File("xnap"), new File("xnap-commons")
	};
	File tempDir;

	@Override
	protected void setUp() throws Exception {
		model = new FileTreeModel("root");
		listener = new TreeModelHandler();
		model.addTreeModelListener(listener);
		tempDir = new File(System.getProperty("java.io.tmpdir"));
		model.addSubRoot(tempDir);
	}
	
	@Override
	protected void tearDown() throws Exception {
		model.removeTreeModelListener(listener);
	}
	
	public void testAddSubRoot()
	{
		for (Object o : subroots) {
			listener.e = null;
			if (o instanceof String) {
				model.addSubRoot((String)o);
			}
			else {
				model.addSubRoot((File)o);
			}
			assertEquals(o, model.getChild(model.getRoot(), 
					model.getChildCount(model.getRoot()) - 1));
			assertNotNull(listener.e);
			assertEquals(o, listener.e.getChildren()[0]);
			assertEquals(model.getRoot(), listener.e.getPath()[0]);
			assertEquals(model.getChildCount(model.getRoot()) - 1, listener.e.getChildIndices()[0]);
		}
		
		// add the same objects again, this time there shouldn't be any events
		for (Object o : subroots) {
			listener.e = null;
			if (o instanceof String) {
				model.addSubRoot((String)o);
			}
			else {
				model.addSubRoot((File)o);
			}
			assertNull(listener.e);
		}
	}
	
	public void testRemoveSubRoots()
	{
		listener.e = null;
		model.removeSubRoots();
		assertNotNull(listener.e);
		assertEquals(model.getRoot(), listener.e.getPath()[0]);
	}
	
	private class TreeModelHandler implements TreeModelListener
	{
		TreeModelEvent e;

		public void treeNodesChanged(TreeModelEvent e) {
			this.e = e;
		}

		public void treeNodesInserted(TreeModelEvent e) {
			this.e = e;
		}

		public void treeNodesRemoved(TreeModelEvent e) {
			this.e = e;
		}

		public void treeStructureChanged(TreeModelEvent e) {
			this.e = e;
		}
		
	}

	public void testSetFileFilter()
	{
		DirectoryFilter filter = new DirectoryFilter();
		model.setFileFilter(filter);
		assertEquals(filter, model.getFileFilter());
	}
	
	public void testFilter()
	{
		model.setFileFilter(new DirectoryFilter());
		testListing(tempDir, model.getSortListedFiles());
	}
	
	public void testListing(File file, boolean sort) 
	{
		File[] files = tempDir.listFiles(model.getFileFilter());
		if (files == null) {
			assertEquals(0, model.getChildCount(tempDir));
			return;
		}
		assertEquals(files.length, model.getChildCount(tempDir));
		if (sort) {
			Arrays.sort(files, new FileTreeModel.FileComparator());
		}
		List<File> fileList = Arrays.asList(files);
		List<File> modelList = new ArrayList<File>();
		for (int i = 0; i < model.getChildCount(tempDir); i++) {
			modelList.add((File)model.getChild(tempDir, i));
		}
		assertEquals(fileList, modelList);
	}
	
	public void testSortFiles()
	{
		model.setSortListedFiles(true);
		assertTrue(model.getSortListedFiles());
		model.setSortListedFiles(false);
		assertFalse(model.getSortListedFiles());
		testListing(tempDir, false);
		model.setSortListedFiles(true);
		testListing(tempDir, true);
	}
	
	private class DirectoryFilter implements FileFilter
	{
		public boolean accept(File pathname) {
			return pathname.isDirectory();
		}
		
	}
	
}
