package org.xnap.commons.util;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import junit.framework.TestCase;
import org.xnap.commons.io.TestProgressMonitor;


public class FileHelperTest extends TestCase {

	private File tempDir;

	@Override
	protected void setUp() throws Exception
	{
		super.setUp();
		
		tempDir = new File(System.getProperty("java.io.tmpdir") + File.separatorChar + "xnap-commons-test-FileHelperText");
		if (tempDir.exists()) {
			tempDir.delete();
		}
		tempDir.mkdirs();
	}
	
	@Override
	protected void tearDown() throws Exception
	{
		super.tearDown();
		
		tempDir.delete();
	}
	
	public void testCreateUnique() throws Exception
	{
		File file1 = FileHelper.createUnique(tempDir, "unique");
		assertTrue(file1.exists());
		File file2 = FileHelper.createUnique(file1.getAbsolutePath());
		assertTrue(file2.exists());
		assertNotSame(file1, file2);
		File file3 = FileHelper.createUnique(tempDir, "unique1");
		assertTrue(file3.exists());
		assertNotSame(file1, file3);
		assertNotSame(file2, file3);
		
		// test with extension:
		File file4 = FileHelper.createUnique(tempDir, "namewith.extension");
		assertTrue(file4.exists());
		File file5 = FileHelper.createUnique(tempDir, "namewith.extension");
		assertTrue(file5.exists());
		assertNotSame(file4, file5);
		
		// test exception
		try {
			FileHelper.createUnique(new File(""), "child");
			fail("Exception expected");
		}
		catch (FileNotFoundException fnfe) {
		}
		
		file1.delete();
		file2.delete();
		file3.delete();
		file4.delete();
		file5.delete();
	}
	
	public void testAppendSeparator()
	{
		assertEquals("filename" + File.separator, 
				FileHelper.appendSeparator("filename"));
		assertEquals("filename" + File.separator,
				FileHelper.appendSeparator("filename" + File.separator));
	}
	
	public void testShorten() throws Exception
	{
		// on empty file
		File file1 = FileHelper.createUnique(tempDir, "toShorten");
		assertEquals(0, file1.length());
		FileHelper.shorten(file1, 0);
		assertEquals(0, file1.length());
		FileHelper.shorten(file1, 333);
		assertEquals(0, file1.length());
		
		// on non-empty file
		FileHelper.writeText(file1, "some content to be shortened away soon");
		assertTrue(file1.length() > 0);
		// shorten a bit
		long length = file1.length();
		FileHelper.shorten(file1, length - 10);
		assertEquals(10, file1.length());
		FileHelper.shorten(file1, file1.length());
		assertEquals(0, file1.length());
		
		file1.delete();
	}
	
	/*
	 * Test method for 'org.xnap.commons.util.FileHelper.move(File, File)'
	 */
	public void testMove() throws Exception
	{
		File file1 = FileHelper.createUnique(tempDir, "toMove");
		assertTrue(file1.exists());
		File file2 = new File(tempDir, "target");
		assertFalse(file2.exists());
		FileHelper.move(file1, file2);
		assertFalse(file1.exists());
		assertTrue(file2.exists());
		
		// move file to itself
		FileHelper.move(file2, file2);
		assertTrue(file2.exists());
		
		// move non-existent file
		assertFalse(file1.exists());
		try {
			FileHelper.move(file1, file1);
			fail("exception expected");
		}
		catch (IOException ie) {
		}
		
		// move over already existing file
		File file3 =  FileHelper.createUnique(tempDir, "existing-dest");
		FileHelper.move(file2, file3);
		assertFalse(file2.exists());
		assertTrue(file3.exists());
		
		file1.delete();
		file2.delete();
		file3.delete();
	}
	
	public void testMoveUnique() throws Exception
	{
		File file1 = FileHelper.createUnique(tempDir, "moveUnique");
		File file2 = FileHelper.createUnique(tempDir, "targetMoveUnique");
		assertTrue(file1.exists());
		assertTrue(file2.exists());
		File file3 = FileHelper.moveUnique(file1, file2.getParent(), file2.getName());
		assertTrue(file3.exists());
		assertFalse(file1.exists());
		assertNotSame(file2, file3);
		
		file3.delete();
		file2.delete();
		file1.delete();
	}

	/*
	 * Test method for 'org.xnap.commons.util.FileHelper.copy(File, File)'
	 */
	public void testCopyFileFile() throws Exception
	{
		File source = FileHelper.createUnique( tempDir, "source");
		File dest = FileHelper.createUnique(tempDir, "dest");
		String content = "this is the content of the file, content, content content";
		FileHelper.writeText(source, content);
		assertTrue(source.length() > 0);
		FileHelper.copy(source, dest);
		assertEquals(source.length(), dest.length());
		assertEquals(content, FileHelper.readText(dest));
		
		// more tests please
		
		dest.delete();
		source.delete();
	}
	
	public void testCopyFileFileProgressMonitor() throws IOException
	{
		File source  = FileHelper.createUnique(tempDir, "source");
		File dest = FileHelper.createUnique(tempDir, "dest");
		String content = "this is the content of the file, \ncontent, content content\n\n\n";
		FileHelper.writeText(source, content);
		assertTrue(source.length() > 0);
		TestProgressMonitor monitor = new TestProgressMonitor();
		FileHelper.copy(source, dest, monitor);
		assertEquals(source.length(), dest.length());
		assertEquals(content, FileHelper.readText(dest));
		assertEquals(source.length(), monitor.getTotalSteps());
		assertEquals(monitor.getTotalSteps(), monitor.getValue());
		dest.delete();
		source.delete();
	}

	public void testExists() throws IOException
	{
		File tempFile = new File(tempDir, "testExists.tmp");
		tempFile.createNewFile();
		assertEquals(true, FileHelper.exists(tempFile.getAbsolutePath()));
		tempFile.delete();
		assertEquals(false, FileHelper.exists(tempFile.getAbsolutePath()));
	}

	/*
	 * Test method for 'org.xnap.commons.util.FileHelper.readText(InputStream)'
	 */
	public void testReadTextInputStream()
	{
	}

	/*
	 * Test method for 'org.xnap.commons.util.FileHelper.toAscii(String)'
	 */
	public void testToAscii()
	{
	}

	/*
	 * Test method for 'org.xnap.commons.util.FileHelper.toFilename(String)'
	 */
	public void testToFilename()
	{
	}

	public void testReadWriteText() throws Exception
	{
		// empty string
		File file1 = FileHelper.createUnique(tempDir, "empty-read-text");
		assertTrue(file1.exists());
		FileHelper.writeText(file1, "");
		assertEquals("", FileHelper.readText(file1));
		
		// some random text
		File file2 = FileHelper.createUnique(tempDir, "random-read-text");
		assertTrue(file2.exists());
		String randomText = "some random piece of text\\ having all kinds of \n line breake..";
		FileHelper.writeText(file2, randomText);
		assertEquals(randomText, FileHelper.readText(file2));
		
		// linebreak test and write to non-existent file
		File file3 = FileHelper.createUnique(tempDir, "line-breaks-text");
		assertTrue(file3.exists());
		file3.delete();
		assertFalse(file3.exists());

		String text = "\n\n\n \r\n\r\n  \\\n\n\n\n\t\tn\tn\n\n";
		FileHelper.writeText(file3, text);
		assertEquals(text, FileHelper.readText(file3));
		
		file1.delete();
		file2.delete();
		file3.delete();
	}
	
	public void testReadWriteBinary() throws Exception
	{
		Collection<Object> c = new ArrayList<Object>();
		// add different objects
		c.add("string");
		c.add(1);
		c.add(new Color(1, 2, 3));
		assertEquals(3, c.size());
		File file1 = FileHelper.createUnique(tempDir, "binary-file");
		FileHelper.writeBinary(file1, c);
		assertTrue(file1.exists());
		assertTrue(file1.length() > 0);
		
		Collection<Object> read = new ArrayList<Object>();
		FileHelper.readBinary(file1, read);
		assertEquals(c.size(), read.size());
		assertEquals(c, read);
		
		// write and read empty collection
		Collection<Object> empty = new ArrayList<Object>();
		assertTrue(empty.isEmpty());
		File file2 = FileHelper.createUnique(tempDir, "empty-file");
		assertTrue(file2.exists());
		FileHelper.writeBinary(file2, empty);
		
		Collection<Object> emptyRead = new ArrayList<Object>();
		FileHelper.readBinary(file2, emptyRead);
		assertTrue(emptyRead.isEmpty());
		
		file1.delete();
		file2.delete();
	}
	
	public void testReadBinary() throws Exception
	{
		Collection<Object> c = new ArrayList<Object>();
		try {
			FileHelper.readBinary(new File("does not exist"), c);
			fail("IOException expected");
		}
		catch (IOException ie) {
		}
		assertTrue(c.isEmpty());
	}
	
	public void testName()
	{
		assertEquals("filename", FileHelper.name("filename.ext"));
		assertEquals("filename", FileHelper.name("filename."));
		assertEquals("file,name/", FileHelper.name("file,name/.test"));
		assertEquals("file,name", FileHelper.name("file,name"));
		// TODO fix test or impl? FileHelper.extension returns .ext as well....
		assertEquals(".ext", FileHelper.name(".ext"));
		assertEquals(".", FileHelper.name("."));
		assertEquals("", FileHelper.name(""));
	}
	
	public void testExtension()
	{
		assertEquals("ext", FileHelper.extension("filename.ext"));
		assertEquals("ext", FileHelper.extension(".ext"));
		assertEquals("", FileHelper.extension("filename."));
		assertEquals("ext", FileHelper.extension("filen,//,name.ext"));
		assertEquals("", FileHelper.extension(""));
		assertEquals("", FileHelper.extension("."));
		assertEquals("ext", FileHelper.extension("\\.ext"));
	}
	
}
