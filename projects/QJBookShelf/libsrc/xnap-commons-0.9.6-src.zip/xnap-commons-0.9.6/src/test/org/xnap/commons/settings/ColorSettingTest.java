package org.xnap.commons.settings;

import java.awt.Color;

/**
 * @author Steffen Pingel
 */
public class ColorSettingTest extends AbstractSettingTest<Color> {

	public ColorSettingTest()
	{
		super(Color.white, Color.black, Color.red);
	}

	@Override
	protected Setting<Color> createSetting(SettingResource backend, String key, Color defaultValue)
	{
		return new ColorSetting(backend, key, defaultValue);
	}

}
