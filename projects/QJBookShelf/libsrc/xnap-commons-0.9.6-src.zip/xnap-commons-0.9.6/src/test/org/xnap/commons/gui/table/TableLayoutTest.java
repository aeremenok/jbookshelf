package org.xnap.commons.gui.table;

import java.util.Iterator;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import junit.framework.TestCase;

public class TableLayoutTest extends TestCase 
{

	public void testAddColumn()
	{
		JTable table = new JTable(new TableSorter(new DefaultTableModel()));
		TableColumn column = new TableColumn();
		table.addColumn(column);
		
		TableLayout layout = new TableLayout(table);
		
		assertEquals(1, layout.getColumnCount());
		assertEquals(column, layout.getColumnAt(layout.getColumnCount() - 1));
		assertTrue(contains(layout.getColumns(), column));
	}
	
	private boolean contains(Iterator<TableColumn> i, TableColumn column)
	{
		while (i.hasNext()) {
			if (i.next().equals(column)) {
				return true;
			}
		}
		return false;
	}
	
	public void testSetColumnVisible()
	{
		JTable table = new JTable(new TableSorter(new DefaultTableModel()));
		TableColumn column = new TableColumn();
		table.addColumn(column);
		
		TableLayout layout = new TableLayout(table);

		int index = layout.getColumnCount() / 2;
		layout.setColumnVisible(index, true);
		assertTrue(layout.isColumnVisible(index));
		int visibleColumns = layout.getVisibleColumnsCount();
		layout.setColumnVisible(index, false);
		assertFalse(layout.isColumnVisible(index));
		assertEquals(visibleColumns - 1, layout.getVisibleColumnsCount());
		layout.setColumnVisible(index, true);
		assertEquals(visibleColumns, layout.getVisibleColumnsCount());
	}
	
}
