/*
 *  XNap
 *
 *  A pure java file sharing client.
 *
 *  See AUTHORS for copyright information.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package org.xnap.commons.util;

import java.util.Locale;
import junit.framework.TestCase;

/**
 * @author Steffen Pingel
 */
public class StringHelperTest extends TestCase {

	public void testFirstToken()
	{
		assertEquals("1", StringHelper.firstToken("1.3", "."));
		assertEquals("1", StringHelper.firstToken("1.", "."));
		assertEquals("", StringHelper.firstToken(".3", "."));
		assertEquals("", StringHelper.firstToken("", "."));
		assertEquals("", StringHelper.firstToken(".", "."));
		assertEquals("ab c", StringHelper.firstToken("ab c", "."));

		assertEquals("a", StringHelper.firstToken("abcd", "bc"));		
	}
	
    public void testLastToken() 
    {
		assertEquals("3", StringHelper.lastToken("1.3", "."));
		assertEquals("", StringHelper.lastToken("1.", "."));
		assertEquals("", StringHelper.lastToken("", "."));
		assertEquals("", StringHelper.lastToken(".", "."));
		assertEquals("", StringHelper.lastToken("abc", "."));

		assertEquals("d", StringHelper.lastToken("abcd", "bc"));
    }

	public void testLastPrefix()
	{
		assertEquals(StringHelper.lastPrefix("1.3", "."), "1");
		assertEquals(StringHelper.lastPrefix("1.", "."), "1");
		assertEquals(StringHelper.lastPrefix("", "."), "");
		assertEquals(StringHelper.lastPrefix(".", "."), "");
		assertEquals(StringHelper.lastPrefix("abc", "."), "abc");

		assertEquals(StringHelper.lastPrefix("abcd", "bc"), "a");
	}

	public void testFormatSize()
	{
		// number separators are locale specific, therefore we save change
		// it temporarily to English
		Locale locale = Locale.getDefault();
		Locale.setDefault(Locale.ENGLISH);
		
		assertEquals("1,023 B", StringHelper.formatSize(1023));
		assertEquals("1 KB", StringHelper.formatSize(1024));
		
		Locale.setDefault(locale);
	}

	public void testFormatLength()
	{
		assertEquals("00:00", StringHelper.formatLength(0));
		assertEquals("01:00", StringHelper.formatLength(60));
	}

	public void testPad()
	{
		assertEquals("", StringHelper.pad("", 0));
		assertEquals("  ", StringHelper.pad("", 1));
		assertEquals(" a ", StringHelper.pad("a", 1));
		assertEquals("   b   ", StringHelper.pad("b", 3));		
		try {
			StringHelper.pad("", -1);
			assertFalse("Expected IllegalArgumentException", true);
		} catch (IllegalArgumentException e) {}
	}

	public void testPadLeftRight()
	{
		assertEquals("", StringHelper.pad("", 0, 0));
		assertEquals("  ", StringHelper.pad("", 1, 1));
		assertEquals(" a", StringHelper.pad("a", 1, 0));
		assertEquals("a ", StringHelper.pad("a", 0, 1));
		assertEquals("   b ", StringHelper.pad("b", 3, 1));		
		try {
			StringHelper.pad("", -1, 0);
			assertFalse("Expected IllegalArgumentException", true);
		} catch (IllegalArgumentException e) {}
		try {
			StringHelper.pad("", 0, -1);
			assertFalse("Expected IllegalArgumentException", true);
		} catch (IllegalArgumentException e) {}
		try {
			StringHelper.pad("", -1, -1);
			assertFalse("Expected IllegalArgumentException", true);
		} catch (IllegalArgumentException e) {}
	}
	
	public void testRandom()
	{
		for (int i = 0; i < 10; i++) {
			String random = StringHelper.randomString(8);
			assertEquals(8, random.length());
			assertEquals(false, random.contains(" "));
		}
		
		assertEquals(0, StringHelper.randomString(0).length());
		assertEquals(1, StringHelper.randomString(1).length());
	}

	public void testIndexOfDigit()
	{
		assertEquals(0, StringHelper.indexOfDigit("123"));
		assertEquals(1, StringHelper.indexOfDigit(" 123"));
		assertEquals(2, StringHelper.indexOfDigit("ab123"));
		assertEquals(3, StringHelper.indexOfDigit("foo1bar"));
		assertEquals(3, StringHelper.indexOfDigit("foo1"));
		assertEquals(-1, StringHelper.indexOfDigit(""));
		assertEquals(-1, StringHelper.indexOfDigit("abc"));
	}

}
