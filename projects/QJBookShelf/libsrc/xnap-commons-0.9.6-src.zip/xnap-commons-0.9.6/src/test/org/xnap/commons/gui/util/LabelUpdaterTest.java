package org.xnap.commons.gui.util;

import java.util.Locale;
import javax.swing.JDialog;
import junit.framework.TestCase;
import org.xnap.commons.i18n.I18nFactory;
import org.xnap.commons.i18n.I18nManager;


public class LabelUpdaterTest extends TestCase {
	
	public void testListener()
	{
		MyDialog dialog = new MyDialog();
		I18nManager.getInstance().addLocaleChangeListener(new LabelUpdater());
		assertEquals(0, dialog.count);
		I18nManager.getInstance().setDefaultLocale(Locale.GERMAN);
		assertEquals(1, dialog.count);
	}
	
	private class MyDialog extends JDialog 
	{
		int count;
		
		public void updateLabels()
		{
			count++;
		}
		
	}
	
}
