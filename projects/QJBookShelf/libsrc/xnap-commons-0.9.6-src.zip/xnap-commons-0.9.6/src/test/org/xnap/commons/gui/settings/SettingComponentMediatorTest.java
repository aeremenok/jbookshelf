package org.xnap.commons.gui.settings;

import javax.swing.JCheckBox;
import javax.swing.JTextField;
import junit.framework.TestCase;
import org.xnap.commons.settings.BooleanSetting;
import org.xnap.commons.settings.PropertyResource;
import org.xnap.commons.settings.StringSetting;

public class SettingComponentMediatorTest extends TestCase {
	
	public void testBooleanSetting()
	{
		PropertyResource resource = new PropertyResource();
		BooleanSetting setting = new BooleanSetting(resource, "foo", false);
		JCheckBox checkBox = new JCheckBox();
		
		SettingComponentMediator mediator = new SettingComponentMediator();
		mediator.add(setting, checkBox);
		
		mediator.revert();
		assertEquals(false, checkBox.isSelected());
		assertEquals(false, setting.getValue().booleanValue());
		
		checkBox.setSelected(true);
		mediator.revert();
		assertEquals(false, checkBox.isSelected());
		assertEquals(false, setting.getValue().booleanValue());
		
		checkBox.setSelected(true);
		mediator.revertToDefaults();
		assertEquals(false, checkBox.isSelected());
		assertEquals(false, setting.getValue().booleanValue());
		
		checkBox.setSelected(true);
		mediator.apply();
		assertEquals(true, checkBox.isSelected());
		assertEquals(true, setting.getValue().booleanValue());

		mediator.revert();
		assertEquals(true, checkBox.isSelected());
		assertEquals(true, setting.getValue().booleanValue());

		mediator.revertToDefaults();
		assertEquals(false, checkBox.isSelected());
		assertEquals(true, setting.getValue().booleanValue());

	}

	public void testStringSetting()
	{
		PropertyResource resource = new PropertyResource();
		StringSetting setting = new StringSetting(resource, "foo", "bar");
		JTextField textField = new JTextField();
		
		SettingComponentMediator mediator = new SettingComponentMediator();
		mediator.add(setting, textField);
		
		mediator.revert();
		assertEquals("bar", textField.getText());
		assertEquals("bar", setting.getValue());
		
		textField.setText("foo");
		mediator.revert();
		assertEquals("bar", textField.getText());
		assertEquals("bar", setting.getValue());
		
		textField.setText("foo");
		mediator.revertToDefaults();
		assertEquals("bar", textField.getText());
		assertEquals("bar", setting.getValue());
		
		textField.setText("baz");
		mediator.apply();
		assertEquals("baz", textField.getText());
		assertEquals("baz", setting.getValue());

		mediator.revert();
		assertEquals("baz", textField.getText());
		assertEquals("baz", setting.getValue());

		mediator.revertToDefaults();
		assertEquals("bar", textField.getText());
		assertEquals("baz", setting.getValue());

	}

}
