package org.xnap.commons.gui.action;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.AbstractAction;
import javax.swing.AbstractButton;
import javax.swing.Icon;
import junit.framework.TestCase;
import org.xnap.commons.gui.Builder;
import org.xnap.commons.gui.util.IconHelper;

public class AbstractXNapActionTest extends TestCase {

	public void testIconPropertyChange()
	{
		Icon icon1 = IconHelper.getButtonIcon("folder.png");
		assertNotNull(icon1);
		
		Icon icon2 = IconHelper.getButtonIcon("folder_open.png");
		assertNotNull(icon2);
		
		MyAction action = new MyAction();
		AbstractButton button = Builder.createButton(action);

		// Note: this test relies on the fact that IconHelper uses ImageIcon
		// objects that override the toString() method to return the filename
		// of the displayed image
		
		action.putValue(AbstractXNapAction.ICON_FILENAME, "folder.png");
		assertEquals(icon1.toString(), button.getIcon().toString());
	
		action.putValue(AbstractXNapAction.ICON_FILENAME, "folder_open.png");
		assertEquals(icon2.toString(), button.getIcon().toString());

		action.putValue(AbstractXNapAction.ICON_FILENAME, null);
		assertEquals(null, button.getIcon());

		action.putValue(AbstractXNapAction.ICON_FILENAME, "folder.png");
		assertEquals(icon1.toString(), button.getIcon().toString());
	}
	
	public void testSetEnabledLater() throws Exception
	{
		EnabledTestAction action = new EnabledTestAction();
		action.setEnabled(false);
		PropertyChangeHandler handler = new PropertyChangeHandler();
		action.addPropertyChangeListener(handler);
		
		handler.sleep = true;
		action.setEnabledLater(true);
		synchronized(handler.lock) {
			if (handler.sleep) {
				handler.lock.wait();
			}
		}
		assertEquals(true, handler.newValue);
		
		handler.sleep = true;
		action.setEnabledLater(false);
		synchronized(handler.lock) {
			if (handler.sleep) {
				handler.lock.wait();
			}
		}
		assertEquals(false, handler.newValue);
	}
	
	private class PropertyChangeHandler implements PropertyChangeListener
	{

		public volatile boolean newValue;
		public Object lock = new Object();
		public volatile boolean sleep;
		
		public void propertyChange(PropertyChangeEvent evt) {
			newValue =  ((Boolean)evt.getNewValue()).booleanValue();
			synchronized(lock) {
				sleep = false;
				lock.notify();
			}
		}
		
	}
	
	private class EnabledTestAction extends AbstractXNapAction
	{

		public void actionPerformed(ActionEvent e) {

		}
		
	}
	
	public class MyAction extends AbstractAction {

		public MyAction()
		{
		}

		public void actionPerformed(ActionEvent e)
		{
		}
				
	}

}
