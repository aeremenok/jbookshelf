package org.xnap.commons.settings;

import junit.framework.TestCase;
import org.xnap.commons.util.PortRange;

public class PortRangeValidatorTest extends TestCase {

	PortRangeValidator val;

	@Override
	protected void setUp() throws Exception {
		val = new PortRangeValidator();
	}
	
	public void testValidPortRanges()
	{
		// valid: [([:number:]*|[:number:]*-[:number:]*);]*
		val.validate("8080");
		val.validate("8080-9090");
		val.validate("1;2-3;989;5445-5445");
		val.validate(";3;;");
		val.validate(PortRange.MIN_PORT + "-" + PortRange.MAX_PORT);
	}
	
	public void testInvalidPortRanges()
	{
		try {
			val.validate("");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			val.validate("-");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			val.validate(";-,-;");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			val.validate("0;1000000");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			val.validate("9999-9990");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			val.validate("f-g;h");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			val.validate("-1");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			val.validate(PortRange.MIN_PORT - 1 + ";" + PortRange.MAX_PORT + 1);
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			// TODO how should this be treated?
//			val.validate("-1-100");
//			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}

	}
	
	public void testCustomRangeValidator()
	{
		PortRangeValidator v = new PortRangeValidator(1, 1);
		v.validate("1");
		v.validate("1;1-1");
		
		try {
			v.validate("0");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			v.validate("2");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			v.validate("0-2;2,0-1");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			v.validate("");
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
	}
	
}
