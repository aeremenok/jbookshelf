package org.xnap.commons.settings;

/**
 * @author Steffen Pingel
 */
public abstract class AbstractArraySettingTest<T> extends AbstractSettingTest<T> {

	public AbstractArraySettingTest(T value1, T value2, T value3)
	{
		super(value1, value2, value3);
	}

	@Override
	public void assertEqualValues(T expectedObject, T valueObject) {
		Object[] expected = (Object[])expectedObject;
		Object[] value = (Object[])valueObject;
		if (expected == null || value == null) {
			assertNull(expected);
			assertNull(value);
			return;
		}
		assertEquals(expected.length, value.length);
		for (int i = 0; i < expected.length; i++) {
			assertEquals(expected[i], value[i]);
		}
	}
}
