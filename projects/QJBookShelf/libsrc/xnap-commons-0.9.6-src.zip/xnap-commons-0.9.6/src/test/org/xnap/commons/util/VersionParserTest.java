/*
 *  XNap
 *
 *  A pure java file sharing client.
 *
 *  See AUTHORS for copyright information.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package org.xnap.commons.util;

import junit.framework.TestCase;

/**
 * @author Steffen Pingel
 */
public class VersionParserTest extends TestCase {
    
    public VersionParserTest(String name) 
    {
		super(name);
    }

    protected void setUp()
    {
    }

    protected void tearDown()
    {
    }

    public void testEquals() 
    {
		assertTrue(VersionParser.compare("1.3", "  1 .  3") == 0);
		assertTrue(VersionParser.compare("1.3", "  1 .  3") == 0);
		assertTrue(VersionParser.compare("1.3", "1.4") < 0);
		assertTrue(VersionParser.compare("1.4", "1.3") > 0);
		assertTrue(VersionParser.compare("1.3r1", "1.3") > 0);
		assertTrue(VersionParser.compare("1.3.1", "1.3") > 0);
		assertTrue(VersionParser.compare("1.3", "1.3-r2") < 0);
		assertTrue(VersionParser.compare("r2", "r1") > 0);
		assertTrue(VersionParser.compare("1.3-r2", "1.3-r1") > 0);
		assertTrue(VersionParser.compare("1:bbb", "2:aaa") < 0);
		assertEquals(new VersionParser("1.2-abc Version").toString(), 
					 "1.2-abc Version");
    }

	public void testPostfixes()
	{
		assertTrue(VersionParser.compare("1.0.0", "1.0-beta1") > 0);
		assertTrue(VersionParser.compare("1.0-beta1", "1.0.0") < 0);
		assertTrue(VersionParser.compare("3.0-pre4", "3.0.0") < 0);
	}

}
