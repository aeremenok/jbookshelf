package org.xnap.commons.gui.dnd;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.io.File;
import java.util.Collections;
import java.util.List;
import javax.swing.JTextField;
import javax.swing.TransferHandler;
import junit.framework.TestCase;

public class DefaultTextFieldFileTransferHandlerTest extends TestCase 
{
	private JTextField textField;

	@Override
	protected void setUp() throws Exception 
	{
		textField = new JTextField();
	}
	
	public void testInstall()
	{
		textField.setTransferHandler(null);
		assertNull(textField.getTransferHandler());
		DefaultTextFieldFileTransferHandler.install(textField);
		assertNotNull(textField.getTransferHandler());
	}

	@SuppressWarnings("unchecked")
	public void testCreateTransferable() throws Exception
	{
		File testFile = new File("/test/todrag");
		textField.setText(testFile.getAbsolutePath());
		DefaultTextFieldFileTransferHandler.install(textField);
		DefaultTextFieldFileTransferHandler handler = (DefaultTextFieldFileTransferHandler) textField.getTransferHandler();
		Transferable t = handler.createTransferable(textField);
		assertTrue(t.isDataFlavorSupported(DataFlavor.javaFileListFlavor));
		List<File> files = (List<File>) t.getTransferData(DataFlavor.javaFileListFlavor);
		assertEquals(testFile, files.get(0));
		
		textField.setEnabled(false);
		assertNull(handler.createTransferable(textField));
		textField.setEnabled(true);
		textField.setText("");
		assertNull(handler.createTransferable(textField));
	}
	
	public void testImportData()
	{
		File testFile = new File("/test/todrag");
		textField.setText("");
		DefaultTextFieldFileTransferHandler.install(textField);
		TransferHandler handler = textField.getTransferHandler();
		assertTrue(handler.importData(textField, 
				new FileTransferable(Collections.singletonList(testFile))));
		assertEquals(testFile, new File(textField.getText()));
	}

}
