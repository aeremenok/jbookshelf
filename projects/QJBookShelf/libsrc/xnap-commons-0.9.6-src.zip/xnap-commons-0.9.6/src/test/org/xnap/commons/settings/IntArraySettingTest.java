package org.xnap.commons.settings;


/**
 * @author Steffen Pingel
 */
public class IntArraySettingTest extends AbstractArraySettingTest<Integer[]> {

	final static Integer[] values1 = new Integer[] {
		1, 2, 3
	};
	final static Integer[] values2 = new Integer[] {
		4, 5, 6
	};
	final static Integer[] values3 = new Integer[] {
		7, 8
	};
	
	public IntArraySettingTest()
	{
		super(values1, values2, values3);
	}

	@Override
	protected Setting<Integer[]> createSetting(SettingResource backend, String key, Integer[] defaultValue)
	{
		return new IntArraySetting(backend, key, defaultValue);
	}
	

}
