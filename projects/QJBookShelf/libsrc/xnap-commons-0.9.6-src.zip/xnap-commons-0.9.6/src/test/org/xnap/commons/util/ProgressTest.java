package org.xnap.commons.util;

import junit.framework.TestCase;

public class ProgressTest extends TestCase {

	public void testCompareTo()
	{
		Progress p = new Progress();
		assertEquals(0, p.compareTo(p));
		p = new Progress(100, 0);
		assertEquals(0, p.compareTo(p));
		p = new Progress(100, 100);
		assertEquals(0, p.compareTo(p));
		p = new Progress(100, 10);
		assertEquals(0, p.compareTo(p));
		
		Progress p1 = new Progress(100, 0);
		Progress p2 = new Progress(100, 1);
		
		assertTrue(p1.compareTo(p2) < 0);
		assertTrue(p2.compareTo(p1) > 0);
		
		p1 = new Progress(0, 0);
		p2 = new Progress(15, 14);
		assertTrue(p1.compareTo(p2) < 0);
		assertTrue(p2.compareTo(p1) > 0);
		
		p1 = new Progress();
		p2 = new Progress(100, 0);
		assertEquals(0, p1.compareTo(p2));
	}
	
	public void testGetPercent()
	{
		Progress p = new Progress();
		assertEquals(0.0, p.getPercent());
		p = new Progress(97,  97);
		assertEquals(100.0, p.getPercent());
		p = new Progress(77, 0);
		assertEquals(0.0, p.getPercent());
	}
	
	public void testProgress()
	{
		try {
			new Progress(10, 11);
			fail("IllegalArgumentException expected");
		}
		catch (IllegalArgumentException iae) {
		}
	}
	
	public void testGetSizeAndGetTransferred()
	{
		Progress p = new Progress(454, 0);
		assertEquals(454, p.getSize());
		assertEquals(0, p.getTransferred());
		p = new Progress(97, 95);
		assertEquals(97, p.getSize());
		assertEquals(95, p.getTransferred());
	}
	
	public void testGetSetRate()
	{
		Progress p = new Progress();
		p.setRate(0);
		assertEquals(0, p.getRate());
		p.setRate(Integer.MAX_VALUE + 1);
		assertEquals(Integer.MAX_VALUE + 1, p.getRate());
		p.setRate(Integer.MIN_VALUE - 1);
		assertEquals(Integer.MIN_VALUE - 1, p.getRate());
	}
	
}
