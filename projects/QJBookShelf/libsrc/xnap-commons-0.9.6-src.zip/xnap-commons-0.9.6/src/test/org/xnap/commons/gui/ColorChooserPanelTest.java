package org.xnap.commons.gui;

import java.awt.Color;
import junit.framework.TestCase;


public class ColorChooserPanelTest extends TestCase {

	public void testConstructor()
	{
		ColorChooserPanel panel = new ColorChooserPanel(Color.black);
		assertEquals(Color.black, panel.getSelectedColor());
		panel.setSelectedColor(Color.white);
		assertEquals(Color.white, panel.getSelectedColor());
	}
	
	public void testSetSelectedColor()
	{
		ColorChooserPanel panel = new ColorChooserPanel();
		panel.setSelectedColor(Color.black);
		assertEquals(Color.black, panel.getSelectedColor());
		panel.setSelectedColor(Color.white);
		assertEquals(Color.white, panel.getSelectedColor());
		panel.setSelectedColor(new Color(1, 2, 3));
		assertEquals(new Color(1, 2, 3), panel.getSelectedColor());
	}
	
}
