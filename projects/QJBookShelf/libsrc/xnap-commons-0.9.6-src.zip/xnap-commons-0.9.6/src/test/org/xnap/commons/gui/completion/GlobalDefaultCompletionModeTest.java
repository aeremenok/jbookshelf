package org.xnap.commons.gui.completion;

import java.lang.reflect.Field;
import javax.swing.JTextField;
import junit.framework.TestCase;
import org.xnap.commons.settings.DefaultCompletionModeSetting;
import org.xnap.commons.settings.PropertyResource;

/**
 * Tests settings propagation for global default completion mode. 
 * @author Felix Berger
 */
public class GlobalDefaultCompletionModeTest extends TestCase {

	private PropertyResource backend;
	private Completion comp;
	private GlobalDefaultCompletionMode mode;

	@Override
	public void setUp() throws Exception
	{
		backend = new PropertyResource();
		comp = new Completion(new JTextField());
		mode = new GlobalDefaultCompletionMode();
		comp.setMode(mode);
	}

	@Override
	public void tearDown() throws Exception
	{
		super.tearDown();
		
		backend = null;
	}
	
	public void testExceptions() 
	{
		try {
			GlobalDefaultCompletionMode.setCompletionMode(null);
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
		
		try {
			GlobalDefaultCompletionMode.setCompletionMode(GlobalDefaultCompletionMode.class.getName());
			fail("exception expected");
		}
		catch (IllegalArgumentException iae) {
		}
	}
	
	public void testSettingsPropagation() throws Exception 
	{
		DefaultCompletionModeSetting setting = new DefaultCompletionModeSetting
		(backend, "globalDefaultMode", AutomaticCompletionMode.class.getName());
		// check initial value
		assertEquals(AutomaticCompletionMode.class.getName(), getDelegateCompletionModeClassName(mode));
		// change setting
		setting.setValue(DropDownListCompletionMode.class.getName());
		// check valaue
		assertEquals(DropDownListCompletionMode.class.getName(), getDelegateCompletionModeClassName(mode));
		// revert to default
		setting.revert();
		// check reverted value
		assertEquals(AutomaticCompletionMode.class.getName(), getDelegateCompletionModeClassName(mode));
	}
	
	private String getDelegateCompletionModeClassName
		(GlobalDefaultCompletionMode mode) throws Exception
	{
		Field field = mode.getClass().getDeclaredField("mode");
		field.setAccessible(true);
		return field.get(mode).getClass().getName();
	}
	
}
