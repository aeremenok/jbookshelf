package org.xnap.commons.gui.completion;

import java.lang.reflect.Method;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;
import junit.framework.TestCase;
import org.xnap.commons.gui.completion.CompletionModeFactory.CompletionModeInfo;

public class CompletionTest extends TestCase 
{

	Completion comp;
	JTextComponent jtc;
	
	public void setUp() 
	{
		jtc = new JTextField();
		comp = new Completion(jtc);
	}
	
	public void tearDown() 
	{
		jtc = null;
		comp = null;
	}
	
	public void testComletionModeChangeListener()
	{
		CompletionModeChangeHandler handler = new CompletionModeChangeHandler();
		comp.addCompletionModeListener(handler);
		
		comp.setMode(new EmacsCompletionMode());
		assertEquals(EmacsCompletionMode.class, handler.newMode);
		
		comp.removeCompletionModeListener(handler);
		comp.addCompletionModeListener(handler);
		
		comp.setMode((new EmacsCompletionMode()));
		assertEquals(EmacsCompletionMode.class, handler.oldMode);
		assertEquals(EmacsCompletionMode.class, handler.newMode);
		
		// shouldn't make a difference if completion is disabled
		comp.setEnabled(false);
		comp.setMode(new ManualCompletionMode());
		assertEquals(EmacsCompletionMode.class, handler.oldMode);
		assertEquals(ManualCompletionMode.class, handler.newMode);
	}
	
	/**
	 * This test was added before throwing an npe if the text component
	 * is null.
	 * The old implementation did not gurantee that, since not all completion 
	 * modes access the text component when they are enabled.
	 */
	public void testNullPointerException()
	{
		CompletionModeInfo[] infos = 
			CompletionModeFactory.getInstalledCompletionModes();
		for (CompletionModeInfo info : infos) {
			GlobalDefaultCompletionMode.setCompletionMode(info.getClassName());
			try {
				new Completion(null);
				fail("NPE expected");
			}
			catch (NullPointerException npe) {
			}
		}
	}
	
	public void testSetEnabled()
	{
		assertTrue(comp.isEnabled());
		
		comp.setEnabled(true);
		assertTrue(comp.isEnabled());
		
		comp.setEnabled(false);
		assertFalse(comp.isEnabled());
		
		comp.setEnabled(false);
		assertFalse(comp.isEnabled());
		
		comp.setEnabled(true);
		assertTrue(comp.isEnabled());
	}
	
	public void testSetModel()
	{
		assertEquals(DefaultCompletionModel.class, comp.getModel().getClass());
		
		FileCompletionModel fileModel = new FileCompletionModel();
		comp.setModel(fileModel);
		assertEquals(fileModel, comp.getModel());
	}
	
	public void testSetText()
	{
		JTextField jtf = new JTextField();
		RaisedAccessCompletion r = new RaisedAccessCompletion(jtf);
		assertEquals("", jtf.getText());
		r.setText("hello");
		assertEquals("hello", jtf.getText());
		r.setText("");
		assertEquals("", jtf.getText());
		r.setText("ab", 1, 2);
		assertEquals("ab", jtf.getText());
		assertEquals("b", jtf.getSelectedText());
		r.setText("ab", 0, 0);
		assertEquals("ab", jtf.getText());
		assertEquals(null, jtf.getSelectedText());
		r.setText("ab", 2, 2);
		assertEquals("ab", jtf.getText());
		assertEquals(null, jtf.getSelectedText());
		r.setText("ab", 0, 1);
		assertEquals("ab", jtf.getText());
		assertEquals("a", jtf.getSelectedText());
		r.setText("abc", 0, 3);
		assertEquals("abc", jtf.getText());
		assertEquals("abc", jtf.getSelectedText());
		try {
			r.setText("", 0, 5);
			fail("illegal argument exception not thrown");
		}
		catch (IllegalArgumentException iae) {
		}
	}
	
	public void testGetPreviousWord() throws Exception
	{
		JTextField jtc = new JTextField();
		Completion comp = new Completion(jtc, false);
		jtc.setCaretPosition(0);
		assertEquals("", comp.getText());
		
		jtc.setText("hello");
		jtc.setCaretPosition(jtc.getText().length());
		assertEquals("hello", comp.getText());
		
		jtc.setText("hello there");
		jtc.setCaretPosition(jtc.getText().length());
		assertEquals("there", comp.getText());
		
		jtc.setText("hello my love");
		jtc.setCaretPosition("hello my".length());
		assertEquals("my", comp.getText());
		
		jtc.setText("hello ");
		jtc.setCaretPosition(jtc.getText().length());
		assertEquals("", comp.getText());
		
		jtc.setText("hello-");
		jtc.setCaretPosition(jtc.getText().length());
		assertEquals("", comp.getText());
		
		jtc.setText("x");
		jtc.setCaretPosition(jtc.getText().length());
		assertEquals("x", comp.getText());
		
		jtc.setText("a b c x");
		jtc.setCaretPosition(jtc.getText().length());
		assertEquals("x", comp.getText());

		jtc.setText(" ");
		jtc.setCaretPosition(jtc.getText().length());
		assertEquals("", comp.getText());
		
		jtc.setText("a b c ");
		jtc.setCaretPosition(jtc.getText().length());
		assertEquals("", comp.getText());

	}
	
	private String getPreviousWord(Completion comp) throws Exception
	{
		Method method = comp.getClass().getDeclaredMethod
		("getPreviousWord", (Class[])null);
		method.setAccessible(true);
		return (String)method.invoke(comp, (Object[])null);
	}
	
	private class CompletionModeChangeHandler implements CompletionModeListener
	{
		public Class oldMode;
		public Class newMode;
		
		public void modeChanged(Class oldMode, Class newMode) {
			this.oldMode = oldMode;
			this.newMode = newMode;
		}
	}
	
	private class RaisedAccessCompletion extends Completion
	{
		public RaisedAccessCompletion(JTextComponent jtc)
		{
			super(jtc);
		}
		
		public void setText(String text)
		{
			super.setText(text);
		}
		
		public void setText(String text, int selectionStart, int selectionEnd)
		{
			super.setText(text, selectionStart, selectionEnd);
		}
	}
}
