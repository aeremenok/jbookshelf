package org.xnap.commons.gui.completion;

import junit.framework.TestCase;

public class ClearCompletionModelActionTest extends TestCase {

	public void testActionPerformed()
	{
		DefaultCompletionModel model = new DefaultCompletionModel();
		model.insert("aaaa");
		model.insert("aaac");
		assertEquals(2, model.toArray().length);
		
		ClearCompletionModelAction action = new ClearCompletionModelAction(model);
		action.actionPerformed(null);
		assertEquals(0, model.toArray().length);
	}
	
}
