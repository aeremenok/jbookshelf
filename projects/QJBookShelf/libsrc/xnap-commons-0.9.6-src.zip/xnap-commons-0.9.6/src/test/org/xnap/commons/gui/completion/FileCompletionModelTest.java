package org.xnap.commons.gui.completion;

import java.io.File;
import java.io.IOException;
import junit.framework.TestCase;
import org.xnap.commons.util.FileHelper;


/**
 * @author Felix Berger
 */
public class FileCompletionModelTest extends TestCase
{
	private FileCompletionModel model;
	private File tmpDir;
	private File subDir;
	private File hiddenFile;
	private File subSubDir;
	private File aaaa1;
	private File aaaa2;
	
	public void setUp() throws IOException
	{
		model = new FileCompletionModel();
		
		tmpDir = new File(System.getProperty("java.io.tmpdir"));
				
		subDir = new File(tmpDir, "completionDir");
		assertTrue(subDir.mkdir());
		
		hiddenFile = new File(subDir, ".hiddenfile");
		hiddenFile.createNewFile();
		
		subSubDir = new File(subDir, "subsubDir");
		assertTrue(subSubDir.mkdir());
		
		aaaa2 = new File(subSubDir, "aaaa2");
		aaaa2.createNewFile();
		aaaa1 = new File(subSubDir, "aaaa1");
		aaaa1.createNewFile();
	}
	
	public void tearDown()
	{
		aaaa1.delete();
		aaaa2.delete();
		subSubDir.delete();
		hiddenFile.delete();
		subDir.delete();
		model = null;
	}
	
	public void testFilenamePrefix()
	{
		model.complete(FileHelper.appendSeparator(subSubDir.getAbsolutePath())
				+ "aaa");
		assertEquals(2, model.getSize());
	}
	
	public void testCompleteUniquePrefix()
	{
		String prefix = FileHelper.appendSeparator(subSubDir.getAbsolutePath());
		assertEquals(prefix + "aaaa", model.completeUniquePrefix(prefix));
		prefix = FileHelper.appendSeparator(subSubDir.getAbsolutePath()) + "aaaa";
		 assertEquals(prefix, model.completeUniquePrefix(prefix));
		prefix = aaaa1.getAbsolutePath();
		assertEquals(prefix, model.completeUniquePrefix(prefix));

		// test if prefix is returned when no completion is possilbe
		assertEquals("test", model.completeUniquePrefix("test"));
	}
	
	public void testDirectoryNameCompletion()
	{
		model.setCompleteHiddenFiles(true);
		model.complete(tmpDir.getAbsolutePath());
		assertEquals(tmpDir.listFiles().length + 1, model.getSize());
	}

	public void testSetters()
	{
		assertTrue(hiddenFile + "should be a hidden file", hiddenFile.isHidden());
		
		model.setCompleteDirectoriesOnly(true);
		model.complete(subDir.getAbsolutePath());
		assertEquals(2, model.getSize());
		
		model.setCompleteDirectoriesOnly(false);
		model.setCompleteHiddenFiles(false);
		model.complete(subDir.getAbsolutePath());
		assertEquals(2, model.getSize());
		
		model.setCompleteHiddenFiles(true);
		model.complete(subDir.getAbsolutePath());
		assertEquals(3, model.getSize());
	}
	
}
