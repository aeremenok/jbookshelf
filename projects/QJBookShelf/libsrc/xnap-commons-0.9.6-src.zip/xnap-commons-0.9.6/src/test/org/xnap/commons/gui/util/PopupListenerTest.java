package org.xnap.commons.gui.util;

import java.awt.Component;
import java.awt.Point;
import java.awt.event.MouseEvent;
import javax.swing.JPopupMenu;
import javax.swing.JTextField;
import junit.framework.TestCase;

public class PopupListenerTest extends TestCase {

	
	private TestPopupMenu menu;
	
	
	@Override
	protected void setUp() throws Exception {
		menu = new TestPopupMenu();
	}
	
	public void testPopupListenenr()
	{
		JTextField jtf = new TestTextField();
		PopupListener listener = new PopupListener(menu);
		jtf.addMouseListener(listener);
		MouseEvent me = new MouseEvent(jtf, MouseEvent.MOUSE_PRESSED, 0, 0, 10, 20, 1, true);
		listener.mousePressed(me);
		assertEquals(jtf, menu.invoker);
		
		menu.invoker = null;
		me = new MouseEvent(jtf, MouseEvent.MOUSE_RELEASED, 0, 0, 10, 20, 1, true);
		listener.mouseReleased(me);
		assertEquals(jtf, menu.invoker);
		
		// test non-popup trigger events
		menu.invoker = null;
		me = new MouseEvent(jtf, MouseEvent.MOUSE_PRESSED, 0, 0, 10, 20, 1, false);
		listener.mousePressed(me);
		assertNull(menu.invoker);
		
		menu.invoker = null;
		me =  new MouseEvent(jtf, MouseEvent.MOUSE_RELEASED, 0, 0, 10, 20, 1, false);
		listener.mouseReleased(me);
		assertNull(menu.invoker);
	}
	
	private class TestPopupMenu extends JPopupMenu
	{
		Component invoker;
		int x;
		int y;
		
		@Override
		public void show(Component invoker, int x, int y) {
			this.invoker = invoker;
			this.x = x;
			this.y = y;
		}
		
	}

	private class TestTextField extends JTextField
	{

		@Override
		public Point getLocationOnScreen() {
			return new Point(0, 0);
		}
		
	}


	
}
