package org.xnap.commons.settings;

import java.awt.Font;

/**
 * @author Steffen Pingel
 */
public class FontSettingTest extends AbstractSettingTest<Font> {

	private static Font fontMonospaced = new Font("Monospaced", 0, 12);
	private static Font fontBoldDialog = new Font("Dialog", Font.BOLD, 10);
	private static Font fontSerif= new Font("Serif", 0, 14);

	public FontSettingTest()
	{
		super(fontMonospaced, fontBoldDialog, fontSerif);
	}

	@Override
	protected Setting<Font> createSetting(SettingResource backend, String key, Font defaultValue)
	{
		return new FontSetting(backend, key, defaultValue);
	}

}
