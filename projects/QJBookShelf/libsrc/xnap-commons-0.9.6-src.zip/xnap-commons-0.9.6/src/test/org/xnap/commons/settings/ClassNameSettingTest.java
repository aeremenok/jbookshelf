package org.xnap.commons.settings;



public class ClassNameSettingTest extends AbstractSettingTest<Object> {

	public ClassNameSettingTest()
	{
		// for testing we need objects whose equals method is overriden
		super(new TestObject() , new PropertyResource(),  new String());
	}

	@Override
	protected ClassNameSetting<Object> createSetting(SettingResource backend, String key,
			Object defaultValue) {
		return new ClassNameSetting<Object>(backend, key, defaultValue);
	}
	
	public static class TestObject extends Object
	{

		@Override
		public boolean equals(Object obj) {
			return obj instanceof TestObject;
		}
		
	}

}
