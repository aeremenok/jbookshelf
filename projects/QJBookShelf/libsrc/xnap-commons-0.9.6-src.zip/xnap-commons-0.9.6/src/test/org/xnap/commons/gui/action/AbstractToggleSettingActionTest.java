package org.xnap.commons.gui.action;

import junit.framework.TestCase;
import org.xnap.commons.settings.BooleanSetting;
import org.xnap.commons.settings.PropertyResource;

public class AbstractToggleSettingActionTest extends TestCase {
	
	boolean state;
	boolean invoked;
	
	public void testToggleButton()
	{
		BooleanSetting setting = new BooleanSetting(new PropertyResource(), "test", false);
		MyToggleAction action = new MyToggleAction(setting);
		
		// just make sure we are correctly initialized
		assertEquals(false, action.isSelected());
		assertEquals(false, setting.getValue().booleanValue());
		
		invoked = false;
		setting.setValue(true);
		assertEquals(true, action.isSelected());
		assertEquals(true, invoked);
		
		invoked = false;
		setting.setValue(false);
		assertEquals(false, action.isSelected());
		assertEquals(true, invoked);		
	}

	public void testToggleAction()
	{
		BooleanSetting setting = new BooleanSetting(new PropertyResource(), "test", false);
		MyToggleAction action = new MyToggleAction(setting);
		
		// just make sure we are correctly initialized
		assertEquals(false, action.isSelected());
		assertEquals(false, setting.getValue().booleanValue());
		
		invoked = false;
		action.setSelected(true);
		assertEquals(true, setting.getValue().booleanValue());
		assertEquals(true, invoked);
		
		invoked = false;
		action.setSelected(false);
		assertEquals(false, setting.getValue().booleanValue());
		assertEquals(true, invoked);		
	}

	public void testSetSelected()
	{
		BooleanSetting setting = new BooleanSetting(new PropertyResource(), "test", false);
		MyToggleAction action = new MyToggleAction(setting);
		assertFalse(action.isSelected());
		
		invoked = false;
		action.setSelected(true);
		assertTrue(action.isSelected());
		assertTrue(invoked);

		invoked = false;
		action.setSelected(true);
		assertTrue(action.isSelected());
		assertFalse(invoked);

		invoked = false;
		action.setSelected(false);
		assertFalse(action.isSelected());
		assertTrue(invoked);

		invoked = false;
		action.setSelected(false);
		assertFalse(action.isSelected());
		assertFalse(invoked);

		invoked = false;
		action.setSelected(true);
		assertTrue(action.isSelected());
		assertTrue(invoked);
	}
	
	public class MyToggleAction extends AbstractToggleSettingAction {

		public MyToggleAction(BooleanSetting setting)
		{
			super(setting);
		}
		
		@Override
		public void toggled(boolean selected)
		{
			super.toggled(selected);
			
			state = selected;
			invoked = true;
		}
		
	}

}