package org.xnap.commons.gui.completion;

import java.util.Arrays;
import javax.swing.JList;
import javax.swing.JTextField;
import junit.framework.TestCase;
import org.xnap.commons.gui.completion.CompletionModeFactory.CompletionModeInfo;

public class CompletionModeFactoryTest extends TestCase {

	

	public void testCreateCustomCompletionMode() throws Exception
	{
		CompletionModeFactory.CompletionModeInfo info =
			new CompletionModeFactory.CompletionModeInfo
			("custom mode", CustomCompletionMode.class.getName());
		CompletionModeFactory.installCompletionMode(info);
		assertTrue(Arrays.asList
				(CompletionModeFactory.getInstalledCompletionModes()).contains(info));
		
		CompletionMode mode = CompletionModeFactory.createCompletionMode(info);
		assertEquals(CustomCompletionMode.class, mode.getClass());
		
		mode = CompletionModeFactory.createCompletionMode(info.getClassName());
		assertEquals(CustomCompletionMode.class, mode.getClass());
		
		mode = CompletionModeFactory.createCompletionMode
			(CompletionModeFactory.getCompletionModeInfoByClassName
					(info.getClassName()));
		assertEquals(CustomCompletionMode.class, mode.getClass());
	}
	
	public void testGetCompletionModeInfoByClassName()
	{
		CompletionModeFactory.CompletionModeInfo info;
		info = CompletionModeFactory.getCompletionModeInfoByClassName
			(EmacsCompletionMode.class.	getName());
		assertNotNull(info);
		assertEquals(EmacsCompletionMode.class.getName(), info.getClassName());
		
		// retrieve non-existent info
		info = CompletionModeFactory.getCompletionModeInfoByClassName("foobar");
		assertNull(info);
	}
	
	public void testCreateInvalidCompletionMode() throws Exception
	{
		try {
			CompletionModeFactory.createCompletionMode(JList.class.getName());
			fail("IllegalArgumentException expected");
		}
		catch (IllegalArgumentException iea) {
		}
	}
	
	public void testCompletionModeInfo()
	{
		try {
			new CompletionModeFactory.CompletionModeInfo(null, "foo");
			fail("npe expected");
		}
		catch (NullPointerException npe) {
		}
		try {
			new CompletionModeFactory.CompletionModeInfo("bar", null);
			fail("npe expected");
		}
		catch (NullPointerException npe) {
		}
		
		CompletionModeInfo info =	new CompletionModeInfo("foo", "bar");
		assertEquals("foo", info.getName());
		assertEquals("bar", info.getClassName());
		assertEquals("foo", info.toString());
	}
	
	public void testCreateInstalledCompletionModes() throws Exception
	{
		Completion comp = new Completion(new JTextField(), 
				new DefaultCompletionModel(new String[] { "xnap", "xilef", 
				"xerxes", "xterm", "X" }));
		CompletionModeInfo[] infos =
			CompletionModeFactory.getInstalledCompletionModes();
		for (CompletionModeInfo info : infos) {
			CompletionMode mode = 
				CompletionModeFactory.createCompletionMode(info);
			comp.setMode(mode);
			assertTrue(comp.isEnabled());
			comp.setEnabled(false);
			assertFalse(comp.isEnabled());
			comp.setEnabled(true);
			assertTrue(comp.isEnabled());
			comp.getTextComponent().setText("x");
			comp.getTextComponent().setText("xnap");
			comp.getTextComponent().getDocument().remove(comp.getTextComponent().getText().length() - 2, 1);
		}
	}
	
	/**
	 * Have this test at the end, since it installs an invalid completion mode
	 * which will be around while the class is loaded.
	 */
	public void testInstallCompletionModeInfo()
	{
		CompletionModeFactory.CompletionModeInfo info = new 
			CompletionModeFactory.CompletionModeInfo("test", "testclass");
		CompletionModeFactory.installCompletionMode(info);
		assertTrue(Arrays.asList(CompletionModeFactory.getInstalledCompletionModes()).contains(info));
	}
	
	public static class CustomCompletionMode extends AbstractCompletionMode
	{
		@Override
		protected void enable() {
		}

		@Override
		public void disable() {
		}
		
	}
	
}
