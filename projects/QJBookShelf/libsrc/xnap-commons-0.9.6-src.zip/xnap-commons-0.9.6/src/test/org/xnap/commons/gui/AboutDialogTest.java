package org.xnap.commons.gui;

import javax.swing.Icon;
import javax.swing.JTabbedPane;
import junit.framework.TestCase;
import org.xnap.commons.gui.util.IconHelper;

public class AboutDialogTest extends TestCase {

	public void testAddTabs()
	{
		AboutDialog dialog = new AboutDialog();
		JTabbedPane tabs = dialog.getTabbedPane();
		assertNotNull(tabs);
		assertEquals(0, tabs.getTabCount());
		
		dialog.addTab("title1", "filename");
		assertEquals(1, tabs.getTabCount());
		assertEquals("title1", tabs.getTitleAt(0));
		
		dialog.addTab("title2", "filename2", "alt", false);
		assertEquals(2, tabs.getTabCount());
		assertEquals("title2", tabs.getTitleAt(1));
		
		Icon icon = IconHelper.getTabTitleIcon("folder.png");
		dialog.addLogoTab("title3", icon, "filename3");
		assertEquals(3, tabs.getTabCount());
		assertEquals("title3", tabs.getTitleAt(2));
		
		dialog.addLogoTab("title4", icon, "filename4");
		assertEquals(4, tabs.getTabCount());
		assertEquals("title4", tabs.getTitleAt(3));
		
	}
	
}
