package org.xnap.commons.settings;

import junit.framework.TestCase;

/**
 * @author Steffen Pingel
 */
public abstract class AbstractSettingTest<T> extends TestCase {

	protected SettingResource backend;
	private T value1;
	private T value2;
	private T value3;

	public AbstractSettingTest(T value1, T value2, T value3)
	{
		this.value1 = value1;
		this.value2 = value2;
		this.value3 = value3;
	}
	
	public void setUp() throws Exception
	{
		super.setUp();
		
		backend = new PropertyResource();
	}

	public void tearDown() throws Exception
	{
		super.tearDown();
		
		backend = null;
	}

	public void assertEqualValues(T expected, T value)
	{
		assertEquals(expected, value);
	}
			
	public void assertIllegalArgumentException(Setting<T> setting, T value)
	{
		try {
			setting.setValue(value);
			assertFalse("Expected IllegalArgumentException", true);
		} catch (IllegalArgumentException e) {}	
	}
	
	protected abstract Setting<T> createSetting(SettingResource backend, String key, T defaultValue); 
	
	public void testDefaultValue()
	{
		Setting<T> setting = createSetting(backend, "test", value1);
		assertEqualValues(value1, setting.getDefaultValue());	
		assertEqualValues(value1, setting.getValue());	
		setting.setValue(value2);
		assertEqualValues(value1, setting.getDefaultValue());
		assertEqualValues(value2, setting.getValue());	
		setting.setValue(null);
		assertEqualValues(value1, setting.getDefaultValue());
		assertEqualValues(value1, setting.getValue());	
	}

	public void testDefaultNull() 
	{
		Setting<T> setting = createSetting(backend, "test", null);
		assertEqualValues(null, setting.getDefaultValue());	
		assertEqualValues(null, setting.getValue());
		setting.setValue(value1);
		assertEqualValues(null, setting.getDefaultValue());
	}

	public void testSetValue() 
	{
		Setting<T> setting = createSetting(backend, "test", value3);
		setting.setValue(value1);
		assertEqualValues(value1, setting.getValue());	
		setting.setValue(value2);
		assertEqualValues(value2, setting.getValue());	
	}

}
