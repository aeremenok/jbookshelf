package org.xnap.commons.settings;

import java.awt.event.KeyEvent;
import javax.swing.KeyStroke;

/**
 * @author Steffen Pingel
 */
public class KeyStrokeSettingTest extends AbstractSettingTest<KeyStroke> {

	final static KeyStroke keyA = KeyStroke.getKeyStroke('a');
	final static KeyStroke keyShiftTab = KeyStroke.getKeyStroke(KeyEvent.VK_TAB, KeyEvent.SHIFT_MASK);
	final static KeyStroke keyCtrlA = KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.CTRL_MASK);
	final static KeyStroke keyCtrlShiftA = KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK);
	final static KeyStroke keyAltCtrlShiftA = KeyStroke.getKeyStroke(KeyEvent.VK_A, KeyEvent.CTRL_MASK | KeyEvent.SHIFT_MASK | KeyEvent.ALT_MASK);

	public KeyStrokeSettingTest()
	{
		super(keyCtrlA, keyShiftTab, keyCtrlShiftA);
	}

	@Override
	protected Setting<KeyStroke> createSetting(SettingResource backend, String key, KeyStroke defaultValue)
	{
		return new KeyStrokeSetting(backend, key, defaultValue);
	}

}
