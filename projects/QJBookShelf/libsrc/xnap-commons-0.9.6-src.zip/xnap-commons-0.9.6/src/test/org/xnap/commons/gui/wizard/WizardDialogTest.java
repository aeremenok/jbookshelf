package org.xnap.commons.gui.wizard;

import junit.framework.TestCase;


public class WizardDialogTest extends TestCase {

	private DefaultWizardPage page2;
	private WizardDialog dialog;
	private DefaultWizardPage page1;

	@Override
	protected void setUp() throws Exception
	{
		super.setUp();

		dialog = new WizardDialog();
		
		page1 = new DefaultWizardPage();
		dialog.addPage(page1, "p1");

		page2 = new DefaultWizardPage();
		dialog.addPage(page2, "p2");
	}
	
	@Override
	protected void tearDown() throws Exception
	{
		super.tearDown();
		
		dialog.removePage(page1);
		page1 = null;
		dialog.removePage(page2);
		page2 = null;
		dialog = null;
	}
	
	public void testNext()
	{
		assertEquals(0, dialog.getSelectedIndex());
		dialog.showNextPage();
		assertEquals(1, dialog.getSelectedIndex());
		try {
			dialog.showNextPage();
			assertTrue("Expected exception", false);
		} catch (IllegalStateException e) {}
	}
	
	public void testPrevious()
	{
		assertEquals(0, dialog.getSelectedIndex());
		dialog.showNextPage();
		dialog.showPreviousPage();
		assertEquals(0, dialog.getSelectedIndex());
		try {
			dialog.showPreviousPage();
			assertTrue("Expected exception", false);
		} catch (IllegalStateException e) {}
	}
	
	public void testListener()
	{
		Handler handler = new Handler();
		dialog.addWizardDialogListener(handler);
		
		handler.invoked = false;
		dialog.showNextPage();
		assertEquals(true, handler.invoked);
		assertEquals(page1, handler.oldPage);
		assertEquals(page2, handler.newPage);

		handler.invoked = false;
		dialog.showPreviousPage();
		assertEquals(true, handler.invoked);
		assertEquals(page2, handler.oldPage);
		assertEquals(page1, handler.newPage);

		dialog.removeWizardDialogListener(handler);
		
		handler.invoked = false;
		dialog.showNextPage();
		assertEquals(false, handler.invoked);
	}

	private class Handler implements WizardDialogListener {

		private WizardPage oldPage;
		private WizardPage newPage;
		private boolean invoked;

		public void pageChanged(WizardPage oldPage, WizardPage newPage)
		{
			this.oldPage = oldPage;
			this.newPage = newPage;
			this.invoked = true;
		}
		
	}
	
}
