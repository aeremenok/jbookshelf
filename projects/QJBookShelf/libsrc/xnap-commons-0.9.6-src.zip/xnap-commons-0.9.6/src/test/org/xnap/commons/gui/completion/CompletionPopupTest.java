package org.xnap.commons.gui.completion;

import java.awt.ComponentOrientation;
import javax.swing.JTextField;
import junit.framework.TestCase;

public class CompletionPopupTest extends TestCase 
{

	CompletionPopup popup;
	
	@Override
	protected void setUp() throws Exception 
	{
		popup = new CompletionPopup();
	}
	
	public void testOrientationsInSync()
	{
		JTextField jtf = new JTextField();
		Completion completion = new Completion(jtf);
		popup.enablePopup(completion);
		assertEquals(jtf.getComponentOrientation(), popup.getComponentOrientation());
		assertEquals(jtf.getComponentOrientation(), popup.getList().getComponentOrientation());
		
		jtf.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		assertEquals(jtf.getComponentOrientation(), popup.getComponentOrientation());
		assertEquals(jtf.getComponentOrientation(), popup.getList().getComponentOrientation());
		
		jtf.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		assertEquals(jtf.getComponentOrientation(), popup.getComponentOrientation());
		assertEquals(jtf.getComponentOrientation(), popup.getList().getComponentOrientation());
		
		popup.disablePopup();
		jtf.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		assertNotSame(jtf.getComponentOrientation(), popup.getComponentOrientation());
		assertNotSame(jtf.getComponentOrientation(), popup.getList().getComponentOrientation());
		
		popup.enablePopup(completion);
		assertEquals(jtf.getComponentOrientation(), popup.getComponentOrientation());
		assertEquals(jtf.getComponentOrientation(), popup.getList().getComponentOrientation());
	}
	
}
