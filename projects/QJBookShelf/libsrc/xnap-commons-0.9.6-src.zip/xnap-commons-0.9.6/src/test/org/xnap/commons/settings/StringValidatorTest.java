/*
 *  XNap
 *
 *  A pure java file sharing client.
 *
 *  See AUTHORS for copyright information.
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package org.xnap.commons.settings;

import junit.framework.TestCase;

/**
 * @author Steffen Pingel
 */
public class StringValidatorTest extends TestCase {
    
    public StringValidatorTest(String name) 
    {
		super(name);
    }

    protected void setUp()
    {
    }

    protected void tearDown()
    {
    }

	public void testEmptyConstructor()
	{
		// should validate anything
		StringValidator v = new StringValidator();
		v.validate("");
		v.validate(" ");
		v.validate("a");
	}

	public void testStringConstructor()
	{
		StringValidator v = new StringValidator("a");
		v.validate("aaa");
		v.validate("a");
		v.validate("");
		invalidate(v, "aba");
		invalidate(v, "b");
	}
	
	public void testStringLengthConstructor()
	{
		StringValidator v = new StringValidator("a", 0);
		v.validate("aaa");
		v.validate("a");
		v.validate("");

		v = new StringValidator("a", 1);
		v.validate("aaa");
		v.validate("aa");
		v.validate("a");
		invalidate(v, "");
	}

	public void testNull()
	{
		StringValidator v = new StringValidator();
		invalidate(v, null);
	}

    public void testEmail() 
    {
		StringValidator.EMAIL.validate("a");
		StringValidator.EMAIL.validate("a@a.com");

		invalidate(StringValidator.EMAIL, null);
		invalidate(StringValidator.EMAIL, "");
		invalidate(StringValidator.EMAIL, " ");
    }

    public void testRegularString() 
    {
		StringValidator.REGULAR_STRING.validate("a");

		invalidate(StringValidator.REGULAR_STRING, null);
		invalidate(StringValidator.REGULAR_STRING, "");
		invalidate(StringValidator.REGULAR_STRING, " ");
	}

    public void invalidate(StringValidator validator, String s) 
    {
		try {
			validator.validate(s);
			assertTrue(false);
		}
		catch (IllegalArgumentException e) {
		}
	}

}

